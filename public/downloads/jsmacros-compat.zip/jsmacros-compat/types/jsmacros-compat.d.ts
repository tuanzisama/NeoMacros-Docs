// jsmacros-compat type declarations: the JsMacros 1.9.2 script surface laid
// over the NeoMacros `neo` surface. Members documented as unavailable in
// docs/missing-apis.md keep their signatures and throw UnimplementedError at
// runtime. Synchronous JsMacros APIs that NeoMacros can only serve
// asynchronously return promises - see the README section
// "Synchronous APIs become promises".
//
// Usage inside a NeoMacros script:
//   import '<path>/jsmacros-compat/src/index.js';
// then reference the globals below (no import needed - they are installed
// on globalThis). Add this file to tsconfig "files" or reference it with
//   /// <reference path="jsmacros-compat.d.ts" />

declare class UnimplementedError extends Error {
    path: string;
    reason: string;
}

// ---------------------------------------------------------------------------
// Math / position classes
// ---------------------------------------------------------------------------

declare class CompatPos2D {
    x: number;
    y: number;
    constructor(x: number, y: number);
    getX(): number;
    getY(): number;
    add(other: CompatPos2D): CompatPos2D;
    add(x: number, y: number): CompatPos2D;
    sub(other: CompatPos2D): CompatPos2D;
    sub(x: number, y: number): CompatPos2D;
    multiply(other: CompatPos2D): CompatPos2D;
    multiply(x: number, y: number): CompatPos2D;
    divide(other: CompatPos2D): CompatPos2D;
    divide(x: number, y: number): CompatPos2D;
    scale(factor: number): CompatPos2D;
    to3D(): CompatPos3D;
    toVector(): CompatVec2D;
    toReverseVector(): CompatVec2D;
    compareTo(other: CompatPos2D): number;
    equals(other: unknown): boolean;
    hashCode(): number;
    toString(): string;
    static ZERO: CompatPos2D;
}

declare class CompatPos3D extends CompatPos2D {
    z: number;
    constructor(x: number, y: number, z: number);
    getZ(): number;
    add(other: CompatPos3D): CompatPos3D;
    add(x: number, y: number, z: number): CompatPos3D;
    sub(other: CompatPos3D): CompatPos3D;
    sub(x: number, y: number, z: number): CompatPos3D;
    multiply(other: CompatPos3D): CompatPos3D;
    multiply(x: number, y: number, z: number): CompatPos3D;
    divide(other: CompatPos3D): CompatPos3D;
    divide(x: number, y: number, z: number): CompatPos3D;
    scale(factor: number): CompatPos3D;
    toBlockPos(): CompatBlockPos;
    static ZERO: CompatPos3D;
}

declare class CompatVec2D {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    constructor(x1: number, y1: number, x2: number, y2: number);
    getX1(): number;
    getY1(): number;
    getX2(): number;
    getY2(): number;
    getDeltaX(): number;
    getDeltaY(): number;
    getStart(): CompatPos2D;
    getEnd(): CompatPos2D;
    getMagnitude(): number;
    getMagnitudeSq(): number;
    add(other: CompatVec2D): CompatVec2D;
    multiply(other: CompatVec2D): CompatVec2D;
    scale(factor: number): CompatVec2D;
    dotProduct(other: CompatVec2D): number;
    reverse(): CompatVec2D;
    normalize(): CompatVec2D;
    to3D(): CompatVec3D;
    equals(other: unknown): boolean;
    toString(): string;
}

declare class CompatVec3D extends CompatVec2D {
    z1: number;
    z2: number;
    constructor(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number);
    getZ1(): number;
    getZ2(): number;
    getDeltaZ(): number;
    getStart(): CompatPos3D;
    getEnd(): CompatPos3D;
    add(other: CompatVec3D): CompatVec3D;
    addStart(pos: CompatPos3D): CompatVec3D;
    addStart(x: number, y: number, z: number): CompatVec3D;
    addEnd(pos: CompatPos3D): CompatVec3D;
    addEnd(x: number, y: number, z: number): CompatVec3D;
    multiply(other: CompatVec3D): CompatVec3D;
    scale(factor: number): CompatVec3D;
    dotProduct(other: CompatVec3D): number;
    crossProduct(other: CompatVec3D): CompatVec3D;
    reverse(): CompatVec3D;
    normalize(): CompatVec3D;
    getPitch(): number;
    getYaw(): number;
    toString(): string;
}

declare class CompatBlockPos {
    constructor(x: number, y: number, z: number);
    getX(): number;
    getY(): number;
    getZ(): number;
    up(n?: number): CompatBlockPos;
    down(n?: number): CompatBlockPos;
    north(n?: number): CompatBlockPos;
    south(n?: number): CompatBlockPos;
    west(n?: number): CompatBlockPos;
    east(n?: number): CompatBlockPos;
    offset(direction: string, n?: number): CompatBlockPos;
    offset(dx: number, dy: number, dz: number): CompatBlockPos;
    distanceTo(other: CompatBlockPos | CompatPos3D): number;
    distanceTo(x: number, y: number, z: number): number;
    toPos3D(): CompatPos3D;
    toNetherCoords(): CompatBlockPos;
    toOverworldCoords(): CompatBlockPos;
    equals(other: unknown): boolean;
    toString(): string;
}

declare class CompatDirection {
    constructor(name: string);
    getName(): string;
    getVector(): CompatPos3D;
    getAxis(): string;
    getOpposite(): CompatDirection;
    getLeft(): CompatDirection;
    getRight(): CompatDirection;
    getPitch(): number;
    getYaw(): number;
    isHorizontal(): boolean;
    isVertical(): boolean;
    isTowardsPositive(): boolean;
    pointsTo(yaw: number): boolean;
    toString(): string;
}

// ---------------------------------------------------------------------------
// Text classes
// ---------------------------------------------------------------------------

interface TextPart {
    text: string;
    color: string | null;
    bold: boolean;
    italic: boolean;
    underlined: boolean;
    strikethrough: boolean;
    obfuscated: boolean;
}

declare class TextHelperCompat {
    constructor(source: string | object | null);
    static fromString(content: string): TextHelperCompat;
    static fromJson(json: string | object): TextHelperCompat;
    static fromTranslationKey(key: string, ...content: unknown[]): TextHelperCompat;
    static wrap(source: string | object | TextHelperCompat): TextHelperCompat;
    getString(): string;
    getFormatted(): string;
    getStringStripFormatting(): string;
    toJson(): object;
    getJson(): string;
    withoutFormatting(): TextHelperCompat;
    visit(visitor: (part: string) => void): void;
    replaceFromString(content: string): TextHelperCompat;
    replaceFromJson(json: string | object): TextHelperCompat;
    // JsMacros members not backed by the neo text pipeline (getWidth, ...)
    // exist and throw UnimplementedError at runtime.
    toString(): string;
}

declare class TextBuilderCompat {
    append(part: string | TextHelperCompat): TextBuilderCompat;
    withColor(index: number): TextBuilderCompat;
    withColor(name: string): TextBuilderCompat;
    withColor(r: number, g: number, b: number): TextBuilderCompat;
    withFormatting(underline: boolean, bold: boolean, italic: boolean, strikethrough: boolean, magic: boolean): TextBuilderCompat;
    build(): TextHelperCompat;
    // Hover/click styling members exist and throw at runtime.
}

// ---------------------------------------------------------------------------
// Item / block helpers
// ---------------------------------------------------------------------------

declare class ItemStackCompat {
    getItemId(): string;
    getItemID(): string;
    getCount(): number;
    getDamage(): number;
    getMaxDamage(): number;
    getMaxDurability(): number;
    getDurability(): number;
    isEmpty(): boolean;
    getItem(): never;
    getName(): TextHelperCompat;
    getDefaultName(): TextHelperCompat;
    getLore(): TextHelperCompat[];
    getEnchantments(): Array<{ id: string; lvl: number }>;
    getEnchantment(id: string): { id: string; lvl: number } | null;
    hasEnchantment(id: string): boolean;
    equals(other: unknown): boolean;
    isNBTEqual(other: ItemStackCompat): boolean;
    isItemEqual(other: ItemStackCompat): boolean;
    isItemEqualIgnoreDamage(other: ItemStackCompat): boolean;
    copy(): ItemStackCompat;
    // The remaining JsMacros ItemStackHelper members exist and throw.
    toString(): string;
}

declare class BlockDataCompat {
    getBlockPos(): CompatBlockPos;
    getX(): number;
    getY(): number;
    getZ(): number;
    getId(): string | undefined;
    getName(): TextHelperCompat;
    getBlockStateHelper(): BlockStateCompat;
    getBlock(): never;
    toString(): string;
    // getNBT / raw block access exist and throw.
}

declare class BlockStateCompat {
    getId(): string | undefined;
    isAir(): boolean;
    isLiquid(): boolean;
    toString(): string;
    // All other JsMacros BlockStateHelper members exist and throw.
}

declare class HitResultCompat {
    getBlock(): BlockDataCompat | null;
    getPos(): CompatPos3D | null;
    getEntity(): EntityHelperCompat | null;
    toString(): string;
}

// ---------------------------------------------------------------------------
// Entity helper chain
// ---------------------------------------------------------------------------

declare class EntityHelperCompat {
    static create(source: unknown): EntityHelperCompat | LivingEntityCompat | PlayerEntityCompat | ClientPlayerCompat | ItemEntityCompat;
    getPos(): CompatPos3D | null;
    getX(): number | undefined;
    getY(): number | undefined;
    getZ(): number | undefined;
    getBlockPos(): CompatBlockPos | null;
    getEyePos(): CompatPos3D | null;
    getEyeHeight(): number | undefined;
    getChunkPos(): CompatPos2D | null;
    getPitch(): number | undefined;
    getYaw(): number | undefined;
    getName(): TextHelperCompat;
    getType(): string;
    is(...types: string[]): boolean;
    isAlive(): boolean;
    isInLava(): boolean;
    isOnFire(): boolean;
    isSneaking(): boolean;
    isSprinting(): boolean;
    getUUID(): string;
    getFacingDirection(): CompatDirection;
    getBiome(): string;
    getVehicle(): EntityHelperCompat | null;
    getPassengers(): EntityHelperCompat[] | null;
    getVelocity(): CompatPos3D | null;
    distanceTo(target: EntityHelperCompat | CompatPos3D | CompatBlockPos | number, y?: number, z?: number): number;
    rayTraceBlock(distance: number, fluid: boolean): BlockDataCompat | null;
    rayTraceEntity(distance: number): EntityHelperCompat | null;
    asClientPlayer(): ClientPlayerCompat | null;
    asPlayer(): PlayerEntityCompat | null;
    asLiving(): LivingEntityCompat | null;
    asVillager(): EntityHelperCompat | null;
    asMerchant(): EntityHelperCompat | null;
    asAnimal(): LivingEntityCompat | null;
    asItem(): ItemEntityCompat | null;
    // JsMacros members without a neo equivalent (getNBT, setGlowing,
    // getMaxAir, specialized mob/animal/passive state, ...) exist and throw.
    toString(): string;
}

declare class LivingEntityCompat extends EntityHelperCompat {
    getHealth(): number | undefined;
    getMaxHealth(): number | undefined;
    getMainHand(): ItemStackCompat | null;
    getOffHand(): ItemStackCompat | null;
    isHolding(itemId: string): boolean;
    isSleeping(): boolean;
    isFallFlying(): boolean;
    isOnGround(): boolean;
    isSpectator(): boolean;
}

declare class PlayerEntityCompat extends LivingEntityCompat {
    getPlayerName(): string;
    getXP(): number | undefined;
    getXPLevel(): number | undefined;
    getXPProgress(): number | undefined;
}

declare class ClientPlayerCompat extends PlayerEntityCompat {
    getFoodLevel(): number | undefined;
    getSaturation(): number | undefined;
    attack(target?: unknown, awaitCompletion?: boolean): Promise<void>;
    interactEntity(target: unknown, offHand?: boolean, awaitCompletion?: boolean): Promise<void>;
    interactBlock(x: number, y: number, z: number, direction?: number, offHand?: boolean, awaitCompletion?: boolean): Promise<void>;
    dropHeldItem(dropStack?: boolean): Promise<void>;
    // Velocity/teleport/look writes and the remaining JsMacros extras exist
    // and throw at runtime.
}

declare class ItemEntityCompat extends EntityHelperCompat {
    getStack(): ItemStackCompat | null;
}

// ---------------------------------------------------------------------------
// Inventory helpers (actions return promises)
// ---------------------------------------------------------------------------

declare class InventoryCompat {
    getType(): string;
    is(...types: string[]): boolean;
    getTotalSlots(): number;
    getSlot(i: number): ItemStackCompat | null;
    getItems(): Array<ItemStackCompat | null>;
    contains(stackOrId: ItemStackCompat | string): boolean;
    findItem(stackOrId: ItemStackCompat | string): number[];
    getItemCount(): Record<string, number>;
    findFreeSlot(): number;
    click(slot: number, mouseButton?: number): Promise<void>;
    dropSlot(slot: number, all?: boolean): Promise<void>;
    quick(slot: number): Promise<void>;
    swapHotbar(slot: number, hotbarSlot: number): Promise<void>;
    split(slot1: number, slot2: number): Promise<void>;
    grabAll(slot: number): Promise<void>;
    closeAndDrop(): Promise<void>;
    close(): Promise<void>;
    getContainerTitle(): string;
    isContainer(): boolean;
    toString(): string;
    // Cursor access, slot maps, drag clicks, and raw container access exist
    // and throw.
}

declare class PlayerInventoryCompat extends InventoryCompat {
}

// The specialized JsMacros inventory classes (FurnaceInventory,
// CraftingInventory, VillagerInventory, ...) are dispatched by the open
// screen kind; their inherited base surface works and every type-specific
// member exists and throws.
declare class FurnaceInventoryCompat extends InventoryCompat { }
declare class CraftingInventoryCompat extends InventoryCompat { }
declare class ContainerInventoryCompat extends InventoryCompat { }

// ---------------------------------------------------------------------------
// Draw helpers
// ---------------------------------------------------------------------------

declare class TextElementCompat {
    text: string;
    x: number;
    y: number;
    color: number;
    setText(value: string | TextHelperCompat): void;
    setPos(x: number, y: number): void;
    setColor(color: number): void;
    getPosX(): number;
    getPosY(): number;
    getColor(): number;
    getText(): string;
}

declare class Draw2DCompat {
    register(): Draw2DCompat;
    unregister(): Draw2DCompat;
    addText(text: string | TextHelperCompat, x: number, y: number, color: number, shadow?: boolean): TextElementCompat;
    setOnInit(callback: () => void): Draw2DCompat;
    setOnFailInit(callback: () => void): Draw2DCompat;
    removeElement(element: TextElementCompat): Draw2DCompat;
    reAddElement(element: TextElementCompat): Draw2DCompat;
    getElements(): TextElementCompat[];
    isVisible(): boolean;
    setVisible(visible: boolean): Draw2DCompat;
    // addRect/addLine/addImage/addItem and styling members exist and throw.
}

declare class BoxElementCompat {
    min: { x: number; y: number; z: number };
    max: { x: number; y: number; z: number };
    color: number;
    setPos1(pos: { x: number; y: number; z: number }): void;
    setPos1(x: number, y: number, z: number): void;
    setPos2(pos: { x: number; y: number; z: number }): void;
    setPos2(x: number, y: number, z: number): void;
    setColor(color: number): void;
}

declare class Line3DElementCompat {
    from: { x: number; y: number; z: number };
    to: { x: number; y: number; z: number };
    color: number;
    setPos1(pos: { x: number; y: number; z: number }): void;
    setPos1(x: number, y: number, z: number): void;
    setPos2(pos: { x: number; y: number; z: number }): void;
    setPos2(x: number, y: number, z: number): void;
    setColor(color: number): void;
}

declare class Draw3DCompat {
    readonly layerId: string;
    register(): Draw3DCompat;
    unregister(): Draw3DCompat;
    addBox(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, color: number, fillColor?: number, fill?: boolean, cull?: boolean): BoxElementCompat;
    addLine(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, color: number, alpha?: number, cull?: boolean): Line3DElementCompat;
    addPoint(pos: CompatPos3D, radius: number, color: number, alpha?: number, cull?: boolean): BoxElementCompat;
    addPoint(x: number, y: number, z: number, radius: number, color: number, alpha?: number, cull?: boolean): BoxElementCompat;
    removeBox(box: BoxElementCompat): void;
    removeLine(line: Line3DElementCompat): void;
    clear(): void;
    getBoxes(): BoxElementCompat[];
    getLines(): Line3DElementCompat[];
    getTraceLines(): never[];
    getEntityTraceLines(): never[];
    getDraw2Ds(): never[];
}

// ---------------------------------------------------------------------------
// Events
// ---------------------------------------------------------------------------

declare class JsEvent {
    cancellable(): boolean;
    joinable(): boolean;
    cancel(): void;
    isCanceled(): boolean;
    getEventName(): string;
    toString(): string;
    // trigger() exists and throws.
}

// Fields carried by the corresponding NeoMacros event are data properties;
// JsMacros fields with no payload equivalent exist as throwing accessors
// (docs/missing-apis.md section 6.2 lists every one).

interface EventKeyShape extends JsEvent { action: number; key: string; mods: string }
interface EventRecvMessageShape extends JsEvent { readonly text: TextHelperCompat; signature: null; messageType: null }
interface EventSendMessageShape extends JsEvent { readonly message: string }
interface EventBossbarShape extends JsEvent { bossBar: { getName(): TextHelperCompat; getPercent(): number | undefined; getUuid(): string | undefined }; uuid: string; type: string }
interface EventSoundShape extends JsEvent { sound: string; volume: number; pitch: number; position: CompatPos3D }
interface EventDimensionChangeShape extends JsEvent { dimension: string }
interface EventChunkLoadShape extends JsEvent { x: number | undefined; z: number | undefined }
interface EventBlockUpdateShape extends JsEvent { block: BlockDataCompat | null; updateType: string }
interface EventEntityLoadShape extends JsEvent { entity: EntityHelperCompat }
interface EventEntityDamagedShape extends JsEvent { entity: EntityHelperCompat; health: number | undefined; damage: number | undefined }
interface EventPlayerJoinShape extends JsEvent { UUID: string | undefined; player: { getName(): string; getUuid(): string } }
interface EventDamageShape extends JsEvent { health: number; change: number }
interface EventDeathShape extends JsEvent { deathPos: CompatBlockPos | null }
interface EventHeldItemChangeShape extends JsEvent { offHand: boolean; item: ItemStackCompat | null; oldItem: ItemStackCompat | null }
interface EventOpenScreenShape extends JsEvent { screen: null; screenName: string | null }

type MappedEventName =
    | 'Tick' | 'Key' | 'MouseScroll' | 'RecvMessage' | 'SendMessage' | 'Sound'
    | 'Bossbar' | 'JoinServer' | 'Disconnect' | 'DimensionChange'
    | 'ChunkLoad' | 'ChunkUnload' | 'BlockUpdate' | 'EntityLoad' | 'EntityUnload'
    | 'EntityDamaged' | 'EntityHealed' | 'PlayerJoin' | 'PlayerLeave'
    | 'AirChange' | 'AttackBlock' | 'AttackEntity' | 'InteractBlock'
    | 'InteractEntity' | 'Damage' | 'Heal' | 'HealthChange' | 'Death'
    | 'EXPChange' | 'FallFlying' | 'HeldItemChange' | 'HungerChange'
    | 'OpenScreen' | 'StatusEffectUpdate' | 'LaunchGame' | 'QuitGame' | 'ANYTHING';

// Registering any other JsMacros event name (RecvPacket, SendPacket, Title,
// SignEdit, ClickSlot, ...) throws UnimplementedError - see
// docs/missing-apis.md section 6.1.
type UnimplementedEventName = string;

interface IEventListenerCompat {
    off(): boolean;
    joined(): boolean;
    toString(): string;
}

interface EventFiltererCompat {
    compatTest(jsEvent: JsEvent): boolean;
    // Builder setters on the BlockUpdate filterer exist and work.
}

interface EventContainerCompat {
    isLocked(): boolean;
    getCtx(): null;
    getLockThread(): null;
    awaitLock(then: () => void): void;
    releaseLock(): void;
}

interface EventAndContextCompat {
    event: JsEvent;
    context: EventContainerCompat;
}

declare class EventCustomCompat {
    eventName: string;
    joinable: boolean;
    readonly cancelable: boolean;
    putInt(name: string, value: number): number;
    putString(name: string, value: string): string;
    putDouble(name: string, value: number): number;
    putBoolean(name: string, value: boolean): boolean;
    getInt(name: string): number | null;
    getString(name: string): string | null;
    getDouble(name: string): number | null;
    getBoolean(name: string): boolean | null;
    getObject(name: string): unknown;
    getType(name: string): 'Int' | 'Double' | 'String' | 'Boolean' | 'Object' | null;
    getUnderlyingMap(): Record<string, unknown>;
    registerEvent(): EventCustomCompat;
    trigger(): void;
    triggerAsync(callback?: (event: JsEvent) => void): void;
}

// ---------------------------------------------------------------------------
// Request / FS helpers
// ---------------------------------------------------------------------------

declare class ResponseCompat {
    readonly responseCode: number;
    readonly headers: Record<string, unknown>;
    text(): Promise<string>;
    json(): Promise<unknown>;
    byteArray(): Promise<number[]>;
    toString(): string;
}

declare class HttpRequestCompat {
    url: string;
    headers: Record<string, string>;
    addHeader(key: string, value: string): HttpRequestCompat;
    setConnectTimeout(millis: number): never;
    setReadTimeout(millis: number): never;
    get(): Promise<ResponseCompat>;
    post(data: string): Promise<ResponseCompat>;
    put(data: string): Promise<ResponseCompat>;
    send(method: string, data?: string): Promise<ResponseCompat>;
}

declare class FileHandlerCompat {
    write(data: string | number[] | ArrayLike<number>): Promise<FileHandlerCompat>;
    append(data: string | number[] | ArrayLike<number>): Promise<FileHandlerCompat>;
    read(): Promise<string>;
    readBytes(): Promise<unknown>;
    readLines(): Promise<{ hasNext(): boolean; next(): string | null; close(): void }>;
    toString(): string;
}

// ---------------------------------------------------------------------------
// Globals
// ---------------------------------------------------------------------------

declare const JsMacros: {
    on(name: MappedEventName, callback: (event: JsEvent, context: EventContainerCompat) => unknown): IEventListenerCompat;
    on(name: MappedEventName, joined: boolean, callback: (event: JsEvent, context: EventContainerCompat) => unknown): IEventListenerCompat;
    on(name: MappedEventName, filterer: EventFiltererCompat | ((event: JsEvent) => unknown), callback: (event: JsEvent, context: EventContainerCompat) => unknown): IEventListenerCompat;
    on(name: UnimplementedEventName, callback: (event: JsEvent, context: EventContainerCompat) => unknown): never;
    once(name: MappedEventName, callback: (event: JsEvent, context: EventContainerCompat) => unknown): IEventListenerCompat;
    once(name: MappedEventName, joined: boolean, callback: (event: JsEvent, context: EventContainerCompat) => unknown): IEventListenerCompat;
    off(listener: IEventListenerCompat): boolean;
    off(name: MappedEventName, listener: IEventListenerCompat): boolean;
    listeners(name: MappedEventName): IEventListenerCompat[];
    disableAllListeners(name?: MappedEventName): void;
    disableScriptListeners(name?: MappedEventName): void;
    waitForEvent(name: MappedEventName): Promise<EventAndContextCompat>;
    waitForEvent(name: MappedEventName, join: boolean): Promise<EventAndContextCompat>;
    waitForEvent(name: MappedEventName, filter: EventFiltererCompat | ((event: JsEvent) => unknown)): Promise<EventAndContextCompat>;
    waitForEvent(name: MappedEventName, join: boolean, filter: EventFiltererCompat | ((event: JsEvent) => unknown), runBeforeWaiting?: () => void): Promise<EventAndContextCompat>;
    assertEvent(event: JsEvent, type: string): void;
    createCustomEvent(eventName: string): EventCustomCompat;
    createEventFilterer(eventName: MappedEventName): EventFiltererCompat;
    createComposedEventFilterer(initial: EventFiltererCompat): EventFiltererCompat;
    createModulusEventFilterer(quotient: number): EventFiltererCompat;
    invertEventFilterer(base: EventFiltererCompat): EventFiltererCompat;
    // runScript, profiles, config, and services exist and throw.
    toString(): string;
};

declare const Player: {
    getPlayer(): ClientPlayerCompat | null;
    openInventory(): InventoryCompat;
    getInteractionManager(): {
        attack(target?: unknown, awaitCompletion?: boolean): Promise<void>;
        interactEntity(entity: unknown, offHand?: boolean, awaitCompletion?: boolean): Promise<void>;
        interactBlock(x: number, y: number, z: number, direction?: number, offHand?: boolean, awaitCompletion?: boolean): Promise<void>;
        getTargetedBlock(): BlockDataCompat | null;
        getTargetedEntity(): EntityHelperCompat | null;
        getGameMode(): string | undefined;
        // breakBlock / holdInteract / setTarget and friends exist and throw.
    };
    /** Alias of getInteractionManager. */
    interactions(): ReturnType<Player['getInteractionManager']>;
    getGameMode(): string | null;
    rayTraceBlock(distance: number, fluid?: boolean): BlockDataCompat | null;
    detailedRayTraceBlock(distance: number, fluid?: boolean): HitResultCompat | null;
    rayTraceEntity(distance: number): EntityHelperCompat | null;
    // Movement input synthesis, screenshots, sign writing, gamemode writes
    // exist and throw.
    toString(): string;
};

declare const World: {
    isWorldLoaded(): boolean;
    getDimension(): string | null;
    getBiome(): string;
    getBiomeAt(x: number, y: number, z: number): string;
    getTime(): number;
    getTimeOfDay(): number;
    isDay(): boolean;
    isNight(): boolean;
    isRaining(): boolean;
    isThundering(): boolean;
    getDifficulty(): number;
    getBlock(x: number, y: number, z: number): BlockDataCompat | null;
    getBlock(pos: CompatPos3D | CompatBlockPos): BlockDataCompat | null;
    getChunk(chunkX: number, chunkZ: number): { getX(): number; getZ(): number; toString(): string };
    isChunkLoaded(chunkX: number, chunkZ: number): boolean;
    getLoadedPlayers(): EntityHelperCompat[] | null;
    getEntities(distance?: number, ...types: string[]): EntityHelperCompat[] | null;
    getEntities(filter: (entity: EntityHelperCompat) => unknown): EntityHelperCompat[] | null;
    rayTraceBlock(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, fluid?: boolean): BlockDataCompat | null;
    rayTraceEntity(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number): EntityHelperCompat | null;
    iterateSphere(pos: CompatBlockPos, radius: number, ignoreAir: boolean, callback: (block: BlockDataCompat) => void): void;
    iterateBox(pos1: CompatBlockPos, pos2: CompatBlockPos, ignoreAir: boolean, callback: (block: BlockDataCompat) => void): void;
    toString(): string;
    // Tab lists, boss bar map, sounds, particles, TPS, world scanner, and
    // raw world access exist and throw.
};

declare const Chat: {
    log(message: string | TextHelperCompat | null, awaitCompletion?: boolean): void;
    logf(format: string, ...args: unknown[]): void;
    logColor(message: string): void;
    say(message: string, awaitCompletion?: boolean): void;
    sayf(format: string, ...args: unknown[]): void;
    actionbar(text: string | TextHelperCompat, tinted?: boolean): void;
    createTextHelperFromString(content: string): TextHelperCompat;
    createTextHelperFromTranslationKey(key: string, ...content: unknown[]): TextHelperCompat;
    createTextHelperFromJSON(json: string): TextHelperCompat;
    createTextBuilder(): TextBuilderCompat;
    getCommandManager(): object;
    getHistory(): object;
    getTextWidth(text: string): never;
    sectionSymbolToAmpersand(text: string): string;
    ampersandToSectionSymbol(text: string): string;
    stripFormatting(text: string): string;
    toString(): string;
    // open, title, toast, and logger access exist and throw.
};

declare const Client: {
    runOnMainThread(runnable: () => unknown, awaitCompletion?: boolean, watchdogMaxTime?: number): Promise<unknown> | undefined;
    waitTick(ticks?: number): Promise<void>;
    getMinecraft(): unknown;
    mcVersion(): string;
    getFPS(): string;
    toString(): string;
    // Connection management, pings, packets, mod lists, clipboard, and
    // registry access exist and throw.
};

declare const Time: {
    time(): number;
    sleep(millis: number): Promise<void>;
    toString(): string;
};

declare const KeyBind: {
    key(keyName: string, state: boolean): void;
    pressKey(keyName: string): void;
    releaseKey(keyName: string): void;
    keyBind(keyBind: string, state: boolean): void;
    pressKeyBind(keyBind: string): void;
    releaseKeyBind(keyBind: string): void;
    toString(): string;
    // Bind introspection and re-assignment exist and throw.
};

declare const Hud: {
    createDraw2D(): Draw2DCompat;
    createDraw3D(): Draw3DCompat;
    registerDraw2D(draw2d: Draw2DCompat): void;
    unregisterDraw2D(draw2d: Draw2DCompat): void;
    registerDraw3D(draw3d: Draw3DCompat): void;
    unregisterDraw3D(draw3d: Draw3DCompat): void;
    listDraw2Ds(): Draw2DCompat[];
    listDraw3Ds(): Draw3DCompat[];
    clearDraw2Ds(): void;
    clearDraw3Ds(): void;
    isContainer(): never;
    toString(): string;
    // Screens and textures exist and throw.
};

declare const FS: {
    list(path: string): Promise<string[] | null>;
    exists(path: string): Promise<boolean>;
    isDir(path: string): Promise<boolean>;
    isFile(path: string): Promise<boolean>;
    getName(path: string): string;
    getDir(path: string): string;
    combine(pathA: string, pathB: string): string;
    createFile(path: string, name: string, createDirs?: boolean): Promise<boolean>;
    makeDir(path: string): Promise<boolean>;
    move(from: string, to: string): Promise<void>;
    copy(from: string, to: string): Promise<void>;
    unlink(path: string): Promise<boolean>;
    open(path: string, charset?: string): FileHandlerCompat;
    walkFiles(path: string, maxDepth: number | undefined, followLinks: boolean, visitor: (path: string, attrs: { isDir: boolean; isFile: boolean; size: number; mtimeMs: number }) => void): Promise<void>;
    toString(): string;
    // Raw file/path handles and script-relative resolution exist and throw.
};

declare const GlobalVars: {
    putInt(name: string, value: number): number;
    putDouble(name: string, value: number): number;
    putString(name: string, value: string): string;
    putBoolean(name: string, value: boolean): boolean;
    putObject(name: string, value: unknown): never;
    getInt(name: string): number | null;
    getDouble(name: string): number | null;
    getString(name: string): string | null;
    getBoolean(name: string): boolean | null;
    getObject(name: string): unknown;
    getType(name: string): 'Int' | 'Double' | 'String' | 'Boolean' | 'Object' | null;
    getAndIncrementInt(name: string): number | null;
    getAndDecrementInt(name: string): number | null;
    incrementAndGetInt(name: string): number | null;
    decrementAndGetInt(name: string): number | null;
    toggleBoolean(name: string): boolean | null;
    remove(name: string): void;
    toString(): string;
};

declare const Request: {
    get(url: string, headers?: Record<string, string>): Promise<ResponseCompat>;
    post(url: string, data: string, headers?: Record<string, string>): Promise<ResponseCompat>;
    create(url: string): HttpRequestCompat;
    createWS(url: string): never;
    toString(): string;
};

declare const Reflection: {
    getClass(name: string, obfName?: string): unknown;
    getMethod(cls: unknown, name: string, ...paramTypes: unknown[]): unknown;
    getDeclaredMethod(cls: unknown, name: string, ...paramTypes: unknown[]): unknown;
    getField(cls: unknown, name: string): unknown;
    getDeclaredField(cls: unknown, name: string): unknown;
    invokeMethod(method: unknown, target: unknown, ...args: unknown[]): unknown;
    newInstance(cls: unknown, ...args: unknown[]): unknown;
    getClassName(value: unknown): string | undefined;
    toString(): string;
    // Class compilation and jar loading exist and throw.
};

declare const JavaUtils: {
    createArrayList(array?: unknown[]): unknown;
    createHashMap(map?: Record<string, unknown>): unknown;
    createHashSet(array?: unknown[]): unknown;
    arrayToString(array: unknown): string;
    arrayDeepToString(array: unknown): string;
    getRandom(seed?: number): unknown;
    toString(): string;
    // getHelperFromRaw exists and throws.
};

declare const JavaWrapper: {
    methodToJava(fn: (...args: unknown[]) => unknown): (...args: unknown[]) => unknown;
    methodToJavaAsync(fn: (...args: unknown[]) => unknown, priority?: number): (...args: unknown[]) => unknown;
    toString(): string;
    // Task-queue controls exist and throw.
};

declare const PositionCommon: {
    createPos(x: number, y: number): CompatPos2D;
    createPos(x: number, y: number, z: number): CompatPos3D;
    createVec(x1: number, y1: number, x2: number, y2: number): CompatVec2D;
    createVec(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number): CompatVec3D;
    createLookingVector(entity: EntityHelperCompat): CompatVec3D;
    createLookingVector(yaw: number, pitch: number): CompatVec3D;
    createBlockPos(x: number, y: number, z: number): CompatBlockPos;
    toString(): string;
};

declare const Utils: {
    encode(message: string): string;
    decode(message: string): string;
    getBase64String(text: string): string;
    getBase64Decoded(text: string): string;
    requireNonNull(obj: unknown, message?: string): unknown;
    toString(): string;
    // Clipboard, hashing, name guessing, and system-open helpers exist and
    // throw.
};

declare const Color: {
    argb(a: number, r: number, g: number, b: number): number;
    rgb(r: number, g: number, b: number): number;
    fromPacked(packed: number | bigint): number;
    alpha(color: number): number;
    red(color: number): number;
    green(color: number): number;
    blue(color: number): number;
    withAlpha(color: number, a: number): number;
    toString(): string;
};

// JsMacros injects `event`, `context`, and `file` into event-run files.
// NeoMacros runs scripts as modules; reading these globals throws with
// migration guidance (subscribe with JsMacros.on instead).
declare const event: never;
declare const context: never;
declare const file: never;
