# jsmacros-compat

[English](README.md)

在 [NeoMacros](../neomacros) 的 `neo` 之上重建 JsMacros 1.9.2 风格的脚本 API。旧的 JsMacros 风格代码（`Player.getPlayer()`、`JsMacros.on('Tick', ...)`）几乎无需修改即可在 NeoMacros 上运行。

独立项目，不分发任何 mod 代码，也不修改 NeoMacros 的任何仓库。

## 安装

把本目录复制进 NeoMacros 的脚本文件夹，在脚本开头：

```js
import './jsmacros-compat/src/index.js';
```

导入即自动安装（幂等）：完整全局面挂载完成（`JsMacros`、`Player`、`World`、`Chat`、`Client`、`Time`、`KeyBind`、`Hud`、`FS`、`GlobalVars`、`Request`、`Reflection`、`JavaUtils`、`JavaWrapper`、`PositionCommon`、`Utils`、`Color`）。

编辑器 / tsc 支持：把 [`types/jsmacros-compat.d.ts`](types/jsmacros-compat.d.ts) 加进 tsconfig。

## 覆盖范围

- **读取面**（同步、活句柄）：玩家/世界/实体/方块查询、`Chat.log/say/actionbar`、`Time.time()`、`KeyBind` 按键注入、`GlobalVars`（走 `neo.storage`）、实体帮助类 4 层主链 + 75 个专门化壳、背包面 + 16 个专门化壳、`Color`、`PositionCommon`、`Utils` 的 base64。
- **事件桥接**：`JsMacros.on/once/off/waitForEvent`，回调 `(event, context)` 形态，36 个已桥接事件名（含旧 `UPPER_SNAKE` 别名），逐事件 payload 适配器，自定义事件，JS 侧 filterer。
- **渲染**：`Hud.createDraw2D`（文本元素）与 `createDraw3D`（线框盒/线/点），保留 JsMacros register 生命周期，经持久的 `neo.hud` / `neo.render` 图层重建。
- **逃逸层**：`Reflection` 走 `neo.java`/`neo.reflect`、`JavaUtils` 集合构造、`Client.getMinecraft`——与 JsMacros 一样受 NeoMacros java 权限门控。

## 未覆盖范围

所有在 NeoMacros 中缺少/无法替代实现的 JsMacros API 成员都**保留原方法名、调用时抛 `UnimplementedError`**——绝不静默缺失。完整清单（类级 1,157 项、事件对象级 24 项、19 个不支持事件名、每项含原因）由 `node tools/audit.mjs` 生成到 [`docs/missing-apis.md`](docs/missing-apis.md)。

重点：包/收包事件（`RecvPacket`/`SendPacket`）、`Title`/`SignEdit`、背包事件（`ClickSlot` 系）、屏幕与纹理、声音/粒子播放、移动输入合成、实体写面（传送/速度/朝向）、破坏方块、服务器连接管理、WebSocket 客户端、运行时 Java 编译。

## 行为说明

### 同步 API 变为 Promise

NeoMacros 异步优先。以下 JsMacros 同步面保留签名但返回 Promise——请补 `await`：

| JsMacros 调用 | 兼容层返回 |
| --- | --- |
| `FS.*`（全部文件操作） | `Promise<...>` |
| `Request.get/post/create(url).get()` | `Promise<ResponseCompat>`（其 `text()/json()/byteArray()` 异步） |
| `Time.sleep(ms)` | `Promise<void>` |
| `Client.waitTick([n])`、`Client.runOnMainThread(fn, true)` | `Promise<void>` / `Promise<unknown>` |
| `Inventory.click/dropSlot/quick/swapHotbar/split/grabAll/closeAndDrop/close` | `Promise<void>` |
| `ClientPlayer.dropHeldItem`、交互管理器动作 | `Promise<void>` |

不 await 的 `FS.exists(p)` 在 `if` 中恒为真——请逐个迁移调用点。

### 其他文档化的偏差

见 [`docs/missing-apis.md`](docs/missing-apis.md) 第 8 节：FS 路径相对游戏目录（而非脚本文件夹）解析、实体读取是活句柄而非快照、显示名由 id 美化而来、`isDay/isNight` 用固定原版时间窗、带样式文本经旧式 § 代码渲染等。

## 开发

```sh
npm test    # node test/smoke.test.mjs - 20 项检查，含全表面交叉核对
npm run gen # 从 JsMacros API 索引重新生成 src/support/surface-data.js
npm run audit # 重新生成 docs/missing-apis.md 并重跑完备性门禁
```

冒烟套件对照 `tools/jsmacros-inventory.json`（官方 JsMacros 1.9.2 API 索引的机器提取）验证每个 JsMacros 全局/类表面成员都存在（实现或抛错 stub）。

布局：`src/support`（错误类型、stub 表、text/pos/block/item shim）、`src/globals`（每个 JsMacros 全局一个模块 + 事件桥接）、`test`（stub `neo` 之上 + 冒烟）、`tools`（索引提取器、表面生成器、审计器）、`types`（手写 d.ts）。

## 2026-11-06 回桥更新

以下成员从"抛错桩"升级为真实实现（对应 NeoMacros T-502~T-513 已落地面）：

- **World**：`getMoonPhase`、`getWorldIdentifier`、TPS 族（instant/1m/5m/15m）、`getTabListHeader/Footer`、`getPlayerEntry`、`getPlayers`、`getScoreboards`、`getBossBars`、`playSound`、`spawnParticle`、`findBlocksMatching`
- **Client**：`connect/disconnect/loadWorld/shutdown/exitGame*`、`ping/pingAsync/cancelAllPings`、`getLoadedMods/isModLoaded/getMod/getModLoader`、`isDevEnv`、`grabMouse`、剪贴板读写、`getGameOptions`（fov/gamma/guiScale/renderDistance 只读切片）、`getRegisteredBlocks/Items`
- **Player**：`getStatistics`、`getReach`、`isBreakingBlock`、`takeScreenshot`（返回 width/height/bytes）
- **Chat**：`title`、`toast`、`getTextWidth`
- **KeyBind**：`getKeyBindings`、`setKeyBind`、`getPressedKeys`
- **Hud**：`getOpenScreen/getOpenScreenName/isContainer`、窗口度量四件、鼠标坐标、`getScaleFactor`
- **Request**：`createWS/createWS2`（WebSocket）
- **JavaUtils**：`getHelperFromRaw`（经 `neo.java.wrap`）
- **Reflection**：`getWrappedClass/wrapInstace`（经 `neo.java.wrap`）

缺失计数 1341 → 约 1282。仍抛错的成员见 `docs/missing-apis.md`（audit 自动重生成）。

## 2026-11-06 容器回桥（T-510 第二批）

12 个容器特化壳从"全抛错"升级为桥接类（未落地成员仍由 fillStubs 补桩）：

- **FurnaceInventory**：`getInput/getFuel/getSmeltedItem/isBurning/getSmeltingProgress`
- **ContainerInventory**：`findFreeContainerSlot`
- **CraftingInventory**：`getInput/getInputSize/getOutput`（3x3 格 + 结果）
- **AnvilInventory**：`getLeftInput/getRightInput/getOutput/getItemRepairCost`
- **EnchantInventory**：`getItemToEnchant/getLapis/getEnchantmentLevels/getGoldCount`
- **GrindStoneInventory**：`getTopInput/getBottomInput/getOutput`
- **StoneCutterInventory**：`getInput/getAvailableRecipeCount/getSelectedRecipe`
- **SmithingInventory**：`getTemplate/getBase/getAddition/getOutput`
- **CartographyInventory**：`getMapItem/getMaterial/getOutput`
- **BeaconInventory**：`getPayment/getLevel/getFirstEffect/getSecondEffect`
- **BrewingStandInventory**：`getBottles/getIngredient/getFuel/getFuelCount/getBrewTime`
- **VillagerInventory**：`getLevel/getExperience/getLevelProgress`

计数 1282 → 1205。仍抛错的成员见 `docs/missing-apis.md`。
