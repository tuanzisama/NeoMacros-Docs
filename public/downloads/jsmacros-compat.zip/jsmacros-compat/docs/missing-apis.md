# jsmacros-compat 未实现 / 无法替代实现 API 清单

> 自动生成：`node tools/audit.mjs`（数据源 = 运行时 `__compatStub` 标记 + 事件适配器实例化 + `unimplemented()` 静态扫描 + 名称表）。
> 对比基线：JsMacros-CE 1.9.2（脚本可见 API 面，`tools/jsmacros-inventory.json`）。
> 规则：以下每一项都在兼容层中**保留原方法名**，触达时抛出 `UnimplementedError`，绝不静默缺失。
>
> 统计：全局/类级缺失成员 **1080 方法 + 77 属性**；事件对象级缺失成员 **4 方法 + 20 属性**；不支持事件名 **19**；手动补充条目 **4**。合计约 **1204** 项。

## 1. 全局库

### JsMacros

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FJsMacros.getProfile` | 方法 | NeoMacros has no profile concept |
| `FJsMacros.getConfig` | 方法 | NeoMacros exposes no config manager to scripts |
| `FJsMacros.getServiceManager` | 方法 | NeoMacros has no service system |
| `FJsMacros.getOpenContexts` | 方法 | NeoMacros does not expose script execution contexts |
| `FJsMacros.runScript` | 方法 | NeoMacros cannot spawn nested script runs |
| `FJsMacros.wrapScriptRun` | 方法 | NeoMacros cannot spawn nested script runs |
| `FJsMacros.wrapScriptRunAsync` | 方法 | NeoMacros cannot spawn nested script runs |
| `FJsMacros.open` | 方法 | deprecated in JsMacros and unavailable under NeoMacros |
| `FJsMacros.openUrl` | 方法 | deprecated in JsMacros and unavailable under NeoMacros |

### Player

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FPlayer.setGameMode` | 方法 | NeoMacros exposes no gamemode write |
| `FPlayer.writeSign` | 方法 | NeoMacros exposes no sign editing |
| `FPlayer.takePanorama` | 方法 | NeoMacros exposes no panorama capture |
| `FPlayer.createPlayerInput` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.createPlayerInputsFromCsv` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.createPlayerInputsFromJson` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.getCurrentPlayerInput` | 方法 | NeoMacros exposes no movement input introspection |
| `FPlayer.addInput` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.addInputs` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.clearInputs` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.setDrawPredictions` | 方法 | NeoMacros exposes no movement prediction |
| `FPlayer.predictInput` | 方法 | NeoMacros exposes no movement prediction |
| `FPlayer.predictInputs` | 方法 | NeoMacros exposes no movement prediction |
| `FPlayer.moveForward` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.moveBackward` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.moveStrafeLeft` | 方法 | NeoMacros exposes no movement input synthesis |
| `FPlayer.moveStrafeRight` | 方法 | NeoMacros exposes no movement input synthesis |

### World

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FWorld.getEntitiesInternal` | 方法 | internal JsMacros entity enumeration variant |
| `FWorld.getWorldScanner` | 方法 | NeoMacros has no world scanner |
| `FWorld.getRespawnPos` | 方法 | NeoMacros exposes no respawn position query |
| `FWorld.getSkyLight` | 方法 | NeoMacros exposes no light level queries |
| `FWorld.getBlockLight` | 方法 | NeoMacros exposes no light level queries |
| `FWorld.playSoundFile` | 方法 | NeoMacros exposes no sound playback |
| `FWorld.getRaw` | 方法 | raw host world access needs the java escape layer |

### Chat

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FChat.logInternal` | 方法 | internal JsMacros chat dispatch variant |
| `FChat.sayInternal` | 方法 | internal JsMacros chat dispatch variant |
| `FChat.open` | 方法 | NeoMacros cannot open the chat input |
| `FChat.getLogger` | 方法 | NeoMacros exposes no logger factory |
| `FChat.createCommandBuilder` | 方法 | deprecated in JsMacros; use the script-side command system of NeoMacros (neo.command) |
| `FChat.unregisterCommand` | 方法 | deprecated in JsMacros; use the script-side command system of NeoMacros (neo.command) |
| `FChat.reRegisterCommand` | 方法 | deprecated in JsMacros; use the script-side command system of NeoMacros (neo.command) |

### Client

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FClient.sendPacket` | 方法 | NeoMacros exposes no packet-level access |
| `FClient.receivePacket` | 方法 | NeoMacros exposes no packet-level access |
| `FClient.getRegistryManager` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `FClient.createPacketByteBuffer` | 方法 | NeoMacros exposes no packet buffer utilities |

### KeyBind

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FKeyBind.getKeyCode` | 方法 | NeoMacros exposes no raw key code objects |

### Hud

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FHud.createScreen` | 方法 | NeoMacros cannot create screens |
| `FHud.openScreen` | 方法 | NeoMacros cannot open or close screens |
| `FHud.createTexture` | 方法 | NeoMacros exposes no texture registry |
| `FHud.getRegisteredTextures` | 方法 | NeoMacros exposes no texture registry |

### FS

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FFS.toRelativePath` | 方法 | NeoMacros exposes no script-folder root to resolve against |
| `FFS.toRawFile` | 方法 | NeoMacros exposes no raw java.io.File handles |
| `FFS.toRawPath` | 方法 | NeoMacros exposes no raw java.nio.Path handles |
| `FFS.getRawAttributes` | 方法 | NeoMacros exposes no raw file attributes |

### GlobalVars

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FGlobalVars.getRaw` | 方法 | NeoMacros storage has no enumerate-all operation |

### Reflection

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FReflection.getAllCompiledJavaClassVersions` | 方法 | NeoMacros cannot compile Java sources |
| `FReflection.getClassFromClassBuilderResult` | 方法 | NeoMacros cannot compile Java sources |
| `FReflection.getCompiledJavaClass` | 方法 | NeoMacros cannot compile Java sources |
| `FReflection.loadCurrentMappingHelper` | 方法 | NeoMacros exposes no mapping helpers |
| `FReflection.loadMappingHelper` | 方法 | NeoMacros exposes no mapping helpers |
| `FReflection.createClassProxyBuilder` | 方法 | NeoMacros has no dynamic class proxying beyond neo.java.proxy handler maps |
| `FReflection.createClassBuilder` | 方法 | NeoMacros has no runtime class generation |
| `FReflection.createLibraryBuilder` | 方法 | NeoMacros has no runtime library generation |
| `FReflection.createLibrary` | 方法 | NeoMacros has no runtime class generation |
| `FReflection.compileJavaClass` | 方法 | NeoMacros cannot compile Java sources |
| `FReflection.loadJarFile` | 方法 | NeoMacros cannot load jars at runtime |
| `FReflection.getReflect` | 方法 | NeoMacros exposes no per-object reflection helper |

### JavaWrapper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FWrapper.deferCurrentTask` | 方法 | NeoMacros exposes no script-thread task queue control |
| `FWrapper.getCurrentPriority` | 方法 | NeoMacros exposes no script-thread task queue control |
| `FWrapper.stop` | 方法 | NeoMacros exposes no script-thread task queue control |

### Utils

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FUtils.getClipboard` | 方法 | NeoMacros exposes no clipboard access |
| `FUtils.setClipboard` | 方法 | NeoMacros exposes no clipboard access |
| `FUtils.copyToClipboard` | 方法 | NeoMacros exposes no clipboard access |
| `FUtils.getHash` | 方法 | NeoMacros exposes no synchronous digest; hashing needs the java escape layer |
| `FUtils.hashString` | 方法 | NeoMacros exposes no synchronous digest; hashing needs the java escape layer |
| `FUtils.guessName` | 方法 | NeoMacros exposes no account introspection |
| `FUtils.guessNameAndRoles` | 方法 | NeoMacros exposes no account introspection |
| `FUtils.open` | 方法 | deprecated in JsMacros and unavailable under NeoMacros |
| `FUtils.openUrl` | 方法 | NeoMacros cannot open system URLs |
| `FUtils.openFile` | 方法 | NeoMacros cannot open system files |

## 2. 实体基类（4 层主链 + ItemEntity）

### EntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EntityHelper.create` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.getAir` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.getChunk` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.getGlowingColor` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.getMaxAir` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.getNBT` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.getSpeed` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.isGlowing` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.resetGlowing` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.resetGlowingColor` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.setCustomName` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.setCustomNameVisible` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.setGlowing` | 方法 | entity state or write action not exposed by the neo entity surface |
| `EntityHelper.setGlowingColor` | 方法 | entity state or write action not exposed by the neo entity surface |

### LivingEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `LivingEntityHelper.canBreatheInWater` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.canHaveStatusEffect` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.canSeeEntity` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.canTakeDamage` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.canTarget` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getAbsorptionHealth` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getArmor` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getBowPullProgress` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getChestArmor` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getDefaultHealth` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getFootArmor` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getHeadArmor` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getItemUseTimeLeft` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getLegArmor` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getMobTags` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.getStatusEffects` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.hasNoDrag` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.hasNoGravity` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.hasStatusEffect` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.isBaby` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.isPartOfGame` | 方法 | living entity state not exposed by the neo entity surface |
| `LivingEntityHelper.isUndead` | 方法 | living entity state not exposed by the neo entity surface |

### PlayerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PlayerEntityHelper.getAbilities` | 方法 | player state not exposed by the neo player surface |
| `PlayerEntityHelper.getAttackCooldownProgress` | 方法 | player state not exposed by the neo player surface |
| `PlayerEntityHelper.getAttackCooldownProgressPerTick` | 方法 | player state not exposed by the neo player surface |
| `PlayerEntityHelper.getFishingBobber` | 方法 | player state not exposed by the neo player surface |
| `PlayerEntityHelper.getScore` | 方法 | player state not exposed by the neo player surface |
| `PlayerEntityHelper.getXPToLevelUp` | 方法 | player state not exposed by the neo player surface |
| `PlayerEntityHelper.isSleepingLongEnough` | 方法 | player state not exposed by the neo player surface |

### ClientPlayerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ClientPlayerEntityHelper.addPos` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.addVelocity` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.calculateMiningSpeed` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.getAdvancementManager` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.getItemCooldownRemainingTicks` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.getItemCooldownsRemainingTicks` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.getTicksSinceCooldownStart` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.getTicksSinceCooldownsStart` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.interact` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.interactItem` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.lookAt` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.setLongAttack` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.setLongInteract` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.setPos` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.setVelocity` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.tryLookAt` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.turnBack` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.turnLeft` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.turnRight` | 方法 | local player write action not exposed by the neo player surface |
| `ClientPlayerEntityHelper.mc` | 属性 | local player write action not exposed by the neo player surface |

### ItemEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ItemEntityHelper.getContainedItemStack` | 方法 | dropped item state not exposed by the neo entity surface |

## 3. 实体专门化壳类（逐类逐方法）

### ArmorStandEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ArmorStandEntityHelper.getBodyRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.getHeadRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.getLeftArmRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.getLeftLegRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.getRightArmRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.getRightLegRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.hasArms` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.hasBasePlate` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.isMarker` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.isSmall` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.isVisible` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArmorStandEntityHelper.toArray` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ArrowEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ArrowEntityHelper.getColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArrowEntityHelper.getPiercingLevel` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArrowEntityHelper.isCritical` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ArrowEntityHelper.isShotFromCrossbow` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### AreaEffectCloudEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AreaEffectCloudEntityHelper.getColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AreaEffectCloudEntityHelper.getParticleType` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AreaEffectCloudEntityHelper.getRadius` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AreaEffectCloudEntityHelper.isWaiting` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### BoatEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BoatEntityHelper.getBoatBlockType` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.getBoatType` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.getLocation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.isChestBoat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.isInAir` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.isInWater` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.isOnLand` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BoatEntityHelper.isUnderwater` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### DisplayEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `DisplayEntityHelper.getBillboardMode` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getBlockBrightness` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getBrightness` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getDisplayHeight` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getDisplayWidth` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getGlowColorOverride` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getLerpProgress` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getLerpTargetPitch` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getLerpTargetX` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getLerpTargetY` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getLerpTargetYaw` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getLerpTargetZ` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getShadowRadius` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getShadowStrength` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getSkyBrightness` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getViewRange` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DisplayEntityHelper.getVisibilityBoundingBox` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### EndCrystalEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EndCrystalEntityHelper.getBeamTarget` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `EndCrystalEntityHelper.isNatural` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### FallingBlockEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FallingBlockEntityHelper.getBlockState` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FallingBlockEntityHelper.getOriginBlockPos` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### FishingBobberEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FishingBobberEntityHelper.getHookedEntity` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FishingBobberEntityHelper.hasCaughtFish` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FishingBobberEntityHelper.hasEntityHooked` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FishingBobberEntityHelper.isInOpenWater` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### FurnaceMinecartEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FurnaceMinecartEntityHelper.isPowered` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### InteractionEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `InteractionEntityHelper.getHeight` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `InteractionEntityHelper.getLastAttacker` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `InteractionEntityHelper.getLastInteracted` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `InteractionEntityHelper.getWidth` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `InteractionEntityHelper.setCanHit` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `InteractionEntityHelper.shouldRespond` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ItemDisplayEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ItemDisplayEntityHelper.getItem` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ItemDisplayEntityHelper.getTransform` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ItemFrameEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ItemFrameEntityHelper.getItem` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ItemFrameEntityHelper.getRotation` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ItemFrameEntityHelper.isGlowingFrame` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### MerchantEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `MerchantEntityHelper.getExperience` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `MerchantEntityHelper.getTrades` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `MerchantEntityHelper.hasCustomer` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `MerchantEntityHelper.refreshTrades` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### MobEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `MobEntityHelper.isAiDisabled` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `MobEntityHelper.isAttacking` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PaintingEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PaintingEntityHelper.getHeight` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PaintingEntityHelper.getIdentifier` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PaintingEntityHelper.getWidth` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PhantomEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PhantomEntityHelper.getSize` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ShulkerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ShulkerEntityHelper.getAttachedSide` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ShulkerEntityHelper.getColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ShulkerEntityHelper.isClosed` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### SlimeEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `SlimeEntityHelper.getSize` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `SlimeEntityHelper.isSmall` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### SnowGolemEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `SnowGolemEntityHelper.hasPumpkin` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `SnowGolemEntityHelper.isShearable` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### SpiderEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `SpiderEntityHelper.isClimbing` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### TextDisplayEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TextDisplayEntityHelper.getData` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### TntEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TntEntityHelper.getRemainingTime` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### TntMinecartEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TntMinecartEntityHelper.getRemainingTime` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TntMinecartEntityHelper.isPrimed` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### TridentEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TridentEntityHelper.hasLoyalty` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TridentEntityHelper.isEnchanted` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### VexEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `VexEntityHelper.isCharging` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### VillagerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `VillagerEntityHelper.getLevel` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `VillagerEntityHelper.getProfession` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `VillagerEntityHelper.getStyle` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### WardenEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `WardenEntityHelper.getAnger` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WardenEntityHelper.isChargingSonicBoom` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WardenEntityHelper.isDigging` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WardenEntityHelper.isEmerging` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WardenEntityHelper.isRoaring` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WardenEntityHelper.isSniffing` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### WitchEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `WitchEntityHelper.getPotion` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WitchEntityHelper.isDrinkingPotion` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### WitherEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `WitherEntityHelper.getRemainingInvulnerableTime` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WitherEntityHelper.isFirstPhase` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WitherEntityHelper.isInvulnerable` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WitherEntityHelper.isSecondPhase` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### WitherSkullEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `WitherSkullEntityHelper.isCharged` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ZombieEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ZombieEntityHelper.isConvertingToDrowned` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ZombieVillagerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ZombieVillagerEntityHelper.getLevel` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ZombieVillagerEntityHelper.getProfession` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ZombieVillagerEntityHelper.getVillagerBiomeType` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ZombieVillagerEntityHelper.isConvertingToVillager` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### AbstractPiglinEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AbstractPiglinEntityHelper.canBeZombified` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### AllayEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AllayEntityHelper.canDuplicate` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AllayEntityHelper.isDancing` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AllayEntityHelper.isHoldingItem` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### AnimalEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AnimalEntityHelper.canBreedWith` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AnimalEntityHelper.isFood` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### AxolotlEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AxolotlEntityHelper.getVariantId` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AxolotlEntityHelper.getVariantName` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AxolotlEntityHelper.isFromBucket` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AxolotlEntityHelper.isPlayingDead` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### BatEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BatEntityHelper.isResting` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### BeeEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BeeEntityHelper.hasNectar` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BeeEntityHelper.hasStung` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `BeeEntityHelper.isAngry` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### BlockDisplayEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BlockDisplayEntityHelper.getBlockState` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### CreeperEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `CreeperEntityHelper.getFuseChange` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `CreeperEntityHelper.getFuseTime` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `CreeperEntityHelper.getMaxFuseTime` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `CreeperEntityHelper.getRemainingFuseTime` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `CreeperEntityHelper.isCharged` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `CreeperEntityHelper.isIgnited` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### DolphinEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `DolphinEntityHelper.getMoistness` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DolphinEntityHelper.getTreasurePos` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DolphinEntityHelper.hasFish` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### DrownedEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `DrownedEntityHelper.hasNautilusShell` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `DrownedEntityHelper.hasTrident` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### EnderDragonEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EnderDragonEntityHelper.getBodyPart` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `EnderDragonEntityHelper.getBodyParts` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `EnderDragonEntityHelper.getPhase` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### EndermanEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EndermanEntityHelper.getHeldBlock` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `EndermanEntityHelper.isHoldingBlock` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `EndermanEntityHelper.isProvoked` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `EndermanEntityHelper.isScreaming` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### FishEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FishEntityHelper.isFromBucket` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### FoxEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FoxEntityHelper.canTrust` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.getItemInMouth` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.getOwner` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.getSecondOwner` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.getTrustedUUIDs` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.hasFoundTarget` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isDefending` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isJumping` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isPouncing` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isRedFox` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isSitting` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isSnowFox` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FoxEntityHelper.isWandering` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### FrogEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FrogEntityHelper.getTarget` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FrogEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `FrogEntityHelper.isCroaking` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### GhastEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `GhastEntityHelper.isShooting` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### GoatEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `GoatEntityHelper.hasHorns` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `GoatEntityHelper.hasLeftHorn` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `GoatEntityHelper.hasRightHorn` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `GoatEntityHelper.isScreaming` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### GuardianEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `GuardianEntityHelper.getTarget` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `GuardianEntityHelper.hasSpikesRetracted` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `GuardianEntityHelper.hasTarget` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `GuardianEntityHelper.isElder` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### IllagerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `IllagerEntityHelper.getState` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `IllagerEntityHelper.isCelebrating` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### IronGolemEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `IronGolemEntityHelper.isPlayerCreated` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### MooshroomEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `MooshroomEntityHelper.isBrown` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `MooshroomEntityHelper.isRed` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `MooshroomEntityHelper.isShearable` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### OcelotEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `OcelotEntityHelper.isTrusting` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PandaEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PandaEntityHelper.getHiddenGene` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.getHiddenGeneName` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.getMainGene` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.getMainGeneName` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isBrown` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isHiddenGeneRecessive` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isIdle` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isLazy` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isLyingOnBack` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isMainGeneRecessive` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isPlayful` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isPlaying` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isScaredByThunderstorm` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isSitting` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isSneezing` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isWeak` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PandaEntityHelper.isWorried` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PigEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PigEntityHelper.isSaddled` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PiglinEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PiglinEntityHelper.hasCrossbowReady` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PiglinEntityHelper.isAdmiring` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PiglinEntityHelper.isChargingCrossbow` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PiglinEntityHelper.isDancing` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PiglinEntityHelper.isMeleeAttacking` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `PiglinEntityHelper.isWandering` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PillagerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PillagerEntityHelper.isCaptain` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### PufferfishEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PufferfishEntityHelper.getSize` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### RabbitEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `RabbitEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `RabbitEntityHelper.isKillerBunny` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### SheepEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `SheepEntityHelper.getColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `SheepEntityHelper.isJeb` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `SheepEntityHelper.isShearable` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `SheepEntityHelper.isSheared` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### SpellcastingIllagerEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `SpellcastingIllagerEntityHelper.getCastedSpell` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `SpellcastingIllagerEntityHelper.isCastingSpell` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### StriderEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `StriderEntityHelper.isSaddled` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `StriderEntityHelper.isShivering` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### TameableEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TameableEntityHelper.getOwner` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TameableEntityHelper.isOwner` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TameableEntityHelper.isSitting` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TameableEntityHelper.isTamed` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### TropicalFishEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TropicalFishEntityHelper.getBaseColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TropicalFishEntityHelper.getPatternColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TropicalFishEntityHelper.getSize` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TropicalFishEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `TropicalFishEntityHelper.getVarietyId` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### VindicatorEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `VindicatorEntityHelper.isJohnny` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### WolfEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `WolfEntityHelper.getCollarColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WolfEntityHelper.isAngry` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WolfEntityHelper.isBegging` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `WolfEntityHelper.isWet` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### AbstractHorseEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AbstractHorseEntityHelper.canBeSaddled` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.canWearArmor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getHealthStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getHorseJumpHeight` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getHorseSpeed` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getInventorySize` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getJumpStrengthStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getMaxHealthStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getMaxJumpStrengthStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getMaxSpeedStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getMinHealthStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getMinJumpStrengthStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getMinSpeedStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getOwner` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.getSpeedStat` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.isAngry` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.isBred` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.isEating` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.isSaddled` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `AbstractHorseEntityHelper.isTame` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### CatEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `CatEntityHelper.getCollarColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `CatEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### DonkeyEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `DonkeyEntityHelper.hasChest` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### HorseEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `HorseEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### LlamaEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `LlamaEntityHelper.getCarpetColor` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `LlamaEntityHelper.getStrength` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `LlamaEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `LlamaEntityHelper.isTraderLlama` | 方法 | specialized entity state has no equivalent in the neo entity surface |

### ParrotEntityHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ParrotEntityHelper.getVariant` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ParrotEntityHelper.isFlying` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ParrotEntityHelper.isPartying` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ParrotEntityHelper.isSittingOnShoulder` | 方法 | specialized entity state has no equivalent in the neo entity surface |
| `ParrotEntityHelper.isStanding` | 方法 | specialized entity state has no equivalent in the neo entity surface |

## 4. 背包类

### Inventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `Inventory.create` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.dragClick` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.findFreeHotbarSlot` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.findFreeInventorySlot` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getCurrentSyncId` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getHeld` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getLocation` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getMap` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getMapInternal` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getRawContainer` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getSelectedHotbarSlotIndex` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getSlotPos` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getSlotUnderMouse` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.getSlots` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.openGui` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.quickAll` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.setSelectedHotbarSlotIndex` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.swap` | 方法 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.handler` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.inventory` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.man` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.map` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.mc` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.player` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |
| `Inventory.syncId` | 属性 | cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface |

### RecipeInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `RecipeInventory.getCategory` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getCraftableRecipes` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getCraftingHeight` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getCraftingSlotCount` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getCraftingWidth` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getInput` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getInputSize` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getOutput` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getRecipeBookWidget` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.getRecipes` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.isRecipeBookOpened` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.setRecipeBook` | 方法 | recipe-book state is not exposed by the neo Inventory surface |
| `RecipeInventory.toggleRecipeBook` | 方法 | recipe-book state is not exposed by the neo Inventory surface |

### PlayerInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PlayerInventory.getBoots` | 方法 | armor/offhand/crafting slot layout is not exposed by the neo Inventory surface |
| `PlayerInventory.getChestplate` | 方法 | armor/offhand/crafting slot layout is not exposed by the neo Inventory surface |
| `PlayerInventory.getHelmet` | 方法 | armor/offhand/crafting slot layout is not exposed by the neo Inventory surface |
| `PlayerInventory.getLeggings` | 方法 | armor/offhand/crafting slot layout is not exposed by the neo Inventory surface |
| `PlayerInventory.getOffhand` | 方法 | armor/offhand/crafting slot layout is not exposed by the neo Inventory surface |
| `PlayerInventory.isInHotbar` | 方法 | armor/offhand/crafting slot layout is not exposed by the neo Inventory surface |

### FurnaceInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FurnaceInventory.canUseAsFuel` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.getFuelValues` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.getPropertyDelegate` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.getRemainingFuelTime` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.getRemainingSmeltingTime` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.getTotalFuelTime` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.getTotalSmeltingTime` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `FurnaceInventory.isSmeltable` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### AnvilInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `AnvilInventory.getLevelCost` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `AnvilInventory.getMaximumLevelCost` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `AnvilInventory.getName` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `AnvilInventory.setName` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### EnchantInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EnchantInventory.doEnchant` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `EnchantInventory.getEnchantmentHelpers` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `EnchantInventory.getEnchantmentIds` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `EnchantInventory.getEnchantments` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `EnchantInventory.getRequiredLevels` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### VillagerInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `VillagerInventory.canRefreshTrades` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `VillagerInventory.getMerchantRewardedExperience` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `VillagerInventory.isLeveled` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `VillagerInventory.selectTrade` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### BeaconInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BeaconInventory.applyEffects` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BeaconInventory.selectFirstEffect` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BeaconInventory.selectSecondEffect` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### BrewingStandInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BrewingStandInventory.canBrewCurrentInput` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.getFirstPotion` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.getMaxFuelUses` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.getPotions` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.getRemainingTicks` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.getSecondPotion` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.getThirdPotion` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.isBrewablePotion` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.isValidIngredient` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.isValidRecipe` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.previewPotion` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `BrewingStandInventory.previewPotions` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### GrindStoneInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `GrindStoneInventory.getExperience` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `GrindStoneInventory.simulateXp` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### HorseInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `HorseInventory.canBeSaddled` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.getHorse` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.getHorseInventory` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.getInventorySize` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.hasArmorSlot` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.hasChest` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.isSaddled` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `HorseInventory.horse` | 属性 | specialized inventory feature is not exposed by the neo Inventory surface |

### LoomInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `LoomInventory.getPatternsFor` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `LoomInventory.listAvailablePatterns` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `LoomInventory.selectPattern` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `LoomInventory.selectPatternId` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `LoomInventory.selectPatternName` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### SmithingInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `SmithingInventory.getLeftInput` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `SmithingInventory.getRightInput` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### StoneCutterInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `StoneCutterInventory.canCraft` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `StoneCutterInventory.getOutput` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `StoneCutterInventory.getRecipes` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `StoneCutterInventory.getSelectedRecipeIndex` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `StoneCutterInventory.selectRecipe` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

### CreativeInventory

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `CreativeInventory.destroyAllItems` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.destroyHeldItem` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getBoots` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getChestplate` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getHelmet` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getLeggings` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getOffhand` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getSavedHotbar` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getShownItems` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getTabNames` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.getTabTexts` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.isInHotbar` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.restoreHotbar` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.saveHotbar` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.scroll` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.scrollTo` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.search` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.selectHotbar` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.selectInventory` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.selectSearch` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.selectTab` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.setCursorStack` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |
| `CreativeInventory.setStack` | 方法 | specialized inventory feature is not exposed by the neo Inventory surface |

## 5. 其他支持类

### TextHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TextHelper.getWidth` | 方法 | not backed by the NeoMacros text pipeline |
| `TextHelper.wrap` | 方法 | not backed by the NeoMacros text pipeline |
| `TextHelper.STRIP_FORMATTING_PATTERN` | 属性 | not backed by the NeoMacros text pipeline |
| `TextHelper.mc` | 属性 | not backed by the NeoMacros text pipeline |

### TextBuilder

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `TextBuilder.appendInternal` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.getWidth` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.withClickEvent` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.withCustomClickEvent` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.withShowEntityHover` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.withShowItemHover` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.withShowTextHover` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.withStyle` | 方法 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.head` | 属性 | hover and click styling has no NeoMacros chat equivalent |
| `TextBuilder.self` | 属性 | hover and click styling has no NeoMacros chat equivalent |

### Pos2D

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `Pos2D.ZERO` | 属性 | no NeoMacros equivalent |

### Pos3D

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `Pos3D.toMojangDoubleVector` | 方法 | no NeoMacros equivalent |
| `Pos3D.toRawBlockPos` | 方法 | no NeoMacros equivalent |

### Vec2D

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `Vec2D.compareTo` | 方法 | no NeoMacros equivalent |

### BlockDataHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BlockDataHelper.getBlockHelper` | 方法 | no equivalent in the neo block surface |
| `BlockDataHelper.getBlockState` | 方法 | no equivalent in the neo block surface |
| `BlockDataHelper.getNBT` | 方法 | no equivalent in the neo block surface |
| `BlockDataHelper.getRawBlock` | 方法 | no equivalent in the neo block surface |
| `BlockDataHelper.getRawBlockEntity` | 方法 | no equivalent in the neo block surface |
| `BlockDataHelper.getRawBlockState` | 方法 | no equivalent in the neo block surface |
| `BlockDataHelper.b` | 属性 | no equivalent in the neo block surface |
| `BlockDataHelper.bp` | 属性 | no equivalent in the neo block surface |
| `BlockDataHelper.e` | 属性 | no equivalent in the neo block surface |
| `BlockDataHelper.mc` | 属性 | no equivalent in the neo block surface |

### BlockStateHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BlockStateHelper.allowsSpawning` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.blocksMovement` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.create` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.emitsRedstonePower` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.exceedsCube` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.getBlock` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.getFluidState` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.getHardness` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.getLuminance` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.getPistonBehaviour` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.getUniversal` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.hasBlockEntity` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.hasComparatorOutput` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.hasRandomTicks` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.isBurnable` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.isOpaque` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.isReplaceable` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.isSolid` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.isToolRequired` | 方法 | state physics and light properties are not exposed by the neo block surface |
| `BlockStateHelper.shouldSuffocate` | 方法 | state physics and light properties are not exposed by the neo block surface |

### ChunkHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ChunkHelper.containsAll` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.containsAny` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.forEach` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getBiome` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getChunkX` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getChunkZ` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getEntities` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getHeight` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getHeightmaps` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getInhabitedTime` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getMaxBuildHeight` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getMinBuildHeight` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getMotionBlockingHeightmap` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getMotionBlockingNoLeavesHeightmap` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getOceanFloorHeightmap` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getOffsetBlock` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getStartingBlock` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getSurfaceHeightmap` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getTileEntities` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |
| `ChunkHelper.getTopYAt` | 方法 | NeoMacros exposes no chunk query surface beyond loaded checks |

### ItemStackHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ItemStackHelper.areEnchantmentsHidden` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.areModifiersHidden` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.canBeApplied` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getAttackDamage` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getCooldownProgress` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getCreative` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getCreativeTab` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getDestroyRestrictions` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getMaxCount` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getNBT` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getPlaceRestrictions` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getPossibleEnchantments` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getPossibleEnchantmentsFromTable` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getRepairCost` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.getTags` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.hasDestroyRestrictions` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.hasPlaceRestrictions` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isCanDestroyHidden` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isCanPlaceHidden` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isDamageable` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isDyeHidden` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isEnchantable` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isEnchanted` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isFood` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isOnCooldown` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isSuitableFor` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isTool` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isUnbreakable` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isUnbreakableHidden` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.isWearable` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.setDamage` | 方法 | not exposed by the neo item stack surface |
| `ItemStackHelper.LORE_STYLE` | 属性 | not exposed by the neo item stack surface |
| `ItemStackHelper.mc` | 属性 | not exposed by the neo item stack surface |

### HitResultHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `HitResultHelper.asBlock` | 方法 | block/entity resolution helpers are not exposed by the neo raycast surface |
| `HitResultHelper.asEntity` | 方法 | block/entity resolution helpers are not exposed by the neo raycast surface |
| `HitResultHelper.resolve` | 方法 | block/entity resolution helpers are not exposed by the neo raycast surface |

### InteractionManagerHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `InteractionManagerHelper.breakBlock` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.breakBlockAsync` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.cancelBreakBlock` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.checkBase` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.checkInstaBreak` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.clearTargetOverride` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.getTarget` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.hasBreakBlockOverride` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.hasInteractOverride` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.hasTargetOverride` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.holdInteract` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.interact` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.interactItem` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.isBreakingBlock` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.preBreakBlock` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.resetTargetChecks` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.setGameMode` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.setTarget` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.setTargetAirCheck` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.setTargetMissed` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.setTargetRangeCheck` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.setTargetShapeCheck` | 方法 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.autoUpdateBase` | 属性 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |
| `InteractionManagerHelper.mc` | 属性 | block breaking, held interactions, and targeting overrides have no NeoMacros equivalent |

### Draw2D

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `Draw2D.addDraw2D` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.addImage` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.addItem` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.addLine` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.addRect` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getDraw2Ds` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getElementsByZIndex` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getHeight` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getImages` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getItems` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getLines` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getRects` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getTexts` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getWidth` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.getZIndex` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.hasCyclicDependencies` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.init` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.removeDraw2D` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.removeImage` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.removeItem` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.removeLine` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.removeRect` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.removeText` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.render` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.setZIndex` | 方法 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.catchInit` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.elements` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.heightSupplier` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.mc` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.onInit` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.visible` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.widthSupplier` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |
| `Draw2D.zIndex` | 属性 | rect, line, image, item, and nested-2D elements have no neo.hud equivalent |

### Draw3D

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `Draw3D.addDraw2D` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.addEntityTraceLine` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.addSurface` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.addTraceLine` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.boxBuilder` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.entityTraceLineBuilder` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.lineBuilder` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.reAddElement` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.removeDraw2D` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.removeTraceLine` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.render` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.surfaceBuilder` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.traceLineBuilder` | 方法 | trace lines and in-world surfaces have no neo.render equivalent |
| `Draw3D.elements` | 属性 | trace lines and in-world surfaces have no neo.render equivalent |

### FileHandler

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `FileHandler.getFile` | 方法 | stream and raw-file access are not exposed by neo.fs |
| `FileHandler.streamBytes` | 方法 | stream and raw-file access are not exposed by neo.fs |
| `FileHandler.charset` | 属性 | stream and raw-file access are not exposed by neo.fs |
| `FileHandler.f` | 属性 | stream and raw-file access are not exposed by neo.fs |

### HTTPRequest

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `HTTPRequest.conn` | 属性 | timeout tuning and raw connection access are not exposed by neo.net |
| `HTTPRequest.connectTimeout` | 属性 | timeout tuning and raw connection access are not exposed by neo.net |
| `HTTPRequest.gson` | 属性 | timeout tuning and raw connection access are not exposed by neo.net |
| `HTTPRequest.readTimeout` | 属性 | timeout tuning and raw connection access are not exposed by neo.net |

### HTTPRequest.Response

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `HTTPRequest.Response.raw` | 属性 | raw header-list and connection details are not exposed by neo.net responses |

### CommandManager

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `CommandManager.createCommandBuilder` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandManager.getArgumentAutocompleteOptions` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandManager.getValidCommands` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandManager.reRegisterCommand` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandManager.unregisterCommand` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandManager.instance` | 属性 | chat history and command management are not exposed by NeoMacros |
| `CommandManager.mc` | 属性 | chat history and command management are not exposed by NeoMacros |

### CommandBuilder

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `CommandBuilder.angleArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.argument` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.blockArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.blockPosArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.blockPredicateArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.blockStateArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.booleanArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.colorArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.columnPosArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.dimensionArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.doubleArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.executes` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.floatRangeArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.greedyStringArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.identifierArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.intArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.intRangeArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.internalExecutes` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.itemArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.itemPredicateArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.itemSlotArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.itemStackArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.literalArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.longArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.nbtArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.nbtCompoundArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.nbtElementArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.or` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.otherwise` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.particleArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.quotedStringArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.regexArgType` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.register` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.suggest` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.suggestBlockPositions` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.suggestIdentifier` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.suggestMatching` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.suggestPositions` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.suggests` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.textArgType` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.timeArg` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.unregister` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.uuidArgType` | 方法 | chat history and command management are not exposed by NeoMacros |
| `CommandBuilder.wordArg` | 方法 | chat history and command management are not exposed by NeoMacros |

### ChatHistoryManager

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ChatHistoryManager.clearRecv` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.clearSent` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.getRecvCount` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.getRecvLine` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.getRecvLines` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.getSent` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.insertRecvText` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.refreshVisible` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.removeRecvText` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.removeRecvTextMatching` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.removeRecvTextMatchingFilter` | 方法 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.hud` | 属性 | chat history and command management are not exposed by NeoMacros |
| `ChatHistoryManager.mc` | 属性 | chat history and command management are not exposed by NeoMacros |

### ScriptScreen

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ScriptScreen.close` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.init` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.render` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.setOnRender` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.setParent` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.shouldCloseOnEsc` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.shouldPause` | 方法 | NeoMacros cannot create or control screens |
| `ScriptScreen.bgStyle` | 属性 | NeoMacros cannot create or control screens |
| `ScriptScreen.drawTitle` | 属性 | NeoMacros cannot create or control screens |
| `ScriptScreen.onRender` | 属性 | NeoMacros cannot create or control screens |

### IScreen

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `IScreen.addButton` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.addCheckbox` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.addCyclingButton` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.addLockButton` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.addSlider` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.addTextInput` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.buttonBuilder` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.checkBoxBuilder` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.close` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.cyclicButtonBuilder` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.getButtonWidgets` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.getOnClose` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.getScreenClassName` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.getTextFields` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.getTitleText` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.isAltDown` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.isCtrlDown` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.isShiftDown` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.lockButtonBuilder` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.reloadScreen` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.removeButton` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.removeTextInput` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnCharTyped` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnClose` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnKeyPressed` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnMouseDown` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnMouseDrag` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnMouseUp` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.setOnScroll` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.sliderBuilder` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.textFieldBuilder` | 方法 | NeoMacros cannot create or control screens |
| `IScreen.texturedButtonBuilder` | 方法 | NeoMacros cannot create or control screens |

### CustomImage

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `CustomImage.clearRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.clipRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.copyArea` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.createTexture` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.createWidget` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.draw3DRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawArc` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawImage` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawLine` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawOval` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawPolygon` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawPolygonLine` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawRoundRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.drawString` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.fill3DRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.fillArc` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.fillOval` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.fillPolygon` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.fillRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.fillRoundRect` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getClipBounds` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getGraphicsColor` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getHeight` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getIdentifier` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getImage` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getName` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getPixel` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getStringWidth` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.getWidth` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.loadImage` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.nativeARGBFlip` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.saveImage` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.setClip` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.setGraphicsColor` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.setPaintMode` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.setPixel` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.setXorMode` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.translate` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.update` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.updateTexture` | 方法 | NeoMacros exposes no texture registry |
| `CustomImage.IMAGES` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.PREFIX` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.currentId` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.graphics` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.identifier` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.image` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.name` | 属性 | NeoMacros exposes no texture registry |
| `CustomImage.texture` | 属性 | NeoMacros exposes no texture registry |

### WorldScannerBuilder

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `WorldScannerBuilder.andBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.andStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.andStringBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.andStringStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.build` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.canCreateNewFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.composeFilters` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.contains` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.createNewFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.createStringFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.endsWith` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.equals` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.finishFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.getTargetFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.is` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.matches` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.notBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.notStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.orBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.orStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.orStringBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.orStringStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.setTargetFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.startsWith` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.test` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.withBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.withStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.withStringBlockFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.withStringStateFilter` | 方法 | NeoMacros has no world scanner |
| `WorldScannerBuilder.blockFilter` | 属性 | NeoMacros has no world scanner |
| `WorldScannerBuilder.method` | 属性 | NeoMacros has no world scanner |
| `WorldScannerBuilder.operation` | 属性 | NeoMacros has no world scanner |
| `WorldScannerBuilder.selectedCategory` | 属性 | NeoMacros has no world scanner |
| `WorldScannerBuilder.stateFilter` | 属性 | NeoMacros has no world scanner |

### StatsHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `StatsHelper.getBlockMined` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getCustomFormattedStat` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getCustomStat` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getEntityKilled` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getFormattedStatMap` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getFormattedStatValue` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getItemBroken` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getItemCrafted` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getItemDropped` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getItemPickedUp` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getItemUsed` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getKilledByEntity` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getRawStatMap` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getRawStatValue` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getStat` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getStatList` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getStatText` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.getTranslationKey` | 方法 | NeoMacros exposes no statistics query |
| `StatsHelper.updateStatistics` | 方法 | NeoMacros exposes no statistics query |

### RegistryHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `RegistryHelper.getActivityTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getBlock` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getBlockEntityTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getBlockIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getBlockState` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getBlocks` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getEnchantment` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getEnchantmentIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getEnchantments` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getEntity` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getEntityAttributeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getEntityTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getFeatureIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getFluidState` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getGameEventNames` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getIdentifier` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getItem` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getItemIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getItemStack` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getItems` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getMemoryModuleTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getPaintingIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getParticleTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getPointOfInterestTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getPotionTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getRawEntityType` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getRecipeTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getScreenHandlerIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getSensorTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getStatTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getStatusEffect` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getStatusEffectIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getStatusEffects` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getStructureFeatureIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getVillagerProfessionIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.getVillagerTypeIds` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.parseIdentifier` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.parseNameSpace` | 方法 | NeoMacros exposes no registry data (java escape layer only) |
| `RegistryHelper.mc` | 属性 | NeoMacros exposes no registry data (java escape layer only) |

### OptionsHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `OptionsHelper.getAccessibilityOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getBase` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getCameraMode` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getChatOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getCloudMode` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getControlOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getDifficulty` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getEnabledResourcePacks` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getFov` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getGamma` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getGraphicsMode` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getGuiScale` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getHeight` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getLanguage` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getMusicOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getRenderDistance` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getResourcePacks` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getSkinOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getSmoothCamera` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getVideoOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getVolume` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getVolumes` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.getWidth` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.isDifficultyLocked` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.isRightHanded` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.lockDifficulty` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.removeServerResourcePack` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.saveOptions` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setCameraMode` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setCloudMode` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setDifficulty` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setEnabledResourcePacks` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setFov` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setGamma` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setGraphicsMode` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setGuiScale` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setHeight` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setLanguage` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setRenderDistance` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setRightHanded` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setSize` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setSmoothCamera` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setVolume` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.setWidth` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.unlockDifficulty` | 方法 | NeoMacros exposes no game options surface |
| `OptionsHelper.SOUND_CATEGORY_MAP` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.accessibility` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.chat` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.control` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.mc` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.music` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.rpm` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.skin` | 属性 | NeoMacros exposes no game options surface |
| `OptionsHelper.video` | 属性 | NeoMacros exposes no game options surface |

### ModContainerHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `ModContainerHelper.getAuthors` | 方法 | NeoMacros exposes no mod list |
| `ModContainerHelper.getDependencies` | 方法 | NeoMacros exposes no mod list |
| `ModContainerHelper.getDescription` | 方法 | NeoMacros exposes no mod list |
| `ModContainerHelper.getEnv` | 方法 | NeoMacros exposes no mod list |
| `ModContainerHelper.getId` | 方法 | NeoMacros exposes no mod list |
| `ModContainerHelper.getName` | 方法 | NeoMacros exposes no mod list |
| `ModContainerHelper.getVersion` | 方法 | NeoMacros exposes no mod list |

### PacketByteBufferHelper

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `PacketByteBufferHelper.clear` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.forEachInCollection` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getBoolean` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getBuffer` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getByte` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getBytes` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getChar` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getDouble` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getFloat` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getLong` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getMedium` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getNetworkStateId` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getPacketId` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getPacketName` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getPacketNames` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getShort` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getUnsignedByte` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getUnsignedInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getUnsignedMedium` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.getUnsignedShort` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.init` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.isClientbound` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.isServerbound` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.main` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.markReaderIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.markWriterIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBitSet` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBlockHitResult` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBlockHitResultHelper` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBlockHitResultMap` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBlockPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBoolean` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readByte` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readByteArray` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readBytes` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readChar` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readChunkHelper` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readChunkPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readChunkSectionPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readDate` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readDouble` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readEnumConstant` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readFloat` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readIdentifier` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readInstant` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readIntArray` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readIntList` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readList` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readLong` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readLongArray` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readMap` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readMedium` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readNbt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readNullable` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readOptional` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readPublicKey` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readRegistryKey` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readShort` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readString` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readUnsignedByte` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readUnsignedInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readUnsignedMedium` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readUnsignedShort` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readUuid` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readVarInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readVarLong` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.readerIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.receivePacket` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.reset` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.resetIndices` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.resetReaderIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.resetWriterIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.sendPacket` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setBoolean` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setByte` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setBytes` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setChar` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setDouble` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setFloat` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setIndices` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setLong` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setMedium` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setReaderIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setShort` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setWriterIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.setZero` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.skipBytes` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.toPacket` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeBitSet` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeBlockHitResult` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeBlockPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeBoolean` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeByte` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeByteArray` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeBytes` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeChar` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeChunkPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeChunkSectionPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeCollection` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeDate` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeDouble` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeEnumConstant` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeFloat` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeGlobalPos` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeIdentifier` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeInstant` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeIntArray` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeIntList` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeLong` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeLongArray` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeMap` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeMedium` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeNbt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeNullable` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeOptional` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writePublicKey` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeRegistryKey` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeShort` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeString` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeUuid` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeVarInt` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeVarLong` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writeZero` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.writerIndex` | 方法 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.BUFFER_TO_PACKET` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.PACKETS` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.PACKET_IDS` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.PACKET_NAMES` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.PACKET_SIDES` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.PACKET_STATES` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.mc` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.original` | 属性 | NeoMacros exposes no packet buffer utilities |
| `PacketByteBufferHelper.packet` | 属性 | NeoMacros exposes no packet buffer utilities |

## 6. 事件系统

### 6.1 不支持的事件名（JsMacros.on 注册时即抛出）

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `RecvPacket` | 事件 | NeoMacros exposes no packet-level events |
| `SendPacket` | 事件 | NeoMacros exposes no packet-level events |
| `Title` | 事件 | NeoMacros has no title event (only the local chat.actionbar output) |
| `SignEdit` | 事件 | NeoMacros has no sign editing event |
| `NameChange` | 事件 | NeoMacros has no entity display-name change event |
| `Riding` | 事件 | NeoMacros has no riding edge event |
| `ArmorChange` | 事件 | NeoMacros has no armor change event |
| `ClickSlot` | 事件 | NeoMacros exposes no inventory events |
| `DropSlot` | 事件 | NeoMacros exposes no inventory events |
| `OpenContainer` | 事件 | NeoMacros exposes no inventory events |
| `ContainerUpdate` | 事件 | NeoMacros exposes no inventory events |
| `SlotUpdate` | 事件 | NeoMacros exposes no inventory events |
| `ItemDamage` | 事件 | NeoMacros exposes no inventory events |
| `ItemPickup` | 事件 | NeoMacros exposes no inventory events |
| `ResourcePackLoaded` | 事件 | NeoMacros has no resource pack event |
| `ProfileLoad` | 事件 | NeoMacros has no profile concept |
| `WrappedScript` | 事件 | internal JsMacros scripting event; script-run APIs are unsupported |
| `Service` | 事件 | internal JsMacros service event; services are unsupported |
| `CommandContext` | 事件 | internal JsMacros command dispatch event |

### 6.2 已桥接事件上不可用的成员（事件对象上读取/调用时抛出）

### EventChunkLoad

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventChunkLoad.isFull` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventDamage

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventDamage.attacker` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventDamage.source` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventDeath

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventDeath.respawn` | 方法 | field is not carried by the corresponding NeoMacros event |
| `EventDeath.inventory` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventDisconnect

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventDisconnect.message` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventEXPChange

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventEXPChange.prevLevel` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventEXPChange.prevProgress` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventEXPChange.prevTotal` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventEXPChange.total` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventEntityUnload

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventEntityUnload.reason` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventHeal

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventHeal.source` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventHealthChange

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventHealthChange.change` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventInteractBlock

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventInteractBlock.offhand` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventInteractBlock.result` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventInteractEntity

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventInteractEntity.offhand` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventInteractEntity.result` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventJoinServer

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventJoinServer.address` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventKey

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventKey.getKeyModifiers` | 方法 | field is not carried by the corresponding NeoMacros event |
| `EventKey.getModInt` | 方法 | field is not carried by the corresponding NeoMacros event |
| `EventKey.parse` | 方法 | field is not carried by the corresponding NeoMacros event |
| `EventKey.mc` | 属性 | field is not carried by the corresponding NeoMacros event |
| `EventKey.wasNullOnDown` | 属性 | field is not carried by the corresponding NeoMacros event |

### EventLaunchGame

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EventLaunchGame.playerName` | 属性 | field is not carried by the corresponding NeoMacros event |

### 6.3 手动补充的事件受限成员

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `BaseEvent.trigger()` | method | re-triggering built-in events is not possible under NeoMacros |
| `EventRecvMessage.text (write)` | property | NeoMacros supports cancelling chat:receive, not rewriting its text |
| `EventSendMessage.message (write)` | property | NeoMacros supports cancelling chat:send, not rewriting the message |
| `EventCustom.cancelable (write)` | property | NeoMacros custom events are always non-cancellable |

## 7. 方法内直接抛出的调用点（静态扫描）

| API | 类型 | 原因（调用时抛出 UnimplementedError） |
| --- | --- | --- |
| `EntityHelper.asServerEntity` | 方法 | server-side entities are invisible to the NeoMacros client surface（src\globals\entity\base.js） |
| `GlobalVars.putObject` | 方法 | NeoMacros storage carries JSON-serializable plain data only（src\globals\globalVars.js） |
| `Hud.isContainer` | 方法 | NeoMacros exposes no open screen introspection（src\globals\hud.js） |
| `Player.getInteractionManager` | 方法 | the local player is not in a world（src\globals\interaction.js） |
| `Inventory` | 方法 | no inventory screen is open（src\globals\inventory.js） |
| `Player.openInventory` | 方法 | the local player is not in a world（src\globals\inventory.js） |
| `EventCustom.cancelable` | 方法 | NeoMacros custom events are always non-cancellable（src\globals\jsMacros.js） |
| `EventCustom.putObject` | 方法 | NeoMacros custom event payloads carry JSON-serializable data only（src\globals\jsMacros.js） |
| `HTTPRequest.setConnectTimeout` | 方法 | NeoMacros exposes no connect timeout tuning（src\globals\request.js） |
| `HTTPRequest.setReadTimeout` | 方法 | NeoMacros exposes no read timeout tuning（src\globals\request.js） |
| `ServerInfoHelper.getIcon` | 方法 | NeoMacros exposes no server icon（src\globals\shells.js） |
| `ServerInfoHelper.getNbt` | 方法 | NeoMacros exposes no server entry NBT（src\globals\shells.js） |
| `ServerInfoHelper.getPlayerCountLabel` | 方法 | NeoMacros exposes no player-count label（src\globals\shells.js） |
| `ServerInfoHelper.getPlayerListSummary` | 方法 | NeoMacros exposes no player-list summary（src\globals\shells.js） |
| `ServerInfoHelper.getProtocolVersion` | 方法 | NeoMacros exposes no protocol version（src\globals\shells.js） |
| `ServerInfoHelper.getVersion` | 方法 | NeoMacros exposes no server version（src\globals\shells.js） |
| `ServerInfoHelper.resourcePackPolicy` | 方法 | NeoMacros exposes no resource-pack policy（src\globals\shells.js） |
| `TradeOfferHelper.getCurrentPriceAdjustment` | 方法 | NeoMacros exposes no special-price diff（src\globals\tradeOffer.js） |
| `TradeOfferHelper.getSpecialPrice` | 方法 | NeoMacros exposes no special-price diff（src\globals\tradeOffer.js） |
| `TradeOfferHelper.getPriceMultiplier` | 方法 | NeoMacros exposes no trade price multiplier（src\globals\tradeOffer.js） |
| `TradeOfferHelper.getExperience` | 方法 | NeoMacros exposes no merchant xp reward（src\globals\tradeOffer.js） |
| `TradeOfferHelper.shouldRewardPlayerExperience` | 方法 | NeoMacros exposes no merchant xp reward（src\globals\tradeOffer.js） |
| `TradeOfferHelper.select` | 方法 | NeoMacros exposes no trade selection on the open screen（src\globals\tradeOffer.js） |
| `TradeOfferHelper.getNBT` | 方法 | NeoMacros exposes no raw offer NBT（src\globals\tradeOffer.js） |
| `World.getBiome` | 方法 | the local player is not in a world（src\globals\world.js） |
| `BlockDataHelper.getBlockStateHelper` | 方法 | the block is no longer loaded in the world（src\support\block.js） |
| `BlockDataHelper.getBlock` | 方法 | raw host block access needs the java escape layer（src\support\block.js） |
| `ItemStackHelper.getItem` | 方法 | raw host item access needs the java escape layer（src\support\itemStack.js） |
| `TextBuilder.withColor` | 方法 | unsupported color argument form（src\support\text.js） |

## 8. 行为近似与签名偏差（不抛错，但必须知晓）

- **FS.* path root** — JsMacros resolves FS paths against the scripts folder; the compat layer resolves against the game directory (NeoMacros exposes no script-folder root).
- **Synchronous APIs become promises** — FS, Request, Time.sleep, Client.waitTick, Client.runOnMainThread(await), and all mutating Inventory actions keep JsMacros signatures but return promises. Old synchronous call sites receive a promise value (e.g. `if (FS.exists(p))` is always truthy) - add `await`.
- **BlockDataHelper.getName / ItemStackHelper.getDefaultName** — Derived from the id ("minecraft:deepslate_bricks" -> "Deepslate Bricks") because NeoMacros exposes no translation lookup.
- **World.isDay / isNight** — Fixed vanilla window: night spans ticks 13000..23000 of the 24000 day.
- **World.isChunkLoaded(cx, cz)** — Implemented by probing the loaded() state of a block inside the chunk.
- **World.getEntities() (all loaded)** — Implemented as an inRadius scan with a 100000-block range around the player.
- **World.iterateSphere / iterateBox** — Pure JS loops over world queries - far slower than the JsMacros native scanner on large volumes.
- **Entity reads are live, not snapshots** — JsMacros helpers snapshot at creation time; compat helpers re-read through live neo handles, so state can change between reads and vanished entities read as null/undefined.
- **Key.mods** — Normalized to shift/control/alt order joined with "+" from the neo modifier list.
- **RecvMessage.text / SendMessage.message rewrite** — Reading works; assignment throws. NeoMacros only supports cancelling these events, not rewriting them.
- **StatusEffectUpdate.oldEffect** — Synthesized from the removed effect id/amplifier; NeoMacros carries no previous-effect data.
- **Player.rayTraceBlock(distance, fluid)** — The fluid flag is accepted but NeoMacros raycasts ignore it. Reach constants: 4.5 (blocks) / 3.0 (entities).
- **interactions.interactBlock(x, y, z, direction, offHand)** — direction and offHand are accepted but ignored (plain use dispatch).
- **Player.openInventory() types** — Screen-type labels are approximated from the neo inventory kind ("Chest" instead of "3 Row Chest"); specialized inventory dispatch follows the kind string.
- **Inventory.split(slot1, slot2)** — Implemented as right-click (pick half) + left-click (place) instead of the native split.
- **Chat.log(TextHelper)** — Styled text renders via legacy section codes; hover/click styling is dropped.
- **Time.sleep / Client.waitTick** — Promise-based; the script loop is never blocked.
- **ANYTHING wildcard** — Maps to the neo "*" subscription, which skips high-traffic events (tick, world:blockUpdate, world:sound) by default.
- **HeldItemChange.offHand** — Always false: NeoMacros fires the held-item event for the main hand only.
- **EventCustom.cancelable = true** — Throws: NeoMacros custom events are non-cancellable.
- **JavaWrapper.methodToJava(fn)** — Identity passthrough - GraalJS converts functions to functional interfaces at the Java interop boundary.
- **JavaUtils collection creators** — Ride the java permission via neo.java, unlike JsMacros where they were permission-free.
- **draw point rendering** — Draw3D.addPoint renders a small wireframe cube (same as JsMacros) but supports no alpha channel merging beyond the ARGB int.
