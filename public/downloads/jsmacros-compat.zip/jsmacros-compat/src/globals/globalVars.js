// The GlobalVars global mapped onto neo.storage (synchronous on both sides).
// Typed put/get pairs keep JsMacros type-guard semantics; the java-object
// slot and the raw map dump are unavailable.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';

export const GlobalVarsCompat = {
    putInt(name, value) {
        neo.storage.put(name, Math.trunc(value));
        return Math.trunc(value);
    },

    putDouble(name, value) {
        neo.storage.put(name, Number(value));
        return Number(value);
    },

    putString(name, value) {
        neo.storage.put(name, String(value));
        return String(value);
    },

    putBoolean(name, value) {
        neo.storage.put(name, !!value);
        return !!value;
    },

    putObject(name, value) {
        unimplemented('GlobalVars.putObject', 'NeoMacros storage carries JSON-serializable plain data only');
    },

    getInt(name) {
        const v = neo.storage.get(name);
        return typeof v === 'number' && Number.isInteger(v) ? v : null;
    },

    getDouble(name) {
        const v = neo.storage.get(name);
        return typeof v === 'number' ? v : null;
    },

    getString(name) {
        const v = neo.storage.get(name);
        return typeof v === 'string' ? v : null;
    },

    getBoolean(name) {
        const v = neo.storage.get(name);
        return typeof v === 'boolean' ? v : null;
    },

    getObject(name) {
        const v = neo.storage.get(name);
        return v !== null && v !== undefined ? v : null;
    },

    getType(name) {
        const v = neo.storage.get(name);
        if (typeof v === 'number') return Number.isInteger(v) ? 'Int' : 'Double';
        if (typeof v === 'string') return 'String';
        if (typeof v === 'boolean') return 'Boolean';
        if (v !== null && v !== undefined) return 'Object';
        return null;
    },

    getAndIncrementInt(name) {
        const v = this.getInt(name);
        if (v === null) return null;
        neo.storage.put(name, v + 1);
        return v;
    },

    getAndDecrementInt(name) {
        const v = this.getInt(name);
        if (v === null) return null;
        neo.storage.put(name, v - 1);
        return v;
    },

    incrementAndGetInt(name) {
        const v = this.getInt(name);
        if (v === null) return null;
        neo.storage.put(name, v + 1);
        return v + 1;
    },

    decrementAndGetInt(name) {
        const v = this.getInt(name);
        if (v === null) return null;
        neo.storage.put(name, v - 1);
        return v - 1;
    },

    toggleBoolean(name) {
        const v = this.getBoolean(name);
        if (v === null) return null;
        neo.storage.put(name, !v);
        return !v;
    },

    remove(name) {
        neo.storage.remove(name);
    },

    toString() {
        return 'GlobalVars(jsmacros-compat over neo.storage)';
    },
};

defineStubs(GlobalVarsCompat, 'GlobalVars', {
    getRaw: 'NeoMacros storage has no enumerate-all operation',
});
