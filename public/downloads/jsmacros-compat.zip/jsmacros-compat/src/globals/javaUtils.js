// The JavaUtils global: collection constructors ride the neo.java escape
// layer (needs the java permission, like every raw-collection use in
// JsMacros scripts), string/array helpers and randomness stay in pure JS.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';

function javaType(name) {
    return neo.java.type(name);
}

function deepToString(value, seen) {
    if (!Array.isArray(value)) return String(value);
    if (seen.has(value)) return '[...]';
    seen.add(value);
    const out = value.map((v) => deepToString(v, seen));
    seen.delete(value);
    return `[${out.join(', ')}]`;
}

export const JavaUtilsCompat = {
    getHelperFromRaw(raw) {
        return neo.java.wrap(raw);
    },

    createArrayList(array) {
        const list = javaType('java.util.ArrayList').new();
        for (const item of array ?? []) list.add(item);
        return list;
    },

    createHashMap(map) {
        const mapObj = javaType('java.util.HashMap').new();
        for (const [k, v] of Object.entries(map ?? {})) mapObj.put(k, v);
        return mapObj;
    },

    createHashSet(array) {
        const set = javaType('java.util.HashSet').new();
        for (const item of array ?? []) set.add(item);
        return set;
    },

    arrayToString(array) {
        return deepToString(array, new Set());
    },

    arrayDeepToString(array) {
        return deepToString(array, new Set());
    },

    getRandom(seed) {
        return seed === undefined
            ? javaType('java.util.Random').new()
            : javaType('java.util.Random').new(seed);
    },

    toString() {
        return 'JavaUtils(jsmacros-compat; collections need the java permission)';
    },
};

defineStubs(JavaUtilsCompat, 'JavaUtils', {
});
