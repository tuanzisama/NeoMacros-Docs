// The Client global: process-level facts from neo.client, thread utilities
// from neo.thread, and a long list of connection/mod/packet surfaces that
// keep JsMacros names but throw.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';

export const ClientCompat = {
    connect(address, port) {
        const target = port === undefined ? String(address) : address + ":" + port;
        return neo.client.connect(target);
    },

    disconnect() {
        return neo.client.disconnect();
    },

    loadWorld(name) {
        return neo.client.loadWorld(String(name));
    },

    shutdown() {
        neo.client.shutdown();
    },

    exitGamePeacefully() {
        neo.client.shutdown();
    },

    exitGameForcefully() {
        neo.client.forceShutdown();
    },

    ping() {
        return neo.client.ping !== undefined ? neo.client.ping : null;
    },

    async pingAsync() {
        return neo.client.ping !== undefined ? neo.client.ping : null;
    },

    cancelAllPings() {
        // latency reads are passive; nothing to cancel
    },

    getLoadedMods() {
        return neo.client.mods;
    },

    isModLoaded(id) {
        return neo.client.isModLoaded(String(id));
    },

    getMod(id) {
        return neo.client.getMod(String(id));
    },

    getModLoader() {
        return "Fabric";
    },

    isDevEnv() {
        return neo.client.isDevEnv;
    },

    grabMouse() {
        neo.client.grabMouse();
    },

    getClipboard() {
        return neo.client.clipboard;
    },

    setClipboard(text) {
        neo.client.setClipboard(String(text));
    },

    getGameOptions() {
        const options = neo.client.options;
        if (options === undefined || options === null) return null;
        return {
            getFov() { return options.fov; },
            getGamma() { return options.gamma; },
            getGuiScale() { return options.guiScale; },
            getRenderDistance() { return options.renderDistance; },
        };
    },

    getRegisteredBlocks() {
        return neo.client.registryIds("block");
    },

    getRegisteredItems() {
        return neo.client.registryIds("item");
    },
    runOnMainThread(runnable, awaitCompletion, watchdogMaxTime) {
        const promise = neo.thread.runOnMain(runnable);
        // JsMacros await=true blocks until processed; the promise form is the
        // documented replacement (see README, "Synchronous APIs become promises").
        return awaitCompletion ? promise : undefined;
    },

    waitTick(ticks) {
        return neo.thread.ticks(ticks ?? 1);
    },

    getMinecraft() {
        return neo.client.minecraft;
    },

    mcVersion() {
        return neo.client.gameVersion;
    },

    getFPS() {
        // JsMacros returns the fps reading as a string.
        return String(neo.client.fps);
    },

    toString() {
        return `Client(${neo.client.gameVersion})`;
    },
};

defineStubs(ClientCompat, 'Client', {
    sendPacket: 'NeoMacros exposes no packet-level access',
    receivePacket: 'NeoMacros exposes no packet-level access',
    getRegistryManager: 'NeoMacros exposes no registry data (java escape layer only)',
    createPacketByteBuffer: 'NeoMacros exposes no packet buffer utilities',
});
