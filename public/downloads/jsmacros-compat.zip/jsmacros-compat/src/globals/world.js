// The World global: world state, block, entity, and ray queries mapped onto
// the neo.world and neo.entity surfaces.
import { CompatBlockPos, CompatPos3D } from '../support/pos.js';
import { BlockDataCompat, blockDataAt, ChunkHelperCompat } from '../support/block.js';
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';
import { createEntity } from './entity/specialized.js';

const DIFFICULTY_IDS = { peaceful: 0, easy: 1, normal: 2, hard: 3 };

// "All loaded entities" radius; far beyond any render distance.
const ALL_LOADED_RANGE = 100000;

function selfPos() {
    const self = neo.player.self;
    if (!self) {
        unimplemented('World.getBiome', 'the local player is not in a world');
    }
    return self.pos;
}

class CompatChunk extends ChunkHelperCompat {
    constructor(x, z) {
        super();
        this._cx = x;
        this._cz = z;
    }

    getX() {
        return this._cx;
    }

    getZ() {
        return this._cz;
    }

    toString() {
        return `chunk (${this._cx}, ${this._cz})`;
    }
}

function parseTypes(args, distance) {
    const types = [];
    let filter = null;
    for (const a of args) {
        if (typeof a === 'string') types.push(a);
        else if (typeof a === 'function') filter = a;
    }
    return { distance, types, filter };
}

export const WorldCompat = {
    getMoonPhase() {
        return neo.world.moonPhase;
    },

    getWorldIdentifier() {
        const name = neo.world.levelName;
        return name === undefined || name === null ? null : String(name);
    },

    getCurrentServerAddress() {
        const info = neo.client.serverInfo;
        return info === undefined || info === null ? null
            : (info.address !== undefined ? String(info.address) : null);
    },

    getServerTPS() {
        return neo.world.tps !== undefined ? neo.world.tps.m5 : null;
    },

    getServerInstantTPS() {
        return neo.world.tps !== undefined ? neo.world.tps.instant : null;
    },

    getServer1MAverageTPS() {
        return neo.world.tps !== undefined ? neo.world.tps.m1 : null;
    },

    getServer5MAverageTPS() {
        return neo.world.tps !== undefined ? neo.world.tps.m5 : null;
    },

    getServer15MAverageTPS() {
        return neo.world.tps !== undefined ? neo.world.tps.m15 : null;
    },

    getTabListHeader() {
        const tab = neo.world.tabList;
        return tab !== undefined && tab !== null && tab.header ? String(tab.header) : null;
    },

    getTabListFooter() {
        const tab = neo.world.tabList;
        return tab !== undefined && tab !== null && tab.footer ? String(tab.footer) : null;
    },

    getPlayerEntry(uuid) {
        const tab = neo.world.tabList;
        if (tab === undefined || tab === null) return null;
        const hit = (tab.entries || []).find((e) => e.uuid === String(uuid));
        return hit === undefined ? null : hit;
    },

    getPlayers() {
        const tab = neo.world.tabList;
        return tab === undefined || tab === null ? [] : (tab.entries || []);
    },

    getScoreboards() {
        const boards = neo.world.scoreboards;
        return boards === undefined || boards === null ? null : boards;
    },

    getBossBars() {
        const bars = neo.world.bossbars;
        if (bars === undefined || bars === null) return [];
        return bars.map((bar) => ({
            getUuid() { return bar.uuid; },
            getName() { return bar.name; },
            getProgress() { return bar.progress; },
            getColor() { return bar.color; },
        }));
    },

    playSound(sound, x, y, z, volume = 1, pitch = 1) {
        if (typeof x !== "number") {
            const pos = neo.player.self.pos;
            neo.world.playSound(sound, pos.x, pos.y, pos.z, volume, pitch);
        } else {
            neo.world.playSound(sound, x, y, z, volume, pitch);
        }
    },

    spawnParticle(particle, x, y, z, count, dx, dy, dz, speed) {
        neo.world.spawnParticle(particle, x, y, z, count, dx, dy, dz, speed);
    },

    findBlocksMatching(blockId, center, range) {
        const origin = center !== undefined && center !== null
            ? center
            : neo.player.self.pos;
        const cx = origin.x !== undefined ? origin.x : origin.getX();
        const cy = origin.y !== undefined ? origin.y : origin.getY();
        const cz = origin.z !== undefined ? origin.z : origin.getZ();
        const blocks = neo.world.findBlocks({
            types: String(blockId),
            center: { x: cx, y: cy, z: cz },
            range: range === undefined ? 16 : range,
        });
        return blocks.map((block) => ({
            getId() { return block.state.id; },
            getBlockState() { return block.state; },
            getPos() { return block.pos; },
        }));
    },
    isWorldLoaded() {
        const d = neo.world.dimension;
        return d !== undefined && d !== null;
    },

    getDimension() {
        const d = neo.world.dimension;
        return d !== undefined && d !== null ? String(d) : null;
    },

    getBiome() {
        const p = selfPos();
        return neo.world.biomeAt(p.x, p.y, p.z);
    },

    getBiomeAt(x, y, z) {
        return neo.world.biomeAt(x, y, z);
    },

    getTime() {
        return neo.world.age;
    },

    getTimeOfDay() {
        return neo.world.time;
    },

    isDay() {
        // Documented approximation: vanilla night spans ticks 13000..23000.
        const t = neo.world.time % 24000;
        return !(t >= 13000 && t < 23000);
    },

    isNight() {
        return !this.isDay();
    },

    isRaining() {
        return neo.world.raining;
    },

    isThundering() {
        return neo.world.thundering;
    },

    getDifficulty() {
        return DIFFICULTY_IDS[neo.world.difficulty] ?? -1;
    },

    getBlock(x, y, z) {
        if (typeof x === 'object') {
            const p = x;
            const px = typeof p.getX === 'function' ? p.getX() : p.x;
            const py = typeof p.getY === 'function' ? p.getY() : p.y;
            const pz = typeof p.getZ === 'function' ? p.getZ() : p.z;
            return blockDataAt(px, py, pz);
        }
        return blockDataAt(x, y, z);
    },

    getChunk(chunkX, chunkZ) {
        return new CompatChunk(chunkX, chunkZ);
    },

    isChunkLoaded(chunkX, chunkZ) {
        // Probing any block of the chunk exercises the chunk-load state.
        return neo.world.loaded(chunkX << 4, 64, chunkZ << 4);
    },

    getLoadedPlayers() {
        const players = neo.entity.players();
        if (!players || players.length === 0) return null;
        return players.map((p) => createEntity(p));
    },

    getEntities(...args) {
        let distance = ALL_LOADED_RANGE;
        if (typeof args[0] === 'number') distance = args[0];
        const { types, filter } = parseTypes(args, distance);
        const self = neo.player.self;
        const center = self?.pos ?? { x: 0, y: 0, z: 0 };
        const found = neo.entity.inRadius(center.x, center.y, center.z, distance);
        let helpers = found.map((e) => createEntity(e));
        if (types.length > 0) {
            helpers = helpers.filter((h) => h.is(...types));
        }
        if (filter) {
            helpers = helpers.filter((h) => !!filter(h));
        }
        if (helpers.length === 0) return null;
        return helpers;
    },

    rayTraceBlock(x1, y1, z1, x2, y2, z2, fluid) {
        const hit = neo.world.raycast(x1, y1, z1, x2, y2, z2);
        return hit && hit.block ? new BlockDataCompat(hit.block) : null;
    },

    rayTraceEntity(x1, y1, z1, x2, y2, z2) {
        const hit = neo.world.raycast(x1, y1, z1, x2, y2, z2);
        return hit && hit.entity ? createEntity(hit.entity) : null;
    },

    iterateSphere(pos, radius, ignoreAir, callback) {
        const minX = Math.floor(pos.x - radius);
        const maxX = Math.ceil(pos.x + radius);
        const minY = Math.floor(pos.y - radius);
        const maxY = Math.ceil(pos.y + radius);
        const minZ = Math.floor(pos.z - radius);
        const maxZ = Math.ceil(pos.z + radius);
        const r2 = radius * radius;
        for (let x = minX; x <= maxX; x++) {
            for (let y = minY; y <= maxY; y++) {
                for (let z = minZ; z <= maxZ; z++) {
                    const dx = x + 0.5 - pos.x;
                    const dy = y + 0.5 - pos.y;
                    const dz = z + 0.5 - pos.z;
                    if (dx * dx + dy * dy + dz * dz > r2) continue;
                    const block = blockDataAt(x, y, z);
                    if (!block) continue;
                    if (ignoreAir && block.getBlockStateHelper().isAir()) continue;
                    callback(block);
                }
            }
        }
    },

    iterateBox(pos1, pos2, ignoreAir, callback) {
        const minX = Math.min(Math.floor(pos1.x), Math.floor(pos2.x));
        const maxX = Math.max(Math.floor(pos1.x), Math.floor(pos2.x));
        const minY = Math.min(Math.floor(pos1.y), Math.floor(pos2.y));
        const maxY = Math.max(Math.floor(pos1.y), Math.floor(pos2.y));
        const minZ = Math.min(Math.floor(pos1.z), Math.floor(pos2.z));
        const maxZ = Math.max(Math.floor(pos1.z), Math.floor(pos2.z));
        for (let x = minX; x <= maxX; x++) {
            for (let y = minY; y <= maxY; y++) {
                for (let z = minZ; z <= maxZ; z++) {
                    const block = blockDataAt(x, y, z);
                    if (!block) continue;
                    if (ignoreAir && block.getBlockStateHelper().isAir()) continue;
                    callback(block);
                }
            }
        }
    },

    toString() {
        return `World(${this.getDimension()})`;
    },
};

defineStubs(WorldCompat, 'World', {
    getEntitiesInternal: 'internal JsMacros entity enumeration variant',
    getWorldScanner: 'NeoMacros has no world scanner',
    getRespawnPos: 'NeoMacros exposes no respawn position query',
    getSkyLight: 'NeoMacros exposes no light level queries',
    getBlockLight: 'NeoMacros exposes no light level queries',
    playSoundFile: 'NeoMacros exposes no sound playback',
    getRaw: 'raw host world access needs the java escape layer',
});

export { CompatBlockPos, CompatPos3D };
