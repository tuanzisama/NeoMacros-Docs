// The Chat global: output mapped onto neo.chat, text helpers built locally,
// formatting conversions implemented in pure string math.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';
import { TextHelperCompat, TextBuilderCompat, stripFormatting } from '../support/text.js';
import { ChatHistoryManagerShell, CommandManagerShell } from './shells.js';

/** Minimal %s/%d/%f/%x formatter mirroring Java String.format for common uses. */
function miniFormat(format, args) {
    let i = 0;
    return String(format).replace(/%(-?\d+)?(?:\.(\d+))?([sdfxX])/g, (match, width, precision, kind) => {
        const value = args[i++];
        let out;
        if (kind === 's') out = String(value);
        else if (kind === 'd') out = String(Math.trunc(Number(value)));
        else if (kind === 'f') out = Number(value).toFixed(precision ? Number(precision) : 6);
        else out = Math.trunc(Number(value)).toString(16);
        if (width) {
            const w = Number(width.replace('-', ''));
            out = width.startsWith('-') ? out.padEnd(w) : out.padStart(w);
        }
        return out;
    });
}

function renderMessage(message) {
    if (message === undefined || message === null) return null;
    if (message instanceof TextHelperCompat) return message.getFormatted();
    return String(message);
}

export const ChatCompat = {
    title(title, subtitle) {
        neo.chat.title(title === undefined ? null : String(title),
            subtitle === undefined ? null : String(subtitle));
    },

    toast(title, message) {
        neo.chat.toast(title === undefined ? null : String(title),
            message === undefined ? null : String(message));
    },

    log(message, awaitCompletion) {
        const rendered = renderMessage(message);
        if (rendered === null) return;
        neo.chat.log(rendered);
    },

    logf(format, ...args) {
        neo.chat.log(miniFormat(format, args));
    },

    logColor(message) {
        // JsMacros logColor converts & codes to section codes.
        neo.chat.log(String(message).replace(/&([0-9a-fk-or])/gi, '\u00a7$1'));
    },

    say(message, awaitCompletion) {
        neo.chat.say(String(message));
    },

    sayf(format, ...args) {
        neo.chat.say(miniFormat(format, args));
    },

    actionbar(text, tinted) {
        neo.chat.actionbar(renderMessage(text) ?? '');
    },

    text(str, style) {
        if (str instanceof TextHelperCompat) return str;
        return neo.chat.text(str === undefined || str === null ? '' : String(str),
            style === undefined || style === null ? null : style);
    },

    createTextHelperFromString(content) {
        return TextHelperCompat.fromString(content);
    },

    createTextHelperFromTranslationKey(key, ...content) {
        return TextHelperCompat.fromTranslationKey(key, ...content);
    },

    createTextHelperFromJSON(json) {
        return TextHelperCompat.fromJson(json);
    },

    createTextBuilder() {
        return new TextBuilderCompat();
    },

    getCommandManager() {
        return new CommandManagerShell();
    },

    getHistory() {
        return new ChatHistoryManagerShell();
    },

    getTextWidth(text) {
        return neo.chat.getWidth(String(text));
    },

    sectionSymbolToAmpersand(text) {
        return String(text).replace(/\u00a7/g, '&');
    },

    ampersandToSectionSymbol(text) {
        return String(text).replace(/&([0-9a-fk-or])/gi, '\u00a7$1').replace(/&&/g, '&');
    },

    stripFormatting(text) {
        return stripFormatting(text);
    },

    toString() {
        return 'Chat(jsmacros-compat)';
    },
};

defineStubs(ChatCompat, 'Chat', {
    logInternal: 'internal JsMacros chat dispatch variant',
    sayInternal: 'internal JsMacros chat dispatch variant',
    open: 'NeoMacros cannot open the chat input',
    getLogger: 'NeoMacros exposes no logger factory',
    createCommandBuilder: 'deprecated in JsMacros; use the script-side command system of NeoMacros (neo.command)',
    unregisterCommand: 'deprecated in JsMacros; use the script-side command system of NeoMacros (neo.command)',
    reRegisterCommand: 'deprecated in JsMacros; use the script-side command system of NeoMacros (neo.command)',
});
