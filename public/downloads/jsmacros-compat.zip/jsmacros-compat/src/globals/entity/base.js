// The four implemented tiers of the JsMacros entity helper chain plus the
// ItemEntity tier, all reading through a unified source: a live neo entity
// handle or an EntitySnapshot payload object (same field names, different
// read timing). Specialized subclasses are built in ./specialized.js on top
// of these.
import { CompatBlockPos, CompatDirection, CompatPos2D, CompatPos3D, directionFromAngles } from '../../support/pos.js';
import { TextHelperCompat } from '../../support/text.js';
import { ItemStackCompat } from '../../support/itemStack.js';
import { BlockDataCompat } from '../../support/block.js';
import { unimplemented } from '../../support/errors.js';
import { fillStubs } from '../../support/stubTable.js';

const ANIMAL_TYPES = new Set([
    'pig', 'cow', 'mooshroom', 'sheep', 'chicken', 'rabbit', 'horse', 'donkey',
    'mule', 'llama', 'trader_llama', 'cat', 'ocelot', 'wolf', 'fox', 'frog',
    'goat', 'axolotl', 'bee', 'polar_bear', 'strider', 'turtle', 'panda',
    'parrot', 'allay', 'camel', 'sniffer',
]);
const MERCHANT_TYPES = new Set(['villager', 'wandering_trader', 'merchant']);

/** Wraps an EntitySnapshot payload object behind the live-handle field names. */
export function snapshotSource(snapshot) {
    const pos = snapshot.pos ?? { x: 0, y: 0, z: 0 };
    const rotation = snapshot.rotation ?? { yawDeg: 0, pitchDeg: 0 };
    const eyeHeight = snapshot.eyeHeight ?? 1.62;
    return {
        uuid: snapshot.uuid,
        type: snapshot.type,
        name: snapshot.name,
        pose: snapshot.pose,
        pos,
        yaw: rotation.yawDeg,
        pitch: rotation.pitchDeg,
        blockPos: { x: Math.floor(pos.x), y: Math.floor(pos.y), z: Math.floor(pos.z) },
        eyePos: { x: pos.x, y: pos.y + eyeHeight, z: pos.z },
        eyeHeight,
        direction: directionFromAngles(rotation.yawDeg, rotation.pitchDeg),
        facing: snapshot.facing,
        chunk: { x: Math.floor(pos.x) >> 4, z: Math.floor(pos.z) >> 4 },
        health: snapshot.health,
        maxHealth: snapshot.maxHealth,
        heldItem: snapshot.heldItem,
        offhandItem: snapshot.offhandItem,
        living: snapshot.living,
        vehicle: snapshot.vehicle,
        passengers: snapshot.passengers,
        velocity: snapshot.velocity,
        sneaking: snapshot.sneaking,
        sprinting: snapshot.sprinting,
        swimming: snapshot.swimming,
        inLava: snapshot.inLava,
        inWater: snapshot.inWater,
        onFire: snapshot.onFire,
        gliding: snapshot.gliding,
        onGround: snapshot.onGround,
        alive: true,
        distanceTo(target) {
            const p = target instanceof EntityHelperCompat
                ? target._read('pos')
                : (target?.pos ?? target);
            const dx = pos.x - p.x;
            const dy = pos.y - p.y;
            const dz = pos.z - p.z;
            return Math.sqrt(dx * dx + dy * dy + dz * dz);
        },
        snapshot() {
            return snapshot;
        },
    };
}

/**
 * JsMacros EntityHelper. `source` is a live neo entity handle or a
 * snapshot source built by {@link snapshotSource}.
 */
export class EntityHelperCompat {
    constructor(source) {
        this._source = source;
    }

    _read(prop) {
        if (this._source === undefined || this._source === null) {
            unimplemented(`EntityHelper.${prop}`, 'the entity is gone');
        }
        return this._source[prop];
    }

    getPos() {
        const p = this._read('pos');
        return p ? new CompatPos3D(p.x, p.y, p.z) : null;
    }

    getX() {
        return this._read('pos')?.x;
    }

    getY() {
        return this._read('pos')?.y;
    }

    getZ() {
        return this._read('pos')?.z;
    }

    getBlockPos() {
        const p = this._read('blockPos');
        return p ? new CompatBlockPos(p.x, p.y, p.z) : null;
    }

    getEyePos() {
        const p = this._read('eyePos');
        return p ? new CompatPos3D(p.x, p.y, p.z) : null;
    }

    getEyeHeight() {
        return this._read('eyeHeight');
    }

    getChunkPos() {
        // JsMacros models the chunk position as Pos2D with y holding z.
        const c = this._read('chunk');
        return c ? new CompatPos2D(c.x, c.z) : null;
    }

    getPitch() {
        return this._read('pitch');
    }

    getYaw() {
        return this._read('yaw');
    }

    getName() {
        return TextHelperCompat.fromString(String(this._read('name')));
    }

    getType() {
        return this._read('type');
    }

    is(...types) {
        const self = withNamespace(this.getType());
        return types.some((t) => withNamespace(String(t)) === self);
    }

    isAlive() {
        return !!this._read('alive');
    }

    isInLava() {
        return !!this._read('inLava');
    }

    isOnFire() {
        return !!this._read('onFire');
    }

    isSneaking() {
        return !!this._read('sneaking');
    }

    isSprinting() {
        return !!this._read('sprinting');
    }

    getUUID() {
        return this._read('uuid');
    }

    getFacingDirection() {
        return new CompatDirection(String(this._read('facing')));
    }

    getBiome() {
        const p = this._read('pos');
        return neo.world.biomeAt(p.x, p.y, p.z);
    }

    getVehicle() {
        const v = this._read('vehicle');
        if (!v) return null;
        if (typeof v === 'string') {
            const handle = neo.entity.lookup(v);
            return handle ? new EntityHelperCompat(handle) : null;
        }
        return new EntityHelperCompat(v);
    }

    getPassengers() {
        const list = this._read('passengers') ?? [];
        // JsMacros models "no passengers" as null, not an empty list.
        if (!Array.isArray(list) || list.length === 0) return null;
        return list.map((p) => (typeof p === 'string'
            ? (neo.entity.lookup(p) ? new EntityHelperCompat(neo.entity.lookup(p)) : null)
            : new EntityHelperCompat(p)));
    }

    getVelocity() {
        const v = this._read('velocity');
        return v ? new CompatPos3D(v.x, v.y, v.z) : null;
    }

    distanceTo(target, y, z) {
        let resolved = target;
        if (target instanceof EntityHelperCompat) {
            resolved = target._source;
        } else if (target instanceof CompatPos3D || target instanceof CompatBlockPos) {
            resolved = { x: target.getX(), y: target.getY(), z: target.getZ() };
        } else if (y !== undefined) {
            resolved = { x: target, y, z };
        }
        return this._source.distanceTo(resolved);
    }

    rayTraceBlock(distance, fluid) {
        const eye = this._read('eyePos');
        const dir = this._read('direction');
        const to = {
            x: eye.x + dir.x * distance,
            y: eye.y + dir.y * distance,
            z: eye.z + dir.z * distance,
        };
        const hit = neo.world.raycast(eye.x, eye.y, eye.z, to.x, to.y, to.z);
        // The fluid flag is accepted but NeoMacros raycasts ignore it.
        return hit && hit.block ? new BlockDataCompat(hit.block) : null;
    }

    rayTraceEntity(distance) {
        const eye = this._read('eyePos');
        const dir = this._read('direction');
        const to = {
            x: eye.x + dir.x * distance,
            y: eye.y + dir.y * distance,
            z: eye.z + dir.z * distance,
        };
        const hit = neo.world.raycast(eye.x, eye.y, eye.z, to.x, to.y, to.z);
        return hit && hit.entity ? new EntityHelperCompat(hit.entity) : null;
    }

    asClientPlayer() {
        const self = neo.player.self;
        if (self && this._read('uuid') === self.uuid) {
            return new ClientPlayerCompat(self);
        }
        return null;
    }

    asPlayer() {
        if (String(this._read('type')).endsWith(':player')) {
            return new PlayerEntityCompat(this._source);
        }
        return null;
    }

    asLiving() {
        const src = this._source;
        const living = typeof src?.living === 'boolean' ? src.living : src?.maxHealth !== undefined;
        return living ? new LivingEntityCompat(this._source) : null;
    }

    asVillager() {
        return MERCHANT_TYPES.has(shortType(this._read('type'))) ? new EntityHelperCompat(this._source) : null;
    }

    asMerchant() {
        return this.asVillager();
    }

    asAnimal() {
        return ANIMAL_TYPES.has(shortType(this._read('type'))) ? new LivingEntityCompat(this._source) : null;
    }

    asItem() {
        return null;
    }

    asServerEntity() {
        unimplemented('EntityHelper.asServerEntity', 'server-side entities are invisible to the NeoMacros client surface');
    }

    toString() {
        return `${this._read('type')} ${this._read('uuid')}`;
    }
}

fillStubs(EntityHelperCompat.prototype, 'EntityHelper', 'entity state or write action not exposed by the neo entity surface');

/** JsMacros EntityHelper.create static dispatch to the most specific tier. */
EntityHelperCompat.create = function create(source) {
    return createEntityFromSource(source);
};

// Late import to avoid the base <-> specialized cycle.
import { createEntity as createEntityFromSource } from './specialized.js';

/** JsMacros LivingEntityHelper tier. */
export class LivingEntityCompat extends EntityHelperCompat {
    getHealth() {
        return this._read('health');
    }

    getMaxHealth() {
        return this._read('maxHealth');
    }

    getMainHand() {
        const stack = this._read('heldItem');
        return stack ? new ItemStackCompat(stack) : null;
    }

    getOffHand() {
        const stack = this._read('offhandItem');
        return stack ? new ItemStackCompat(stack) : null;
    }

    isHolding(itemId) {
        if (typeof this._source.isHolding === 'function') {
            return !!this._source.isHolding(itemId);
        }
        const wanted = withNamespace(itemId);
        return [this.getMainHand(), this.getOffHand()]
            .some((s) => s && withNamespace(s.getItemId()) === wanted);
    }

    isSleeping() {
        return !!this._read('sleeping');
    }

    isFallFlying() {
        return !!this._read('gliding');
    }

    isOnGround() {
        return !!this._read('onGround');
    }

    isSpectator() {
        const mode = this._read('gamemode');
        return mode === 'spectator';
    }
}

fillStubs(LivingEntityCompat.prototype, 'LivingEntityHelper', 'living entity state not exposed by the neo entity surface');

/** JsMacros PlayerEntityHelper tier (works for remote players too). */
export class PlayerEntityCompat extends LivingEntityCompat {
    getPlayerName() {
        return String(this._read('name'));
    }

    getXP() {
        return this._read('xp')?.total;
    }

    getXPLevel() {
        return this._read('xp')?.level;
    }

    getXPProgress() {
        return this._read('xp')?.progress;
    }
}

fillStubs(PlayerEntityCompat.prototype, 'PlayerEntityHelper', 'player state not exposed by the neo player surface');

/** JsMacros ClientPlayerEntityHelper tier: only the local player reaches it. */
export class ClientPlayerCompat extends PlayerEntityCompat {
    getFoodLevel() {
        return this._read('hunger');
    }

    getSaturation() {
        return this._read('saturation');
    }

    /** Legacy JsMacros attack entry point; resolves the entity argument. */
    attack(target, awaitCompletion) {
        const handle = target instanceof EntityHelperCompat ? target._source : target;
        return neo.player.self.attack(handle);
    }

    interactEntity(target, offHand, awaitCompletion) {
        const handle = target instanceof EntityHelperCompat ? target._source : target;
        return neo.player.self.interactEntity(handle);
    }

    interactBlock(x, y, z, direction, offHand, awaitCompletion) {
        const pos = new neo.types.BlockPos(x, y, z);
        return neo.player.self.interactBlock(pos);
    }

    dropHeldItem(dropStack) {
        return neo.player.self.dropHeld(!!dropStack);
    }

    toString() {
        return `ClientPlayer ${this._read('name')}`;
    }
}

fillStubs(ClientPlayerCompat.prototype, 'ClientPlayerEntityHelper', 'local player write action not exposed by the neo player surface');

/** JsMacros ItemEntityHelper tier. */
export class ItemEntityCompat extends EntityHelperCompat {
    getStack() {
        const stack = this._read('stack') ?? this._read('heldItem');
        return stack ? new ItemStackCompat(stack) : null;
    }
}

fillStubs(ItemEntityCompat.prototype, 'ItemEntityHelper', 'dropped item state not exposed by the neo entity surface');

function withNamespace(id) {
    const s = String(id);
    return s.includes(':') ? s : `minecraft:${s}`;
}

function shortType(typeId) {
    return String(typeId).replace('minecraft:', '');
}

/** Whether the source behaves like a live handle (has a snapshot() reader). */
export function isLiveHandle(source) {
    return !!source && typeof source.snapshot === 'function';
}

/** Chooses the compat tier for any neo handle or snapshot object. */
export function baseTierFor(source) {
    const type = shortType(source?.type ?? '');
    const self = neo.player.self;
    if (self && source.uuid === self.uuid) return ClientPlayerCompat;
    if (type === 'player') return PlayerEntityCompat;
    if (source.stack !== undefined || type === 'item') return ItemEntityCompat;
    const living = typeof source.living === 'boolean' ? source.living : source.maxHealth !== undefined;
    if (living) return LivingEntityCompat;
    return EntityHelperCompat;
}
