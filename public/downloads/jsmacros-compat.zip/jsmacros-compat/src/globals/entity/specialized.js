// Specialized entity helper shells. Every JsMacros entity subclass outside
// the four implemented tiers (plus ItemEntity) is carried as a shell class
// whose methods keep their JsMacros names and throw on call, because the
// specialized state they expose (mob goals, villager trades, boss phases,
// animal breeding state, ...) has no equivalent in the generic neo entity
// surface. Shells still deliver everything inherited from the implemented
// base tiers.
import { ENTITY_SHELLS } from '../../support/surface-data.js';
import { stubShellClass } from '../../support/stubTable.js';
import {
    EntityHelperCompat,
    LivingEntityCompat,
    PlayerEntityCompat,
    ClientPlayerCompat,
    ItemEntityCompat,
    baseTierFor,
} from './base.js';

const SHELL_REASON = 'specialized entity state has no equivalent in the neo entity surface';

const TIERS = {
    EntityHelper: EntityHelperCompat,
    LivingEntityHelper: LivingEntityCompat,
    PlayerEntityHelper: PlayerEntityCompat,
    ClientPlayerEntityHelper: ClientPlayerCompat,
    ItemEntityHelper: ItemEntityCompat,
};

// Define shells in dependency order: a shell's base is either an implemented
// tier or another shell defined earlier. The hierarchy is a tree rooted in
// EntityHelper, so a simple fixpoint walk terminates.
const SHELL_CLASSES = {};
const pending = new Set(Object.keys(ENTITY_SHELLS));
while (pending.size > 0) {
    let progressed = false;
    for (const name of [...pending]) {
        const baseName = ENTITY_SHELLS[name];
        const Base = TIERS[baseName] ?? SHELL_CLASSES[baseName];
        if (!Base) continue;
        SHELL_CLASSES[name] = stubShellClass(name, Base, SHELL_REASON);
        pending.delete(name);
        progressed = true;
    }
    if (!progressed) {
        throw new Error(`entity shell hierarchy is not rooted: ${[...pending].join(', ')}`);
    }
}

/** camelCase -> snake_case suffix used to match minecraft type ids. */
function typeIdKey(typeId) {
    const short = String(typeId).replace('minecraft:', '');
    return short;
}

const TYPE_DISPATCH = {};
for (const name of Object.keys(SHELL_CLASSES)) {
    // VillagerEntityHelper -> villager; ZombieVillagerEntityHelper -> zombie_villager.
    const key = name.replace(/EntityHelper$/, '');
    const snake = key.replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase();
    TYPE_DISPATCH[snake] = SHELL_CLASSES[name];
}

/**
 * Builds the most specific JsMacros helper for a neo entity handle or
 * an EntitySnapshot payload object.
 */
export function createEntity(source) {
    if (!source) return null;
    const snake = typeIdKey(source.type ?? '');
    const Shell = TYPE_DISPATCH[snake];
    if (Shell) return new Shell(source);
    const Tier = baseTierFor(source);
    return new Tier(source);
}

/** All shell classes, exposed for audit introspection. */
export function shellClasses() {
    return SHELL_CLASSES;
}
