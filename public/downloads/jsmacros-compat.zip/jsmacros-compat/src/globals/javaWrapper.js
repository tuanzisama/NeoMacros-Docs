// The JavaWrapper global. GraalJS converts script functions to functional
// interfaces at the Java interop boundary on its own, so methodToJava keeps
// its name and passes the function through unchanged. The thread-priority
// scheduling controls are unavailable.
import { defineStubs } from '../support/stubTable.js';

export const JavaWrapperCompat = {
    methodToJava(fn) {
        return fn;
    },

    methodToJavaAsync(fn, priority) {
        return fn;
    },

    toString() {
        return 'JavaWrapper(jsmacros-compat; functions pass through to the Java interop boundary)';
    },
};

defineStubs(JavaWrapperCompat, 'JavaWrapper', {
    deferCurrentTask: 'NeoMacros exposes no script-thread task queue control',
    getCurrentPriority: 'NeoMacros exposes no script-thread task queue control',
    stop: 'NeoMacros exposes no script-thread task queue control',
});
