// The Utils global. Base64 and null-checks work in pure JS; clipboard,
// hashing, name guessing, and the system-open helpers keep their names and
// throw.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function base64Encode(bytes) {
    let out = '';
    for (let i = 0; i < bytes.length; i += 3) {
        const b0 = bytes[i];
        const b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
        const b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
        out += B64[b0 >> 2];
        out += B64[((b0 & 3) << 4) | (b1 >> 4)];
        out += i + 1 < bytes.length ? B64[((b1 & 15) << 2) | (b2 >> 6)] : '=';
        out += i + 2 < bytes.length ? B64[b2 & 63] : '=';
    }
    return out;
}

function base64Decode(text) {
    const clean = String(text).replace(/[^A-Za-z0-9+/]/g, '');
    const bytes = [];
    for (let i = 0; i < clean.length; i += 4) {
        const n = (B64.indexOf(clean[i]) << 18)
            | (B64.indexOf(clean[i + 1] ?? 'A') << 12)
            | ((clean[i + 2] ? B64.indexOf(clean[i + 2]) : 63) << 6)
            | (clean[i + 3] ? B64.indexOf(clean[i + 3]) : 63);
        bytes.push((n >> 16) & 0xff);
        if (clean[i + 2] && clean[i + 2] !== '=') bytes.push((n >> 8) & 0xff);
        if (clean[i + 3] && clean[i + 3] !== '=') bytes.push(n & 0xff);
    }
    return bytes;
}

function utf8Bytes(text) {
    return Array.from(new TextEncoder().encode(String(text)));
}

function utf8FromBytes(bytes) {
    return new TextDecoder().decode(Uint8Array.from(bytes));
}

export const UtilsCompat = {
    encode(message) {
        return base64Encode(utf8Bytes(message));
    },

    decode(message) {
        return utf8FromBytes(base64Decode(message));
    },

    /** JsMacros CE alias of encode. */
    getBase64String(text) {
        return this.encode(text);
    },

    /** JsMacros CE alias of decode. */
    getBase64Decoded(text) {
        return this.decode(text);
    },

    requireNonNull(obj, message) {
        if (obj === undefined || obj === null) {
            throw new Error(message ?? 'argument is null');
        }
        return obj;
    },

    toString() {
        return 'Utils(jsmacros-compat)';
    },
};

defineStubs(UtilsCompat, 'Utils', {
    getClipboard: 'NeoMacros exposes no clipboard access',
    setClipboard: 'NeoMacros exposes no clipboard access',
    copyToClipboard: 'NeoMacros exposes no clipboard access',
    getHash: 'NeoMacros exposes no synchronous digest; hashing needs the java escape layer',
    hashString: 'NeoMacros exposes no synchronous digest; hashing needs the java escape layer',
    guessName: 'NeoMacros exposes no account introspection',
    guessNameAndRoles: 'NeoMacros exposes no account introspection',
    open: 'deprecated in JsMacros and unavailable under NeoMacros',
    openUrl: 'NeoMacros cannot open system URLs',
    openFile: 'NeoMacros cannot open system files',
});
