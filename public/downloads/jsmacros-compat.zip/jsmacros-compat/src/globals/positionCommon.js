// The PositionCommon global: factories for the compat math classes.
import {
    CompatPos2D, CompatPos3D, CompatVec2D, CompatVec3D, CompatBlockPos,
    directionFromAngles,
} from '../support/pos.js';

export const PositionCommonCompat = {
    createPos(x, y, z) {
        return z === undefined ? new CompatPos2D(x, y) : new CompatPos3D(x, y, z);
    },

    createVec(...args) {
        return args.length >= 5
            ? new CompatVec3D(args[0], args[1], args[2], args[3], args[4], args[5])
            : new CompatVec2D(args[0], args[1], args[2], args[3]);
    },

    createLookingVector(entityOrYaw, pitch) {
        if (typeof entityOrYaw === 'object' && entityOrYaw !== null) {
            const eye = entityOrYaw.getEyePos();
            const dir = directionFromAngles(entityOrYaw.getYaw(), entityOrYaw.getPitch());
            return new CompatVec3D(eye.x, eye.y, eye.z, eye.x + dir.x, eye.y + dir.y, eye.z + dir.z);
        }
        const dir = directionFromAngles(entityOrYaw, pitch);
        return new CompatVec3D(0, 0, 0, dir.x, dir.y, dir.z);
    },

    createBlockPos(x, y, z) {
        return new CompatBlockPos(x, y, z);
    },

    toString() {
        return 'PositionCommon(jsmacros-compat)';
    },
};
