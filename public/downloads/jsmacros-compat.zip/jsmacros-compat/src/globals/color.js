// The Color global: pure ARGB integer math, fully local.
import { argb, rgb, alpha, red, green, blue, withAlpha, fromPacked } from '../support/colorUtil.js';

export const ColorCompat = {
    argb,

    rgb,

    fromPacked,

    alpha,

    red,

    green,

    blue,

    withAlpha,

    toString() {
        return 'Color(jsmacros-compat)';
    },
};
