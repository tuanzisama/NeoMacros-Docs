// The Reflection global mapped onto neo.java + neo.reflect. Every member
// rides the java permission, exactly like Reflection in JsMacros scripts.
// Dynamic class compilation has no NeoMacros equivalent.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';

export const ReflectionCompat = {
    getWrappedClass(raw) {
        return neo.java.wrap(raw);
    },

    wrapInstace(raw) {
        return neo.java.wrap(raw);
    },

    getClass(name, obfName) {
        // The obfuscated name argument is accepted; NeoMacros resolves
        // Mojmap binary names at the call site.
        return neo.java.type(name);
    },

    getMethod(cls, name, ...paramTypes) {
        return neo.reflect.method(cls, name, paramTypes);
    },

    getDeclaredMethod(cls, name, ...paramTypes) {
        return neo.reflect.method(cls, name, paramTypes);
    },

    getField(cls, name) {
        return neo.reflect.field(cls, name);
    },

    getDeclaredField(cls, name) {
        return neo.reflect.field(cls, name);
    },

    invokeMethod(method, target, ...args) {
        return neo.reflect.invoke(method, target, args);
    },

    newInstance(cls, ...args) {
        return neo.reflect.newInstance(cls, args);
    },

    getClassName(value) {
        return neo.reflect.className(value);
    },

    toString() {
        return 'Reflection(jsmacros-compat over neo.java/neo.reflect; needs the java permission)';
    },
};

defineStubs(ReflectionCompat, 'Reflection', {
    getAllCompiledJavaClassVersions: 'NeoMacros cannot compile Java sources',
    getClassFromClassBuilderResult: 'NeoMacros cannot compile Java sources',
    getCompiledJavaClass: 'NeoMacros cannot compile Java sources',
    loadCurrentMappingHelper: 'NeoMacros exposes no mapping helpers',
    loadMappingHelper: 'NeoMacros exposes no mapping helpers',
    createClassProxyBuilder: 'NeoMacros has no dynamic class proxying beyond neo.java.proxy handler maps',
    createClassBuilder: 'NeoMacros has no runtime class generation',
    createLibraryBuilder: 'NeoMacros has no runtime library generation',
    createLibrary: 'NeoMacros has no runtime class generation',
    compileJavaClass: 'NeoMacros cannot compile Java sources',
    loadJarFile: 'NeoMacros cannot load jars at runtime',
    getReflect: 'NeoMacros exposes no per-object reflection helper',
});
