// The FS global mapped onto neo.fs. JsMacros' synchronous filesystem surface
// keeps its names and returns promises (see README, "Synchronous APIs become
// promises"). Paths resolve against the game directory under NeoMacros, not
// the scripts folder - a documented behavioral deviation.
import { unimplemented } from '../support/errors.js';
import { defineStubs, fillStubs } from '../support/stubTable.js';

export class FileHandlerCompat {
    constructor(path) {
        this._path = path;
    }

    write(data) {
        const content = typeof data === 'string' ? data : Array.from(data);
        const writePromise = typeof data === 'string'
            ? neo.fs.writeText(this._path, content)
            : neo.fs.writeBytes(this._path, content);
        return writePromise.then(() => this);
    }

    append(data) {
        const addition = typeof data === 'string' ? data : Array.from(data);
        return neo.fs.exists(this._path).then((exists) => {
            if (!exists) {
                return typeof addition === 'string'
                    ? neo.fs.writeText(this._path, addition)
                    : neo.fs.writeBytes(this._path, addition);
            }
            return neo.fs.readText(this._path).then((current) => {
                if (typeof addition === 'string') {
                    return neo.fs.writeText(this._path, current + addition);
                }
                return neo.fs.readBytes(this._path).then((bytes) => {
                    const merged = Array.from(bytes ?? []).concat(addition);
                    return neo.fs.writeBytes(this._path, merged);
                });
            });
        }).then(() => this);
    }

    read() {
        return neo.fs.readText(this._path);
    }

    readBytes() {
        return neo.fs.readBytes(this._path);
    }

    readLines() {
        // Load-once semantics: the iterator serves the snapshot read at call
        // time, because NeoMacros has no blocking per-line reads.
        return neo.fs.readText(this._path).then((text) => {
            const lines = text.split(/\r?\n/);
            let index = 0;
            return {
                hasNext: () => index < lines.length,
                next: () => (index < lines.length ? lines[index++] : null),
                close: () => undefined,
            };
        });
    }

    toString() {
        return `FileHandler(${this._path})`;
    }
}

fillStubs(FileHandlerCompat.prototype, 'FileHandler', 'stream and raw-file access are not exposed by neo.fs');

async function statOrNull(path) {
    try {
        return await neo.fs.stat(path);
    } catch (e) {
        return null;
    }
}

export const FsCompat = {
    list(path) {
        return neo.fs.list(path).catch(() => null);
    },

    exists(path) {
        return neo.fs.exists(path);
    },

    async isDir(path) {
        const s = await statOrNull(path);
        return !!s && !!s.isDir;
    },

    async isFile(path) {
        const s = await statOrNull(path);
        return !!s && !!s.isFile;
    },

    getName(path) {
        const normalized = String(path).replace(/\\/g, '/');
        const trimmed = normalized.replace(/\/+$/, '');
        const idx = trimmed.lastIndexOf('/');
        return idx === -1 ? trimmed : trimmed.slice(idx + 1);
    },

    getDir(path) {
        const normalized = String(path).replace(/\\/g, '/');
        const idx = normalized.lastIndexOf('/');
        return idx === -1 ? '' : normalized.slice(0, idx);
    },

    combine(pathA, pathB) {
        const a = String(pathA).replace(/\\/g, '/').replace(/\/+$/, '');
        const b = String(pathB).replace(/\\/g, '/').replace(/^\/+/, '');
        return a === '' ? b : `${a}/${b}`;
    },

    async createFile(path, name, createDirs) {
        const target = this.combine(path, name);
        const exists = await neo.fs.exists(target);
        if (exists) return false;
        if (createDirs) {
            await neo.fs.mkdir(this.getDir(target));
        }
        await neo.fs.writeText(target, '');
        return true;
    },

    async makeDir(path) {
        const exists = await neo.fs.exists(path);
        if (exists) return false;
        await neo.fs.mkdir(path);
        return true;
    },

    move(from, to) {
        return neo.fs.move(from, to);
    },

    copy(from, to) {
        return neo.fs.copy(from, to);
    },

    unlink(path) {
        return neo.fs.delete(path).then(() => true).catch(() => false);
    },

    open(path, charset) {
        // The charset argument is accepted; NeoMacros reads UTF-8 only.
        return new FileHandlerCompat(path);
    },

    async walkFiles(path, maxDepth, followLinks, visitor) {
        const depth = maxDepth ?? Infinity;
        const walk = async (current, level) => {
            if (level > depth) return;
            const entries = await this.list(current);
            if (!entries) return;
            for (const entry of entries) {
                const child = this.combine(current, entry);
                const s = await statOrNull(child);
                if (!s) continue;
                if (s.isDir) {
                    await walk(child, level + 1);
                } else {
                    visitor(child, { isDir: false, isFile: true, size: s.size, mtimeMs: s.mtimeMs });
                }
            }
        };
        await walk(path, 0);
    },

    toString() {
        return 'FS(jsmacros-compat; paths resolve against the game directory)';
    },
};

defineStubs(FsCompat, 'FS', {
    toRelativePath: 'NeoMacros exposes no script-folder root to resolve against',
    toRawFile: 'NeoMacros exposes no raw java.io.File handles',
    toRawPath: 'NeoMacros exposes no raw java.nio.Path handles',
    getRawAttributes: 'NeoMacros exposes no raw file attributes',
});
