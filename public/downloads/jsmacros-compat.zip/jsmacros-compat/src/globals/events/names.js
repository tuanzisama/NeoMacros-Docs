// JsMacros event name registry: mapping to neo event names, legacy aliases,
// and the explicit unsupported set. Every JsMacros 1.9.2 event name resolves
// through resolveEvent to exactly one of the three outcomes, so JsMacros.on
// either bridges, throws with the reason, or joins a script-created custom
// event.

export const MAPPED = {
    Tick: { neo: ['tick'], adapter: 'tick', jsCancellable: false, syncCapable: false },
    Key: { neo: ['key:press'], adapter: 'key', jsCancellable: true, syncCapable: true },
    MouseScroll: { neo: ['input:wheel'], adapter: 'mouseScroll', jsCancellable: true, syncCapable: false },
    RecvMessage: { neo: ['chat:receive'], adapter: 'recvMessage', jsCancellable: true, syncCapable: false },
    SendMessage: { neo: ['chat:send'], adapter: 'sendMessage', jsCancellable: true, syncCapable: true },
    Sound: { neo: ['world:sound'], adapter: 'sound', jsCancellable: true, syncCapable: false },
    Bossbar: { neo: ['world:bossbar'], adapter: 'bossbar', jsCancellable: false, syncCapable: false },
    JoinServer: { neo: ['world:join'], adapter: 'joinServer', jsCancellable: false, syncCapable: false },
    Disconnect: { neo: ['world:leave'], adapter: 'disconnect', jsCancellable: false, syncCapable: false },
    DimensionChange: { neo: ['world:dimensionChange'], adapter: 'dimensionChange', jsCancellable: false, syncCapable: false },
    ChunkLoad: { neo: ['world:chunkLoad'], adapter: 'chunkLoad', jsCancellable: false, syncCapable: false },
    ChunkUnload: { neo: ['world:chunkUnload'], adapter: 'chunkUnload', jsCancellable: false, syncCapable: false },
    BlockUpdate: { neo: ['world:blockUpdate'], adapter: 'blockUpdate', jsCancellable: false, syncCapable: false },
    EntityLoad: { neo: ['entity:load'], adapter: 'entityLoad', jsCancellable: false, syncCapable: false },
    EntityUnload: { neo: ['entity:unload'], adapter: 'entityUnload', jsCancellable: false, syncCapable: false },
    EntityDamaged: { neo: ['entity:damage'], adapter: 'entityDamaged', jsCancellable: false, syncCapable: false },
    EntityHealed: { neo: ['entity:heal'], adapter: 'entityHealed', jsCancellable: false, syncCapable: false },
    PlayerJoin: { neo: ['player:join'], adapter: 'playerJoin', jsCancellable: false, syncCapable: false },
    PlayerLeave: { neo: ['player:leave'], adapter: 'playerLeave', jsCancellable: false, syncCapable: false },
    AirChange: { neo: ['player:air'], adapter: 'airChange', jsCancellable: false, syncCapable: false },
    AttackBlock: { neo: ['player:attackBlock'], adapter: 'attackBlock', jsCancellable: false, syncCapable: true },
    AttackEntity: { neo: ['player:attackEntity'], adapter: 'attackEntity', jsCancellable: false, syncCapable: true },
    InteractBlock: { neo: ['player:interactBlock'], adapter: 'interactBlock', jsCancellable: false, syncCapable: true },
    InteractEntity: { neo: ['player:interactEntity'], adapter: 'interactEntity', jsCancellable: false, syncCapable: true },
    Damage: { neo: ['player:damage'], adapter: 'damage', jsCancellable: false, syncCapable: false },
    Heal: { neo: ['player:heal'], adapter: 'heal', jsCancellable: false, syncCapable: false },
    HealthChange: { neo: ['player:health'], adapter: 'healthChange', jsCancellable: false, syncCapable: false },
    Death: { neo: ['player:death'], adapter: 'death', jsCancellable: false, syncCapable: false },
    EXPChange: { neo: ['player:exp'], adapter: 'expChange', jsCancellable: false, syncCapable: false },
    FallFlying: { neo: ['player:gliding'], adapter: 'fallFlying', jsCancellable: false, syncCapable: false },
    HeldItemChange: { neo: ['player:heldItem'], adapter: 'heldItemChange', jsCancellable: false, syncCapable: false },
    HungerChange: { neo: ['player:hunger'], adapter: 'hungerChange', jsCancellable: false, syncCapable: false },
    OpenScreen: { neo: ['screen:open', 'screen:close'], adapter: 'openScreen', jsCancellable: false, syncCapable: false },
    StatusEffectUpdate: { neo: ['player:effect'], adapter: 'statusEffectUpdate', jsCancellable: false, syncCapable: false },
    LaunchGame: { neo: ['game:start'], adapter: 'launchGame', jsCancellable: false, syncCapable: false },
    QuitGame: { neo: ['game:quit'], adapter: 'quitGame', jsCancellable: false, syncCapable: false },
    // The neo wildcard skips high-traffic events (tick, world:blockUpdate,
    // world:sound) by default; documented in the README.
    ANYTHING: { neo: ['*'], adapter: 'anything', jsCancellable: false, syncCapable: false },
};

export const UNSUPPORTED = {
    RecvPacket: 'NeoMacros exposes no packet-level events',
    SendPacket: 'NeoMacros exposes no packet-level events',
    Title: 'NeoMacros has no title event (only the local chat.actionbar output)',
    SignEdit: 'NeoMacros has no sign editing event',
    NameChange: 'NeoMacros has no entity display-name change event',
    Riding: 'NeoMacros has no riding edge event',
    ArmorChange: 'NeoMacros has no armor change event',
    ClickSlot: 'NeoMacros exposes no inventory events',
    DropSlot: 'NeoMacros exposes no inventory events',
    OpenContainer: 'NeoMacros exposes no inventory events',
    ContainerUpdate: 'NeoMacros exposes no inventory events',
    SlotUpdate: 'NeoMacros exposes no inventory events',
    ItemDamage: 'NeoMacros exposes no inventory events',
    ItemPickup: 'NeoMacros exposes no inventory events',
    ResourcePackLoaded: 'NeoMacros has no resource pack event',
    ProfileLoad: 'NeoMacros has no profile concept',
    WrappedScript: 'internal JsMacros scripting event; script-run APIs are unsupported',
    Service: 'internal JsMacros service event; services are unsupported',
    CommandContext: 'internal JsMacros command dispatch event',
};

/** Old UPPER_SNAKE profile names accepted by JsMacros profile loading. */
export const LEGACY_ALIASES = {
    TICK: 'Tick',
    KEY: 'Key',
    RECV_MESSAGE: 'RecvMessage',
    SEND_MESSAGE: 'SendMessage',
    TITLE: 'Title',
    RECV_PACKET: 'RecvPacket',
    SEND_PACKET: 'SendPacket',
    JOIN_SERVER: 'JoinServer',
    DISCONNECT: 'Disconnect',
    DIMENSION_CHANGE: 'DimensionChange',
    CHUNK_LOAD: 'ChunkLoad',
    CHUNK_UNLOAD: 'ChunkUnload',
    BLOCK_UPDATE: 'BlockUpdate',
    BOSSBAR_UPDATE: 'Bossbar',
    SOUND: 'Sound',
    NAME_CHANGE: 'NameChange',
    PLAYER_JOIN: 'PlayerJoin',
    PLAYER_LEAVE: 'PlayerLeave',
    AIR_CHANGE: 'AirChange',
    ARMOR_CHANGE: 'ArmorChange',
    DAMAGE: 'Damage',
    DEATH: 'Death',
    EXP_CHANGE: 'EXPChange',
    HELD_ITEM: 'HeldItemChange',
    HUNGER_CHANGE: 'HungerChange',
    OPEN_SCREEN: 'OpenScreen',
    SIGN_EDIT: 'SignEdit',
    ITEM_PICKUP: 'ItemPickup',
    ITEM_DAMAGE: 'ItemDamage',
    PROFILE_LOAD: 'ProfileLoad',
};

const REVERSE = {};
for (const [jsName, entry] of Object.entries(MAPPED)) {
    if (jsName === 'ANYTHING') continue;
    for (const neoName of entry.neo) {
        if (!(neoName in REVERSE)) REVERSE[neoName] = jsName;
    }
}

/** neo event name -> JsMacros event name (used by the ANYTHING bridge). */
export function fromNeoName(neoName) {
    return REVERSE[neoName] ?? null;
}

/** Prefix applied to script-created custom event names. */
export const CUSTOM_PREFIX = 'compat:';

/**
 * Resolves any JsMacros event name to a bridge instruction.
 * @returns {{kind: 'mapped', name: string, entry: object}
 *          | {kind: 'unsupported', name: string, reason: string}
 *          | {kind: 'custom', name: string, registered: boolean}
 *          | {kind: 'unknown', name: string}}
 */
export function resolveEvent(name, customRegistry) {
    const canonical = LEGACY_ALIASES[name] ?? name;
    if (canonical === 'ANYTHING' || canonical === '*') {
        return { kind: 'mapped', name: 'ANYTHING', entry: MAPPED.ANYTHING };
    }
    const mapped = MAPPED[canonical];
    if (mapped) return { kind: 'mapped', name: canonical, entry: mapped };
    if (canonical in UNSUPPORTED) {
        return { kind: 'unsupported', name: canonical, reason: UNSUPPORTED[canonical] };
    }
    if (customRegistry && customRegistry.has(canonical)) {
        return { kind: 'custom', name: canonical, registered: true };
    }
    return { kind: 'unknown', name: canonical };
}
