// JsMacros EventContainer and EventAndContext shims. NeoMacros attributes
// subscriptions to the loading module and cleans them up on unload, so the
// explicit lock protocol degrades to no-ops.

export class EventContainerCompat {
    isLocked() {
        return false;
    }

    getCtx() {
        return null;
    }

    getLockThread() {
        return null;
    }

    awaitLock(then) {
        // Never locked: queued callbacks run immediately.
        if (typeof then === 'function') then();
    }

    releaseLock() {
        // No lock to release; NeoMacros owns subscription lifetime.
    }

    toString() {
        return 'EventContainer(releaseLock is a no-op under NeoMacros)';
    }
}

export class EventAndContextCompat {
    constructor(event, context) {
        this.event = event;
        this.context = context;
    }

    toString() {
        return `EventAndContext(${this.event?.getEventName?.() ?? '?'})`;
    }
}

export const SHARED_CONTEXT = new EventContainerCompat();
