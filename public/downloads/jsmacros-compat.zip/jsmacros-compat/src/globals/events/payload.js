// Per-event payload adapters. Each adapter shapes a neo event payload into
// the JsMacros event object: supported fields become data properties,
// unsupported surface fields become throwing accessors, and JsMacros-only
// methods become throwing methods - so every documented member exists.
import { TextHelperCompat } from '../../support/text.js';
import { CompatBlockPos, CompatPos3D } from '../../support/pos.js';
import { ItemStackCompat } from '../../support/itemStack.js';
import { BlockDataCompat, blockDataAt } from '../../support/block.js';
import { createEntity } from '../entity/specialized.js';
import { unimplemented } from '../../support/errors.js';
import { fillSurfaceFields } from '../../support/stubTable.js';
import { SURFACE } from '../../support/surface-data.js';
import { fromNeoName } from './names.js';

const FIELD_REASON = 'field is not carried by the corresponding NeoMacros event';

const FACE_TO_ID = { down: 0, up: 1, north: 2, south: 3, west: 4, east: 5 };

const BOSSBAR_TYPES = {
    add: 'ADD',
    remove: 'REMOVE',
    updateProgress: 'UPDATE_PERCENT',
    updateName: 'UPDATE_NAME',
    updateStyle: 'UPDATE_STYLE',
    updateProperties: 'UPDATE_PROPERTIES',
};

class JsEvent {
    /**
     * @param {string} jsName JsMacros event name surfaced by getEventName()
     * @param {object} entry mapping entry from names.js
     * @param {boolean} syncDelivered whether this instance was delivered by a
     *        joined (onSync) subscription, the only path whose cancel is honored
     */
    constructor(jsName, entry, syncDelivered) {
        this._jsName = jsName;
        this._entry = entry;
        this._syncDelivered = !!syncDelivered;
        this._cancelled = false;
    }

    cancellable() {
        return !!this._entry?.jsCancellable;
    }

    joinable() {
        // JsMacros joinable events exist; under NeoMacros every subscription
        // behaves like a non-joined one except the sync-capable subset.
        return true;
    }

    cancel() {
        if (!this.cancellable()) {
            throw new Error(`${this._jsName} is not a cancellable event`);
        }
        // JsMacros semantics: cancel on a non-joined delivery is a silent
        // no-op, so the flag is recorded but only sync delivery honors it.
        this._cancelled = true;
    }

    isCanceled() {
        return this._cancelled && this._syncDelivered;
    }

    getEventName() {
        return this._jsName;
    }

    trigger() {
        unimplemented(`BaseEvent.trigger(${this._jsName})`, 're-triggering built-in events is not possible under NeoMacros');
    }
}

function fillEventMembers(obj, surfaceClass, reason) {
    const entry = SURFACE[surfaceClass];
    if (entry) {
        for (const name of Object.keys(entry.methods)) {
            if (name in obj) continue;
            const stubFn = function stub() {
                unimplemented(`${surfaceClass}.${name}`, reason);
            };
            stubFn.__compatStub = reason;
            obj[name] = stubFn;
        }
    }
    fillSurfaceFields(obj, surfaceClass, reason);
}

/** Field that reads normally but rejects JsMacros-style rewrites. */
function rewriteBlocked(obj, name, value) {
    let current = value;
    Object.defineProperty(obj, name, {
        get() {
            return current;
        },
        set() {
            unimplemented(`${name} (write)`, 'NeoMacros only supports cancelling this event, not rewriting it');
        },
        configurable: true,
    });
}

function isPress(action) {
    return String(action ?? '').toLowerCase().startsWith('pre');
}

function modsString(modifiers) {
    if (!Array.isArray(modifiers)) return '';
    const order = [];
    let rest = modifiers.map(String);
    const pick = (needle, name) => {
        rest = rest.filter((m) => {
            if (m.toLowerCase().includes(needle)) {
                order.push(name);
                return false;
            }
            return true;
        });
    };
    pick('shift', 'left.shift');
    pick('ctrl', 'left.control');
    pick('control', 'left.control');
    pick('alt', 'left.alt');
    return [...order, ...rest].join('+');
}

class BossBarCompat {
    constructor(payload) {
        this._p = payload;
    }

    getName() {
        return TextHelperCompat.fromString(String(this._p?.name ?? ''));
    }

    getPercent() {
        return this._p?.progress;
    }

    getUuid() {
        return this._p?.uuid;
    }

    toString() {
        return `BossBar(${this._p?.name})`;
    }
}

class PlayerListEntryCompat {
    constructor(name, uuid) {
        this._name = name;
        this._uuid = uuid;
    }

    getName() {
        return this._name;
    }

    getUuid() {
        return this._uuid;
    }

    toString() {
        return `PlayerListEntry(${this._name})`;
    }
}

class EffectCompat {
    constructor(effectId, amplifier) {
        this._id = effectId;
        this._amplifier = amplifier;
    }

    getId() {
        return this._id;
    }

    getAmplifier() {
        return this._amplifier;
    }

    toString() {
        return `${this._id} x${(this._amplifier ?? 0) + 1}`;
    }
}

const ADAPTERS = {
    tick: {
        cls: 'EventTick',
        build(neoPayload) {
            return {};
        },
    },
    key: {
        cls: 'EventKey',
        build(neoPayload) {
            return {
                action: isPress(neoPayload.action) ? 1 : 0,
                key: neoPayload.key,
                mods: modsString(neoPayload.modifiers),
            };
        },
    },
    mouseScroll: {
        cls: 'EventMouseScroll',
        build(neoPayload) {
            return { deltaX: 0, deltaY: neoPayload.amount };
        },
    },
    recvMessage: {
        cls: 'EventRecvMessage',
        // `text` is defined separately in adapt() as a rewrite-blocked field.
        build(neoPayload) {
            return { signature: null, messageType: null };
        },
    },
    sendMessage: {
        cls: 'EventSendMessage',
        build(neoPayload) {
            return { message: neoPayload.message };
        },
    },
    sound: {
        cls: 'EventSound',
        build(neoPayload) {
            const pos = neoPayload.pos ?? { x: 0, y: 0, z: 0 };
            return {
                sound: neoPayload.soundId,
                volume: neoPayload.volume,
                pitch: neoPayload.pitch,
                position: new CompatPos3D(pos.x, pos.y, pos.z),
            };
        },
    },
    bossbar: {
        cls: 'EventBossbar',
        build(neoPayload) {
            return {
                bossBar: new BossBarCompat(neoPayload),
                uuid: neoPayload.uuid,
                type: BOSSBAR_TYPES[neoPayload.action] ?? neoPayload.action,
            };
        },
    },
    joinServer: {
        cls: 'EventJoinServer',
        build() {
            const self = neo.player.self;
            return { player: self ? createEntity(self) : null };
        },
    },
    disconnect: {
        cls: 'EventDisconnect',
        build() {
            return {};
        },
    },
    dimensionChange: {
        cls: 'EventDimensionChange',
        build(neoPayload) {
            return { dimension: neoPayload.to };
        },
    },
    chunkLoad: {
        cls: 'EventChunkLoad',
        build(neoPayload) {
            return { x: neoPayload.chunk?.x, z: neoPayload.chunk?.z };
        },
    },
    chunkUnload: {
        cls: 'EventChunkUnload',
        build(neoPayload) {
            return { x: neoPayload.chunk?.x, z: neoPayload.chunk?.z };
        },
    },
    blockUpdate: {
        cls: 'EventBlockUpdate',
        build(neoPayload) {
            const pos = neoPayload.pos ?? { x: 0, y: 0, z: 0 };
            return { block: blockDataAt(pos.x, pos.y, pos.z), updateType: 'STATE' };
        },
    },
    entityLoad: {
        cls: 'EventEntityLoad',
        build(neoPayload) {
            return { entity: createEntity(neoPayload.entity) };
        },
    },
    entityUnload: {
        cls: 'EventEntityUnload',
        build(neoPayload) {
            return { entity: createEntity(neoPayload.entity) };
        },
    },
    entityDamaged: {
        cls: 'EventEntityDamaged',
        build(neoPayload) {
            const snap = neoPayload.entity;
            return { entity: createEntity(snap), health: snap?.health, damage: neoPayload.amount };
        },
    },
    entityHealed: {
        cls: 'EventEntityHealed',
        build(neoPayload) {
            const snap = neoPayload.entity;
            return { entity: createEntity(snap), health: snap?.health, damage: neoPayload.amount };
        },
    },
    playerJoin: {
        cls: 'EventPlayerJoin',
        build(neoPayload) {
            const snap = neoPayload.player;
            return {
                UUID: snap?.uuid,
                player: new PlayerListEntryCompat(snap?.name, snap?.uuid),
            };
        },
    },
    playerLeave: {
        cls: 'EventPlayerLeave',
        build(neoPayload) {
            return {
                UUID: neoPayload.uuid,
                player: new PlayerListEntryCompat(neoPayload.name, neoPayload.uuid),
            };
        },
    },
    airChange: {
        cls: 'EventAirChange',
        build(neoPayload) {
            return { air: neoPayload.air };
        },
    },
    attackBlock: {
        cls: 'EventAttackBlock',
        build(neoPayload) {
            const pos = neoPayload.block?.pos ?? { x: 0, y: 0, z: 0 };
            return {
                block: neoPayload.block ? new BlockDataCompat(neoPayload.block) : null,
                side: FACE_TO_ID[String(neoPayload.face ?? '').toLowerCase()] ?? -1,
            };
        },
    },
    attackEntity: {
        cls: 'EventAttackEntity',
        build(neoPayload) {
            return { entity: createEntity(neoPayload.target) };
        },
    },
    interactBlock: {
        cls: 'EventInteractBlock',
        build(neoPayload) {
            return {
                block: neoPayload.block ? new BlockDataCompat(neoPayload.block) : null,
                side: FACE_TO_ID[String(neoPayload.face ?? '').toLowerCase()] ?? -1,
            };
        },
    },
    interactEntity: {
        cls: 'EventInteractEntity',
        build(neoPayload) {
            return { entity: createEntity(neoPayload.target) };
        },
    },
    damage: {
        cls: 'EventDamage',
        build(neoPayload) {
            return { health: neoPayload.health, change: neoPayload.amount };
        },
    },
    heal: {
        cls: 'EventHeal',
        build(neoPayload) {
            return { health: neoPayload.health, change: neoPayload.amount };
        },
    },
    healthChange: {
        cls: 'EventHealthChange',
        build(neoPayload) {
            return { health: neoPayload.health };
        },
    },
    death: {
        cls: 'EventDeath',
        build(neoPayload) {
            const pos = neoPayload.player?.pos;
            return { deathPos: pos ? new CompatBlockPos(pos.x, pos.y, pos.z) : null };
        },
    },
    expChange: {
        cls: 'EventEXPChange',
        build(neoPayload) {
            return { level: neoPayload.level, progress: neoPayload.progress };
        },
    },
    fallFlying: {
        cls: 'EventFallFlying',
        build(neoPayload) {
            return { state: neoPayload.gliding };
        },
    },
    heldItemChange: {
        cls: 'EventHeldItemChange',
        build(neoPayload) {
            return {
                offHand: false,
                item: neoPayload.current ? new ItemStackCompat(neoPayload.current) : null,
                oldItem: neoPayload.previous ? new ItemStackCompat(neoPayload.previous) : null,
            };
        },
    },
    hungerChange: {
        cls: 'EventHungerChange',
        build(neoPayload) {
            return { foodLevel: neoPayload.hunger };
        },
    },
    openScreen: {
        cls: 'EventOpenScreen',
        build(neoPayload, meta) {
            // JsMacros fires OpenScreen on open and on close (with nulls).
            if (meta?.closing) {
                return { screen: null, screenName: null };
            }
            return { screen: null, screenName: neoPayload.title };
        },
    },
    statusEffectUpdate: {
        cls: 'EventStatusEffectUpdate',
        build(neoPayload) {
            const added = !!neoPayload.added;
            const effect = new EffectCompat(neoPayload.effectId, neoPayload.amplifier);
            return {
                added,
                removed: !added,
                newEffect: added ? effect : null,
                // NeoMacros carries no previous-effect data; the removal edge
                // reports the removed effect's own id and amplifier.
                oldEffect: added ? null : effect,
            };
        },
    },
    launchGame: {
        cls: 'EventLaunchGame',
        build() {
            return {};
        },
    },
    quitGame: {
        cls: 'EventQuitGame',
        build() {
            return {};
        },
    },
};

/**
 * Adapts one neo payload into a JsMacros event object.
 * @param {object} entry mapping entry carrying the adapter key and name
 * @param {string} jsName resolved JsMacros event name
 * @param {object} neoPayload the raw neo payload
 * @param {{sync?: boolean, closing?: boolean}} meta delivery context
 */
export function adapt(entry, jsName, neoPayload, meta) {
    const adapter = ADAPTERS[entry.adapter];
    if (!adapter) {
        throw new Error(`no payload adapter registered for ${jsName}`);
    }
    if (jsName === 'ANYTHING') {
        return anythingEvent(neoPayload, meta);
    }
    const ev = new JsEvent(jsName, entry, meta?.sync);
    if (jsName === 'RecvMessage') {
        rewriteBlocked(ev, 'text', new TextHelperCompat(neoPayload.message));
    }
    const props = adapter.build(neoPayload, meta, ev);
    Object.assign(ev, props);
    fillEventMembers(ev, adapter.cls, FIELD_REASON);
    return ev;
}

/** Generic JsMacros-shaped event for wildcard (ANYTHING) deliveries. */
function anythingEvent(neoPayload, meta) {
    const neoName = neoPayload?.type ?? '';
    const jsName = fromNeoName(neoName) ?? neoName;
    const ev = new JsEvent(jsName || 'ANYTHING', null, meta?.sync);
    const payload = neoPayload ?? {};
    for (const key of Object.keys(payload)) {
        if (!(key in ev)) ev[key] = payload[key];
    }
    ev.getEventName = () => jsName || 'ANYTHING';
    return ev;
}
