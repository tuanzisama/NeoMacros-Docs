// JsMacros Inventory helpers over the neo Inventory handle. All mutating
// actions dispatch through the game like their neo counterparts and return
// promises; the base query surface reads live. Slot-section layouts (getMap
// and friends) are unavailable because NeoMacros exposes no slot map.
import { unimplemented } from '../support/errors.js';
import { fillStubs } from '../support/stubTable.js';
import { ItemStackCompat } from '../support/itemStack.js';
import { TradeOfferHelperCompat } from './tradeOffer.js';

const KIND_LABELS = {
    player: 'Survival Inventory',
    creative: 'Creative',
    chest: 'Chest',
    crafting: 'Crafting',
    furnace: 'Furnace',
    anvil: 'Anvil',
    enchanting: 'Enchant',
    brewing: 'Brewing Stand',
    villager: 'Villager',
    loom: 'Loom',
    stonecutter: 'Stone Cutter',
    smithing: 'Smithing',
    cartography: 'Cartography',
    grindstone: 'Grind Stone',
    beacon: 'Beacon',
    horse: 'Horse',
};

function itemIdOf(stackOrId) {
    if (typeof stackOrId === 'string') {
        const s = stackOrId;
        return s.includes(':') ? s : `minecraft:${s}`;
    }
    return stackOrId.getItemId();
}

export class InventoryCompat {
    constructor(neoInv) {
        this._inv = neoInv;
    }

    _require() {
        if (!this._inv) {
            unimplemented('Inventory', 'no inventory screen is open');
        }
        return this._inv;
    }

    getType() {
        const kind = this._require().kind;
        return KIND_LABELS[kind] ?? String(kind);
    }

    is(...types) {
        const kind = this._require().kind;
        const label = KIND_LABELS[kind] ?? String(kind);
        return types.some((t) => t === label || t === kind);
    }

    getTotalSlots() {
        return this._require().size;
    }

    getSlot(i) {
        const stack = this._require().slot(i);
        return stack ? new ItemStackCompat(stack) : null;
    }

    getItems() {
        const inv = this._require();
        const out = [];
        for (let i = 0; i < inv.size; i++) {
            const stack = inv.slot(i);
            out.push(stack ? new ItemStackCompat(stack) : null);
        }
        return out;
    }

    contains(stackOrId) {
        const inv = this._require();
        if (typeof stackOrId === 'string') {
            return !!inv.contains(itemIdOf(stackOrId));
        }
        return !!inv.contains(stackOrId.getItemId());
    }

    findItem(stackOrId) {
        return this._require().findAll(itemIdOf(stackOrId));
    }

    getItemCount() {
        const counts = {};
        for (const stack of this.getItems()) {
            if (!stack || stack.isEmpty()) continue;
            const id = stack.getItemId();
            counts[id] = (counts[id] ?? 0) + stack.getCount();
        }
        return counts;
    }

    findFreeSlot() {
        const inv = this._require();
        for (let i = 0; i < inv.size; i++) {
            const stack = inv.slot(i);
            if (!stack || stack.isEmpty()) return i;
        }
        return -1;
    }

    click(slot, mouseButton) {
        return this._require().click(slot, mouseButton ?? 0, false);
    }

    dropSlot(slot, all) {
        return this._require().drop(slot, !!all);
    }

    quick(slot) {
        return this._require().quickMove(slot);
    }

    swapHotbar(slot, hotbarSlot) {
        if (hotbarSlot === 40) {
            unimplemented('Inventory.swapHotbar(slot, 40)', 'NeoMacros hotbar swaps cover indexes 0..8 only');
        }
        return this._require().swapHotbar(slot, hotbarSlot);
    }

    split(slot1, slot2) {
        const inv = this._require();
        // Right-click picks up half the stack, left-click places it.
        return inv.click(slot1, 1, false).then(() => inv.click(slot2, 0, false));
    }

    grabAll(slot) {
        return this._require().click(slot, 0, false);
    }

    closeAndDrop() {
        const inv = this._require();
        return inv.close().then(() => neo.player.self.dropHeld(true));
    }

    close() {
        return this._require().close();
    }

    getContainerTitle() {
        return this._require().title;
    }

    isContainer() {
        return this._require().kind !== 'player';
    }

    toString() {
        return `Inventory(${this._inv?.kind})`;
    }
}

fillStubs(InventoryCompat.prototype, 'Inventory', 'cursor, slot-map layout, and raw container access are not exposed by the neo Inventory surface');

// RecipeInventory sits between the base and the implemented PlayerInventory.
export class RecipeInventoryCompat extends InventoryCompat {
}

fillStubs(RecipeInventoryCompat.prototype, 'RecipeInventory', 'recipe-book state is not exposed by the neo Inventory surface');

export class PlayerInventoryCompat extends RecipeInventoryCompat {
    toString() {
        return `Inventory(${this._inv?.kind ?? 'player'})`;
    }
}

fillStubs(PlayerInventoryCompat.prototype, 'PlayerInventory', 'armor/offhand/crafting slot layout is not exposed by the neo Inventory surface');

// Specialized shells: their type-specific methods keep JsMacros names and
// throw; the inherited base query/action surface keeps working.
const SHELL_REASON = 'specialized inventory feature is not exposed by the neo Inventory surface';

function inventoryShell(jsClassName) {
    const cls = class extends InventoryCompat {
    };
    Object.defineProperty(cls, 'name', { value: jsClassName });
    fillStubs(cls.prototype, jsClassName, SHELL_REASON);
    return cls;
}

// Furnace bridge: neo FurnaceInventory handle (input/fuel/output/lit/progress).
class FurnaceInventoryCompat extends InventoryCompat {
    getInput() { return this._inv ? this._inv.input ?? null : null; }
    getFuel() { return this._inv ? this._inv.fuel ?? null : null; }
    getSmeltedItem() { return this._inv ? this._inv.output ?? null : null; }
    isBurning() { return this._inv ? this._inv.lit === true : false; }
    getSmeltingProgress() { return this._inv ? this._inv.litProgress ?? null : null; }
}

// Chest bridge: first free container slot.
class ContainerInventoryCompat extends InventoryCompat {
    findFreeContainerSlot() { return this._inv ? this._inv.firstEmpty ?? null : null; }
}

// Crafting bridge: the 3x3 grid and result.
class CraftingInventoryCompat extends InventoryCompat {
    getInput() { return this._inv ? this._inv.grid ?? [] : []; }
    getInputSize() { return this._inv && this._inv.grid ? this._inv.grid.length : 0; }
    getOutput() { return this._inv ? this._inv.result ?? null : null; }
}

// Anvil bridge: inputs, result, and the level cost.
class AnvilInventoryCompat extends InventoryCompat {
    getLeftInput() { return this._inv ? this._inv.firstInput ?? null : null; }
    getRightInput() { return this._inv ? this._inv.secondInput ?? null : null; }
    getOutput() { return this._inv ? this._inv.result ?? null : null; }
    getItemRepairCost() { return this._inv ? this._inv.cost ?? null : null; }
}

// Enchanting bridge: item, lapis, and the three costs.
class EnchantInventoryCompat extends InventoryCompat {
    getItemToEnchant() { return this._inv ? this._inv.item ?? null : null; }
    getLapis() { return this._inv ? this._inv.lapis ?? null : null; }
    getEnchantmentLevels() { return this._inv ? this._inv.costs ?? [] : []; }
    getGoldCount() { return this._inv ? this._inv.goldCount ?? null : null; }
}

// Grindstone bridge: top/bottom inputs and the result.
class GrindStoneInventoryCompat extends InventoryCompat {
    getTopInput() { return this._inv ? this._inv.topInput ?? null : null; }
    getBottomInput() { return this._inv ? this._inv.bottomInput ?? null : null; }
    getOutput() { return this._inv ? this._inv.result ?? null : null; }
}

// Stonecutter bridge: input, count, and the selected recipe index.
class StoneCutterInventoryCompat extends InventoryCompat {
    getInput() { return this._inv ? this._inv.input ?? null : null; }
    getAvailableRecipeCount() { return this._inv ? this._inv.recipeCount ?? 0 : 0; }
    getSelectedRecipe() { return this._inv ? this._inv.selectedRecipeIndex ?? null : null; }
}

// Smithing bridge: template/base/addition and result.
class SmithingInventoryCompat extends InventoryCompat {
    getTemplate() { return this._inv ? this._inv.template ?? null : null; }
    getBase() { return this._inv ? this._inv.base ?? null : null; }
    getAddition() { return this._inv ? this._inv.addition ?? null : null; }
    getOutput() { return this._inv ? this._inv.result ?? null : null; }
}

// Cartography bridge: map/material/result.
class CartographyInventoryCompat extends InventoryCompat {
    getMapItem() { return this._inv ? this._inv.map ?? null : null; }
    getMaterial() { return this._inv ? this._inv.material ?? null : null; }
    getOutput() { return this._inv ? this._inv.result ?? null : null; }
}

// Beacon bridge: payment, level, and selected effects.
class BeaconInventoryCompat extends InventoryCompat {
    getPayment() { return this._inv ? this._inv.payment ?? null : null; }
    getLevel() { return this._inv ? this._inv.levels ?? null : null; }
    getFirstEffect() { return this._inv ? this._inv.primaryEffect ?? null : null; }
    getSecondEffect() { return this._inv ? this._inv.secondaryEffect ?? null : null; }
}

// Brewing bridge: bottles, ingredient, fuel, and the live brew progress.
class BrewingStandInventoryCompat extends InventoryCompat {
    getBottles() { return this._inv ? this._inv.bottles ?? [] : []; }
    getIngredient() { return this._inv ? this._inv.ingredient ?? null : null; }
    getFuel() { return this._inv ? this._inv.fuel ?? null : null; }
    getFuelCount() { return this._inv ? this._inv.fuelUses ?? null : null; }
    getBrewTime() { return this._inv ? this._inv.brewingTicks ?? null : null; }
}

// Villager bridge: trader level, experience, and the live trade offers.
class VillagerInventoryCompat extends InventoryCompat {
    getLevel() { return this._inv ? this._inv.traderLevel ?? null : null; }
    getExperience() { return this._inv ? this._inv.traderXp ?? null : null; }
    getLevelProgress() { return this._inv ? this._inv.futureTraderXp ?? null : null; }
    getTrades() {
        const trades = this._inv && this._inv.trades ? this._inv.trades : [];
        return trades.map((offer, index) => new TradeOfferHelperCompat(offer, index, this));
    }
}

// Mount bridge: the saddle and body-armor slots over the shared slot face.
class HorseInventoryCompat extends InventoryCompat {
    getSaddle() { return this._inv ? this._inv.saddle ?? null : null; }
    getArmor() { return this._inv ? this._inv.armor ?? null : null; }
}
fillStubs(HorseInventoryCompat.prototype, 'HorseInventory', SHELL_REASON);

fillStubs(FurnaceInventoryCompat.prototype, 'FurnaceInventory', SHELL_REASON);
fillStubs(ContainerInventoryCompat.prototype, 'ContainerInventory', SHELL_REASON);
fillStubs(CraftingInventoryCompat.prototype, 'CraftingInventory', SHELL_REASON);
fillStubs(AnvilInventoryCompat.prototype, 'AnvilInventory', SHELL_REASON);
fillStubs(EnchantInventoryCompat.prototype, 'EnchantInventory', SHELL_REASON);
fillStubs(GrindStoneInventoryCompat.prototype, 'GrindStoneInventory', SHELL_REASON);
fillStubs(StoneCutterInventoryCompat.prototype, 'StoneCutterInventory', SHELL_REASON);
fillStubs(SmithingInventoryCompat.prototype, 'SmithingInventory', SHELL_REASON);
fillStubs(CartographyInventoryCompat.prototype, 'CartographyInventory', SHELL_REASON);
fillStubs(BeaconInventoryCompat.prototype, 'BeaconInventory', SHELL_REASON);
fillStubs(BrewingStandInventoryCompat.prototype, 'BrewingStandInventory', SHELL_REASON);
fillStubs(VillagerInventoryCompat.prototype, 'VillagerInventory', SHELL_REASON);

export const INVENTORY_SHELLS = {
    ContainerInventory: ContainerInventoryCompat,
    CraftingInventory: CraftingInventoryCompat,
    FurnaceInventory: FurnaceInventoryCompat,
    AnvilInventory: AnvilInventoryCompat,
    EnchantInventory: EnchantInventoryCompat,
    VillagerInventory: VillagerInventoryCompat,
    BeaconInventory: BeaconInventoryCompat,
    BrewingStandInventory: BrewingStandInventoryCompat,
    CartographyInventory: CartographyInventoryCompat,
    GrindStoneInventory: GrindStoneInventoryCompat,
    HorseInventory: HorseInventoryCompat,
    LoomInventory: inventoryShell('LoomInventory'),
    SmithingInventory: SmithingInventoryCompat,
    StoneCutterInventory: StoneCutterInventoryCompat,
    CreativeInventory: inventoryShell('CreativeInventory'),
};

const KIND_DISPATCH = {
    player: PlayerInventoryCompat,
    creative: INVENTORY_SHELLS.CreativeInventory,
    chest: INVENTORY_SHELLS.ContainerInventory,
    generic: INVENTORY_SHELLS.ContainerInventory,
    container: INVENTORY_SHELLS.ContainerInventory,
    furnace: INVENTORY_SHELLS.FurnaceInventory,
    crafting: INVENTORY_SHELLS.CraftingInventory,
    anvil: INVENTORY_SHELLS.AnvilInventory,
    enchant: INVENTORY_SHELLS.EnchantInventory,
    villager: INVENTORY_SHELLS.VillagerInventory,
    beacon: INVENTORY_SHELLS.BeaconInventory,
    brewing: INVENTORY_SHELLS.BrewingStandInventory,
    cartography: INVENTORY_SHELLS.CartographyInventory,
    grindstone: INVENTORY_SHELLS.GrindStoneInventory,
    horse: INVENTORY_SHELLS.HorseInventory,
    loom: INVENTORY_SHELLS.LoomInventory,
    smithing: INVENTORY_SHELLS.SmithingInventory,
    stonecutter: INVENTORY_SHELLS.StoneCutterInventory,
};

/** JsMacros Inventory.create equivalent: wraps the open inventory screen. */
export function openInventoryCompat() {
    const inv = neo.player.inventory ?? neo.player.self?.inventory;
    if (!inv) {
        unimplemented('Player.openInventory', 'the local player is not in a world');
    }
    const Cls = KIND_DISPATCH[inv.kind] ?? INVENTORY_SHELLS.ContainerInventory;
    return new Cls(inv);
}
