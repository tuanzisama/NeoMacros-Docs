// The Hud global plus Draw2D/Draw3D helpers. Both keep the JsMacros
// register/unregister lifecycle and rebuild their shapes through the
// persistent neo.hud text overlay and neo.render layers: 2D supports the
// Text element family, 3D supports boxes, lines, and points; everything
// else (rects, images, items, surfaces, traces, screens, textures) keeps
// its name and throws.
import { unimplemented } from '../support/errors.js';
import { defineStubs, fillStubs } from '../support/stubTable.js';
import { TextHelperCompat } from '../support/text.js';

let drawCounter = 0;

function swallow(promise) {
    if (promise && typeof promise.catch === 'function') promise.catch(() => undefined);
}

function argbWithAlpha(color, alpha) {
    if (alpha === undefined) return color;
    return ((alpha & 0xff) << 24) | (color & 0xffffff);
}

class TextElementCompat {
    constructor(owner, text, x, y, color) {
        this._owner = owner;
        this._text = String(text);
        this._x = x;
        this._y = y;
        this._color = color;
    }

    get text() {
        return this._text;
    }

    set text(value) {
        this._text = String(value);
        this._redraw();
    }

    get x() {
        return this._x;
    }

    set x(value) {
        this._x = value;
        this._redraw();
    }

    get y() {
        return this._y;
    }

    set y(value) {
        this._y = value;
        this._redraw();
    }

    get color() {
        return this._color;
    }

    set color(value) {
        this._color = value;
        this._redraw();
    }

    _redraw() {
        this._owner._redrawElement(this);
    }

    setText(value) {
        this._text = value instanceof TextHelperCompat ? value.getFormatted() : String(value);
        this._redraw();
    }

    setPos(x, y) {
        this._x = x;
        this._y = y;
        this._redraw();
    }

    setColor(color) {
        this._color = color;
        this._redraw();
    }

    getPosX() {
        return this.x;
    }

    getPosY() {
        return this.y;
    }

    getColor() {
        return this.color;
    }

    getText() {
        return this.text;
    }

    toString() {
        return `Text(${String(this.text).slice(0, 24)})`;
    }
}

fillStubs(TextElementCompat.prototype, 'Text', 'scale, rotation, shadow, alignment, and z-index styling have no neo.hud equivalent');

export class Draw2DCompat {
    constructor() {
        this._elements = [];
        this._registered = false;
        this._onInit = null;
        this.id = `jsm-compat-2d-${++drawCounter}`;
    }

    _commitElement(el) {
        swallow(neo.hud.addText(el.id, String(el.text), el.x, el.y, el.color));
    }

    _redrawElement(el) {
        if (!this._registered) return;
        swallow(neo.hud.removeText(el.id).then(() => this._commitElement(el)));
    }

    register() {
        if (this._registered) return this;
        this._registered = true;
        swallow(neo.hud.removeText(this.id + ':init'));
        if (this._onInit) {
            // JsMacros init clears all elements, then the callback re-adds.
            this._elements = [];
            this._onInit();
        }
        for (const el of this._elements) this._commitElement(el);
        return this;
    }

    unregister() {
        this._registered = false;
        for (const el of this._elements) swallow(neo.hud.removeText(el.id));
        return this;
    }

    addText(text, x, y, color, shadow, zIndex, scale, rotation) {
        if (zIndex !== undefined || scale !== undefined || rotation !== undefined) {
            unimplemented('Draw2D.addText(zIndex/scale/rotation)', 'neo.hud text has no z-index, scale, or rotation');
        }
        const rendered = text instanceof TextHelperCompat ? text.getFormatted() : String(text);
        const el = new TextElementCompat(this, rendered, x, y, color);
        this._elements.push(el);
        if (this._registered) this._commitElement(el);
        return el;
    }

    setOnInit(callback) {
        this._onInit = callback;
        return this;
    }

    setOnFailInit(callback) {
        // Registration cannot fail under NeoMacros; the callback is stored
        // and never invoked.
        return this;
    }

    removeElement(element) {
        const idx = this._elements.indexOf(element);
        if (idx !== -1) {
            this._elements.splice(idx, 1);
            if (this._registered) swallow(neo.hud.removeText(element.id));
        }
        return this;
    }

    reAddElement(element) {
        if (!this._elements.includes(element)) this._elements.push(element);
        if (this._registered) this._commitElement(element);
        return this;
    }

    getElements() {
        return [...this._elements];
    }

    isVisible() {
        return this._registered;
    }

    setVisible(visible) {
        return visible ? this.register() : this.unregister();
    }

    toString() {
        return `Draw2D(${this.id}, ${this._elements.length} elements)`;
    }
}

fillStubs(Draw2DCompat.prototype, 'Draw2D', 'rect, line, image, item, and nested-2D elements have no neo.hud equivalent');

class BoxElementCompat {
    constructor(owner, min, max, color) {
        this._owner = owner;
        this._min = min;
        this._max = max;
        this._color = color;
    }

    get min() {
        return this._min;
    }

    set min(value) {
        this._min = value;
        this._owner._redrawAll();
    }

    get max() {
        return this._max;
    }

    set max(value) {
        this._max = value;
        this._owner._redrawAll();
    }

    get color() {
        return this._color;
    }

    set color(value) {
        this._color = value;
        this._owner._redrawAll();
    }

    setPos1(x1, y1, z1) {
        this._min = typeof x1 === 'object' ? x1 : { x: x1, y: y1, z: z1 };
        this._owner._redrawAll();
    }

    setPos2(x2, y2, z2) {
        this._max = typeof x2 === 'object' ? x2 : { x: x2, y: y2, z: z2 };
        this._owner._redrawAll();
    }

    setColor(color) {
        this._color = color;
        this._owner._redrawAll();
    }

    toString() {
        return `Box(${this.min.x},${this.min.y},${this.min.z} -> ${this.max.x},${this.max.y},${this.max.z})`;
    }
}

fillStubs(BoxElementCompat.prototype, 'Box', 'fill color and cull settings have no neo.render equivalent');

class Line3DElementCompat {
    constructor(owner, from, to, color) {
        this._owner = owner;
        this._from = from;
        this._to = to;
        this._color = color;
    }

    get from() {
        return this._from;
    }

    set from(value) {
        this._from = value;
        this._owner._redrawAll();
    }

    get to() {
        return this._to;
    }

    set to(value) {
        this._to = value;
        this._owner._redrawAll();
    }

    get color() {
        return this._color;
    }

    set color(value) {
        this._color = value;
        this._owner._redrawAll();
    }

    setPos1(x1, y1, z1) {
        this._from = typeof x1 === 'object' ? x1 : { x: x1, y: y1, z: z1 };
        this._owner._redrawAll();
    }

    setPos2(x2, y2, z2) {
        this._to = typeof x2 === 'object' ? x2 : { x: x2, y: y2, z: z2 };
        this._owner._redrawAll();
    }

    setColor(color) {
        this._color = color;
        this._owner._redrawAll();
    }

    toString() {
        return `Line3D(${this.from.x},${this.from.y},${this.from.z} -> ${this.to.x},${this.to.y},${this.to.z})`;
    }
}

fillStubs(Line3DElementCompat.prototype, 'Line3D', 'alpha and cull setters have no neo.render equivalent');

export class Draw3DCompat {
    constructor() {
        this._boxes = [];
        this._lines = [];
        this._registered = false;
        this.layerId = `jsm-compat-3d-${++drawCounter}`;
    }

    _drawBox(box) {
        neo.render.drawBox(this.layerId, box.min, box.max, box.color);
    }

    _drawLine(line) {
        neo.render.drawLine(this.layerId, line.from, line.to, line.color);
    }

    _redrawAll() {
        if (!this._registered) return;
        neo.render.clearLayer(this.layerId);
        for (const box of this._boxes) this._drawBox(box);
        for (const line of this._lines) this._drawLine(line);
    }

    register() {
        this._registered = true;
        this._redrawAll();
        return this;
    }

    unregister() {
        this._registered = false;
        neo.render.clearLayer(this.layerId);
        return this;
    }

    addBox(x1, y1, z1, x2, y2, z2, color, fillColor, fill, cull) {
        if (fill) {
            unimplemented('Draw3D.addBox(fill)', 'neo.render draws wireframe boxes only');
        }
        const min = typeof x1 === 'object' ? x1 : { x: Math.min(x1, x2), y: Math.min(y1, y2), z: Math.min(z1, z2) };
        const max = typeof x2 === 'object' ? x2 : { x: Math.max(x1, x2), y: Math.max(y1, y2), z: Math.max(z1, z2) };
        const box = new BoxElementCompat(this, min, max, color);
        this._boxes.push(box);
        if (this._registered) this._drawBox(box);
        return box;
    }

    addLine(x1, y1, z1, x2, y2, z2, color, alpha, cull) {
        const from = typeof x1 === 'object' ? x1 : { x: x1, y: y1, z: z1 };
        const to = typeof z2 === 'object' ? z2 : { x: x2, y: y2, z: z2 };
        const line = new Line3DElementCompat(this, from, to, argbWithAlpha(color, alpha));
        this._lines.push(line);
        if (this._registered) this._drawLine(line);
        return line;
    }

    addPoint(posOrX, yOrRadius, zOrColor, radiusOrAlpha, color, alpha, cull) {
        // Two forms: (Pos3D, radius, color[, alpha[, cull]]) and
        // (x, y, z, radius, color[, alpha[, cull]]). Points are rendered as
        // small wireframe cubes, like the JsMacros implementation.
        let center;
        let radius;
        let argb;
        if (typeof posOrX === 'object') {
            center = posOrX;
            radius = yOrRadius;
            argb = argbWithAlpha(zOrColor, radiusOrAlpha);
        } else {
            center = { x: posOrX, y: yOrRadius, z: zOrColor };
            radius = radiusOrAlpha;
            argb = argbWithAlpha(color, alpha);
        }
        return this.addBox(
            center.x - radius, center.y - radius, center.z - radius,
            center.x + radius, center.y + radius, center.z + radius,
            argb, argb, false, true,
        );
    }

    removeBox(box) {
        const idx = this._boxes.indexOf(box);
        if (idx !== -1) {
            this._boxes.splice(idx, 1);
            this._redrawAll();
        }
    }

    removeLine(line) {
        const idx = this._lines.indexOf(line);
        if (idx !== -1) {
            this._lines.splice(idx, 1);
            this._redrawAll();
        }
    }

    clear() {
        this._boxes = [];
        this._lines = [];
        neo.render.clearLayer(this.layerId);
    }

    getBoxes() {
        return [...this._boxes];
    }

    getLines() {
        return [...this._lines];
    }

    getTraceLines() {
        return [];
    }

    getEntityTraceLines() {
        return [];
    }

    getDraw2Ds() {
        return [];
    }

    toString() {
        return `Draw3D(${this.layerId}, ${this._boxes.length} boxes, ${this._lines.length} lines)`;
    }
}

fillStubs(Draw3DCompat.prototype, 'Draw3D', 'trace lines and in-world surfaces have no neo.render equivalent');

const draw2ds = new Set();
const draw3ds = new Set();

export const HudCompat = {
    getOpenScreen() {
        const opened = neo.player.screen;
        if (opened === undefined || opened === null) return null;
        return {
            getTitle() { return opened.title; },
            getContainer() { return opened.container ?? neo.player.inventory; },
        };
    },

    getOpenScreenName() {
        const opened = neo.player.screen;
        return opened === undefined || opened === null ? null : String(opened.title);
    },

    isContainer() {
        const opened = neo.player.screen;
        return opened !== undefined && opened !== null && opened.kind !== "screen";
    },

    getScaleFactor() {
        const window = neo.client.window;
        if (window === undefined || window === null) return 1;
        return Math.max(1, Math.round(window.width / Math.max(1, window.scaledWidth)));
    },

    getMouseX() {
        return neo.client.mouse.x;
    },

    getMouseY() {
        return neo.client.mouse.y;
    },

    getWindowWidth() {
        const window = neo.client.window;
        return window === undefined || window === null ? 0 : window.width;
    },

    getWindowHeight() {
        const window = neo.client.window;
        return window === undefined || window === null ? 0 : window.height;
    },

    createDraw2D() {
        const d = new Draw2DCompat();
        draw2ds.add(d);
        return d;
    },

    createDraw3D() {
        const d = new Draw3DCompat();
        draw3ds.add(d);
        return d;
    },

    registerDraw2D(draw2d) {
        draw2d.register();
    },

    unregisterDraw2D(draw2d) {
        draw2d.unregister();
    },

    registerDraw3D(draw3d) {
        draw3d.register();
    },

    unregisterDraw3D(draw3d) {
        draw3d.unregister();
    },

    listDraw2Ds() {
        return [...draw2ds];
    },

    listDraw3Ds() {
        return [...draw3ds];
    },

    clearDraw2Ds() {
        for (const d of draw2ds) d.unregister();
        draw2ds.clear();
    },

    clearDraw3Ds() {
        for (const d of draw3ds) d.unregister();
        draw3ds.clear();
    },

    isContainer() {
        unimplemented('Hud.isContainer', 'NeoMacros exposes no open screen introspection');
    },

    toString() {
        return 'Hud(jsmacros-compat)';
    },
};

defineStubs(HudCompat, 'Hud', {
    createScreen: 'NeoMacros cannot create screens',
    openScreen: 'NeoMacros cannot open or close screens',
    createTexture: 'NeoMacros exposes no texture registry',
    getRegisteredTextures: 'NeoMacros exposes no texture registry',
});
