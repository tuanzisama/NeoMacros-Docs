// JsMacros TradeOfferHelper over the neo TradeOffer data face. The fields
// cross from the open villager screen; members whose merchant internals the
// neo surface does not publish (special price diff, xp rewards, selection)
// keep their JsMacros names and throw on call.
import { unimplemented } from '../support/errors.js';

export class TradeOfferHelperCompat {
    constructor(offer, index, inv) {
        this._offer = offer ?? {};
        this._index = index;
        this._inv = inv ?? null;
    }

    get index() { return this._index; }
    get inv() { return this._inv; }

    getIndex() { return this._index; }
    getLeftInput() { return this._offer.baseCostA ?? null; }
    getOriginalFirstInput() { return this._offer.baseCostA ?? null; }
    getInput() { return this._offer.costA ?? null; }
    getRightInput() { return this._offer.costB ?? null; }
    getOutput() { return this._offer.result ?? null; }
    getOriginalPrice() {
        return this._offer.baseCostA ? this._offer.baseCostA.count : null;
    }
    getAdjustedPrice() {
        return this._offer.costA ? this._offer.costA.count : null;
    }
    getDemandBonus() { return this._offer.demand ?? 0; }
    getUses() { return this._offer.uses ?? 0; }
    getMaxUses() { return this._offer.maxUses ?? 0; }
    isAvailable() {
        return (this._offer.uses ?? 0) < (this._offer.maxUses ?? 0);
    }

    getCurrentPriceAdjustment() {
        unimplemented('TradeOfferHelper.getCurrentPriceAdjustment',
            'NeoMacros exposes no special-price diff');
    }
    getSpecialPrice() {
        unimplemented('TradeOfferHelper.getSpecialPrice',
            'NeoMacros exposes no special-price diff');
    }
    getPriceMultiplier() {
        unimplemented('TradeOfferHelper.getPriceMultiplier',
            'NeoMacros exposes no trade price multiplier');
    }
    getExperience() {
        unimplemented('TradeOfferHelper.getExperience',
            'NeoMacros exposes no merchant xp reward');
    }
    shouldRewardPlayerExperience() {
        unimplemented('TradeOfferHelper.shouldRewardPlayerExperience',
            'NeoMacros exposes no merchant xp reward');
    }
    select() {
        unimplemented('TradeOfferHelper.select',
            'NeoMacros exposes no trade selection on the open screen');
    }
    getNBT() {
        unimplemented('TradeOfferHelper.getNBT',
            'NeoMacros exposes no raw offer NBT');
    }

    toString() {
        const out = this.getOutput();
        return 'TradeOffer(' + (out ? out.id + ' x' + out.count : 'empty') + ')';
    }
}
