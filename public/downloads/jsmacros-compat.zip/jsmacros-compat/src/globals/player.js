// The Player global: local player access, eye rays, and the interaction
// manager. Movement input synthesis, screenshots, sign writing, and
// teleport/velocity writes have no NeoMacros equivalent and throw.
import { unimplemented } from '../support/errors.js';
import { defineStubs, fillStubs } from '../support/stubTable.js';
import { CompatPos3D } from '../support/pos.js';
import { blockDataAt } from '../support/block.js';
import { createEntity } from './entity/specialized.js';
import { InteractionManagerCompat } from './interaction.js';
import { openInventoryCompat } from './inventory.js';

const BLOCK_REACH = 4.5;
const ENTITY_REACH = 3.0;

function eyeRay(distance, fluid) {
    const self = neo.player.self;
    if (!self) return null;
    const eye = self.eyePos;
    const dir = self.direction;
    const hit = neo.world.raycast(
        eye.x, eye.y, eye.z,
        eye.x + dir.x * distance,
        eye.y + dir.y * distance,
        eye.z + dir.z * distance,
    );
    // The fluid flag is accepted but NeoMacros raycasts ignore it.
    return hit;
}

export class HitResultCompat {
    constructor(rayHit) {
        this._hit = rayHit;
    }

    getBlock() {
        const b = this._hit?.block;
        return b ? blockDataAt(b.pos.x, b.pos.y, b.pos.z) : null;
    }

    getPos() {
        const p = this._hit?.pos;
        return p ? new CompatPos3D(p.x, p.y, p.z) : null;
    }

    getEntity() {
        return this._hit?.entity ? createEntity(this._hit.entity) : null;
    }

    toString() {
        return `HitResult(${this._hit?.hit ? 'hit' : 'miss'})`;
    }
}

fillStubs(HitResultCompat.prototype, 'HitResultHelper', 'block/entity resolution helpers are not exposed by the neo raycast surface');

export const PlayerCompat = {
    takeScreenshot() {
        const image = neo.client.grabScreenshot();
        if (image === undefined || image === null) return null;
        return {
            getWidth() { return image.width; },
            getHeight() { return image.height; },
            getBytes() { return image.bytes; },
        };
    },

    getStatistics() {
        const self = neo.player.self;
        if (self === undefined || self === null) return null;
        return self.statistics;
    },

    getReach() {
        const self = neo.player.self;
        if (self === undefined || self === null) return null;
        return self.entityInteractionRange;
    },

    isBreakingBlock() {
        const self = neo.player.self;
        if (self === undefined || self === null) return false;
        return self.isBreakingBlock === true;
    },

    getPlayer() {
        const self = neo.player.self;
        return self ? createEntity(self) : null;
    },

    openInventory() {
        return openInventoryCompat();
    },

    getInteractionManager() {
        return new InteractionManagerCompat();
    },

    /** JsMacros alias of getInteractionManager. */
    interactions() {
        return new InteractionManagerCompat();
    },

    getGameMode() {
        return neo.player.self?.gamemode ?? null;
    },

    rayTraceBlock(distance, fluid) {
        const hit = eyeRay(distance, fluid);
        return hit && hit.block ? blockDataAt(hit.block.pos.x, hit.block.pos.y, hit.block.pos.z) : null;
    },

    detailedRayTraceBlock(distance, fluid) {
        const hit = eyeRay(distance, fluid);
        return hit ? new HitResultCompat(hit) : null;
    },

    rayTraceEntity(distance) {
        const hit = eyeRay(distance, false);
        return hit && hit.entity ? createEntity(hit.entity) : null;
    },

    toString() {
        return `Player(${neo.player.self?.name ?? 'none'})`;
    },
};

defineStubs(PlayerCompat, 'Player', {
    setGameMode: 'NeoMacros exposes no gamemode write',
    writeSign: 'NeoMacros exposes no sign editing',
    takePanorama: 'NeoMacros exposes no panorama capture',
    createPlayerInput: 'NeoMacros exposes no movement input synthesis',
    createPlayerInputsFromCsv: 'NeoMacros exposes no movement input synthesis',
    createPlayerInputsFromJson: 'NeoMacros exposes no movement input synthesis',
    getCurrentPlayerInput: 'NeoMacros exposes no movement input introspection',
    addInput: 'NeoMacros exposes no movement input synthesis',
    addInputs: 'NeoMacros exposes no movement input synthesis',
    clearInputs: 'NeoMacros exposes no movement input synthesis',
    setDrawPredictions: 'NeoMacros exposes no movement prediction',
    predictInput: 'NeoMacros exposes no movement prediction',
    predictInputs: 'NeoMacros exposes no movement prediction',
    moveForward: 'NeoMacros exposes no movement input synthesis',
    moveBackward: 'NeoMacros exposes no movement input synthesis',
    moveStrafeLeft: 'NeoMacros exposes no movement input synthesis',
    moveStrafeRight: 'NeoMacros exposes no movement input synthesis',
});

export { ENTITY_REACH, BLOCK_REACH };
