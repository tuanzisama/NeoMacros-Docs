// Return-value shell classes: JsMacros APIs that hand back helper objects
// whose entire surface is unavailable under NeoMacros. The objects exist so
// old scripts get a consistent shape, and every method throws with the
// documented reason.
import { fillStubs } from '../support/stubTable.js';
import { unimplemented } from '../support/errors.js';

function shell(className, reason) {
    const cls = class {
    };
    Object.defineProperty(cls, 'name', { value: className });
    fillStubs(cls.prototype, className, reason);
    return cls;
}

const CHAT_REASON = 'chat history and command management are not exposed by NeoMacros';
const SCREEN_REASON = 'NeoMacros cannot create or control screens';
const TEXTURE_REASON = 'NeoMacros exposes no texture registry';
const SCAN_REASON = 'NeoMacros has no world scanner';
const STATS_REASON = 'NeoMacros exposes no statistics query';
const REGISTRY_REASON = 'NeoMacros exposes no registry data (java escape layer only)';
const OPTIONS_REASON = 'NeoMacros exposes no game options surface';
const MODS_REASON = 'NeoMacros exposes no mod list';
const PACKET_REASON = 'NeoMacros exposes no packet buffer utilities';
const SERVER_REASON = 'NeoMacros exposes no server ping data';
const ABILITIES_REASON = 'NeoMacros exposes no player abilities query';
const TRADES_REASON = 'NeoMacros exposes no trade offers';

export const ChatHistoryManagerShell = shell('ChatHistoryManager', CHAT_REASON);
export const CommandManagerShell = shell('CommandManager', CHAT_REASON);
export const CommandBuilderShell = shell('CommandBuilder', CHAT_REASON);
export const ScriptScreenShell = shell('ScriptScreen', SCREEN_REASON);
export const IScreenShell = shell('IScreen', SCREEN_REASON);
export const CustomImageShell = shell('CustomImage', TEXTURE_REASON);
export const WorldScannerBuilderShell = shell('WorldScannerBuilder', SCAN_REASON);
export const StatsHelperShell = shell('StatsHelper', STATS_REASON);
export const RegistryHelperShell = shell('RegistryHelper', REGISTRY_REASON);
export const OptionsHelperShell = shell('OptionsHelper', OPTIONS_REASON);
export const ModContainerHelperShell = shell('ModContainerHelper', MODS_REASON);
export const PacketByteBufferHelperShell = shell('PacketByteBufferHelper', PACKET_REASON);

// Server info bridge: live reads through the neo client port (latency
// included); the icon, version, and player-list surfaces stay stubbed.
class ServerInfoHelperCompat {
    info() {
        return neo?.client?.getServerInfo?.() ?? null;
    }
    getName() { const i = this.info(); return i ? i.name : null; }
    getLabel() { const i = this.info(); return i ? i.name : null; }
    getAddress() { const i = this.info(); return i ? i.address : null; }
    getPing() { const i = this.info(); return i ? i.ping : null; }
    isOnline() { return this.info() != null; }
    isLocal() { return this.info() == null; }

    getIcon() { unimplemented('ServerInfoHelper.getIcon', 'NeoMacros exposes no server icon'); }
    getNbt() { unimplemented('ServerInfoHelper.getNbt', 'NeoMacros exposes no server entry NBT'); }
    getPlayerCountLabel() { unimplemented('ServerInfoHelper.getPlayerCountLabel', 'NeoMacros exposes no player-count label'); }
    getPlayerListSummary() { unimplemented('ServerInfoHelper.getPlayerListSummary', 'NeoMacros exposes no player-list summary'); }
    getProtocolVersion() { unimplemented('ServerInfoHelper.getProtocolVersion', 'NeoMacros exposes no protocol version'); }
    getVersion() { unimplemented('ServerInfoHelper.getVersion', 'NeoMacros exposes no server version'); }
    resourcePackPolicy() { unimplemented('ServerInfoHelper.resourcePackPolicy', 'NeoMacros exposes no resource-pack policy'); }

    toString() {
        const i = this.info();
        return i ? 'ServerInfo(' + i.address + ')' : 'ServerInfo(local)';
    }
}
export const ServerInfoHelperShell = ServerInfoHelperCompat;

// Abilities bridge: live reads through the neo abilities handle, writes
// dispatch client-side exactly like the neo write face.
class PlayerAbilitiesHelperCompat {
    handle() {
        const self = neo?.player?.self;
        return self ? self.abilities : null;
    }
    getFlying() { const a = this.handle(); return a ? a.isFlying() : false; }
    getAllowFlying() { const a = this.handle(); return a ? a.mayFly() : false; }
    getCreativeMode() { const a = this.handle(); return a ? a.isInstabuild() : false; }
    getInvulnerable() { const a = this.handle(); return a ? a.isInvulnerable() : false; }
    canModifyWorld() { const a = this.handle(); return a ? a.mayBuild() : false; }
    getFlySpeed() { const a = this.handle(); return a ? a.flySpeed : 0; }
    getWalkSpeed() { const a = this.handle(); return a ? a.walkingSpeed : 0; }

    setFlying(b) {
        const a = neo.player.self.abilities;
        return a.setFlying(Boolean(b)).then(() => undefined);
    }
    setFlySpeed(speed) {
        const a = neo.player.self.abilities;
        return a.setFlySpeed(Number(speed)).then(() => undefined);
    }
    setWalkSpeed(speed) {
        const a = neo.player.self.abilities;
        return a.setWalkingSpeed(Number(speed)).then(() => undefined);
    }
    setAllowFlying(_b) {
        unimplemented('PlayerAbilitiesHelper.setAllowFlying(b)',
            'NeoMacros exposes no may-fly write');
    }

    toString() {
        const a = this.handle();
        return a ? 'Abilities()' : 'Abilities(unloaded)';
    }
}
export const PlayerAbilitiesHelperShell = PlayerAbilitiesHelperCompat;
export { TradeOfferHelperCompat as TradeOfferHelperShell } from './tradeOffer.js';
