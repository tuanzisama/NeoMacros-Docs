// The Time global. time() stays synchronous; sleep keeps its name and
// returns a promise because NeoMacros has no blocking sleep on the script
// loop (see README, "Synchronous APIs become promises").
export const TimeCompat = {
    time() {
        return Date.now();
    },

    sleep(millis) {
        return neo.thread.sleep(millis);
    },

    toString() {
        return 'Time(jsmacros-compat)';
    },
};
