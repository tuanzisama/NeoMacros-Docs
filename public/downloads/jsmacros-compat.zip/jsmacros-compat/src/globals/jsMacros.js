// The JsMacros global: event subscription bridged onto neo.events with the
// JsMacros (event, context) callback shape, plus custom events, filterers,
// and wait primitives. Unsupported JsMacros scripting surfaces (script
// spawning, profiles, services) keep their names and throw.
import { unimplemented } from '../support/errors.js';
import { defineStubs } from '../support/stubTable.js';
import { MAPPED, CUSTOM_PREFIX, resolveEvent } from './events/names.js';
import { adapt } from './events/payload.js';
import { EventAndContextCompat, SHARED_CONTEXT } from './events/context.js';

// NeoMacros waitForUntil needs a timeout; JsMacros waits forever. 2^53-1 ms
// (~285k years) is the largest value that survives the number->long hop.
const FOREVER = Number.MAX_SAFE_INTEGER;

const listeners = new Map();
let nextListenerId = 1;
const customEvents = new Set();

function matches(filterer, jsEvent) {
    if (!filterer) return true;
    if (typeof filterer === 'function') return !!filterer(jsEvent);
    if (typeof filterer.compatTest === 'function') return !!filterer.compatTest(jsEvent);
    return !!filterer(jsEvent);
}

function adaptFor(jsName, entry, neoPayload, meta) {
    if (customEvents.has(jsName)) {
        return customEventPayload(jsName, neoPayload);
    }
    return adapt(entry, jsName, neoPayload, meta);
}

function customEventPayload(jsName, payload) {
    const data = payload ?? {};
    const event = {
        getEventName: () => jsName,
        cancellable: () => false,
        joinable: () => true,
        cancel() {
            throw new Error(`${jsName} is not a cancellable event`);
        },
        isCanceled: () => false,
        getString: (k) => (typeof data[k] === 'string' ? data[k] : null),
        getInt: (k) => (typeof data[k] === 'number' && Number.isInteger(data[k]) ? data[k] : null),
        getDouble: (k) => (typeof data[k] === 'number' ? data[k] : null),
        getBoolean: (k) => (typeof data[k] === 'boolean' ? data[k] : null),
        getObject: (k) => (data[k] !== undefined ? data[k] : null),
        getType: (k) => {
            const v = data[k];
            if (typeof v === 'number') return Number.isInteger(v) ? 'Int' : 'Double';
            if (typeof v === 'string') return 'String';
            if (typeof v === 'boolean') return 'Boolean';
            if (v !== undefined && v !== null) return 'Object';
            return null;
        },
    };
    return event;
}

function prefixedCustom(name) {
    return `${CUSTOM_PREFIX}${name}`;
}

class ListenerCompat {
    constructor(id, jsName, joined, handles, once) {
        this._id = id;
        this._jsName = jsName;
        this._joined = joined;
        this._handles = handles;
        this._once = once;
        this._done = false;
    }

    off() {
        return JsMacros_off(this);
    }

    joined() {
        return this._joined;
    }

    trigger(event) {
        unimplemented(`IEventListener.trigger(${this._jsName})`, 'manual event delivery is not possible under NeoMacros');
    }

    toString() {
        return `IEventListener(${this._jsName}${this._joined ? ', joined' : ''})`;
    }
}

function JsMacros_off(listener) {
    const record = listeners.get(listener._id);
    if (!record) return false;
    for (const handle of record.handles) {
        try {
            neo.events.off(handle);
        } catch (e) {
            // NeoMacros already cleaned this subscription up (module unload).
        }
    }
    listeners.delete(listener._id);
    return true;
}

function resolveJsName(name) {
    const resolved = resolveEvent(name, customEvents);
    if (resolved.kind === 'unsupported') {
        unimplemented(`JsMacros.on('${resolved.name}')`, resolved.reason);
    }
    if (resolved.kind === 'unknown') {
        throw new Error(`unknown JsMacros event '${resolved.name}' - create custom events with JsMacros.createCustomEvent`);
    }
    return resolved;
}

function subscribe(jsName, entry, callback, filterer, joined, once) {
    const id = nextListenerId++;
    const handles = [];
    const sync = joined && !!entry?.syncCapable && !customEvents.has(jsName);
    const neoNames = entry?.neo ?? [prefixedCustom(jsName)];

    const deliver = (neoPayload, meta) => {
        const jsEvent = adaptFor(jsName, entry, neoPayload, meta);
        if (!matches(filterer, jsEvent)) return undefined;
        callback(jsEvent, SHARED_CONTEXT);
        if (once) markDone(id);
        return jsEvent;
    };

    for (const neoName of neoNames) {
        const closing = neoNames.length > 1 && neoName === 'screen:close';
        if (sync) {
            const handle = neo.events.onSync(neoName, (payload) => {
                const jsEvent = deliver(payload, { sync: true, closing });
                return !!jsEvent?.isCanceled();
            });
            handles.push(handle);
        } else {
            const handle = neo.events.on(neoName, (payload) => {
                deliver(payload, { closing });
            });
            handles.push(handle);
        }
    }

    const listener = new ListenerCompat(id, jsName, joined, handles, once);
    listeners.set(id, { jsName, handles, listener });
    return listener;
}

function markDone(id) {
    const record = listeners.get(id);
    if (record) JsMacros_off(record.listener);
}

function parseSubscriptionArgs(rest) {
    let joined = false;
    let filterer = null;
    let callback = null;
    for (const arg of rest) {
        if (typeof arg === 'boolean') {
            joined = arg;
        } else if (typeof arg === 'function') {
            callback = arg;
        } else if (arg && (typeof arg.compatTest === 'function' || typeof arg === 'object')) {
            filterer = arg;
        }
    }
    if (!callback) {
        throw new Error('JsMacros.on: missing callback');
    }
    return { joined, filterer, callback };
}

function parseWaitArgs(rest) {
    let join = false;
    let filter = null;
    let before = null;
    const fns = [];
    for (const arg of rest) {
        if (typeof arg === 'boolean') {
            join = arg;
        } else if (arg && typeof arg === 'object' && typeof arg.compatTest === 'function') {
            if (!filter) filter = arg;
        } else if (typeof arg === 'function') {
            fns.push(arg);
        }
    }
    if (fns.length === 1) {
        filter = fns[0];
    } else if (fns.length >= 2) {
        [filter, before] = fns;
    }
    return { join, filter, before };
}

function waitForOne(jsName, entry, neoName, filter, meta) {
    const wrap = (payload) => {
        const jsEvent = adaptFor(jsName, entry, payload, meta);
        return jsEvent;
    };
    if (filter) {
        const filterOnJs = (payload) => matches(filter, wrap(payload));
        return neo.events.waitForUntil(neoName, filterOnJs, FOREVER).then(wrap);
    }
    return neo.events.waitFor(neoName).then(wrap);
}

class EventCustomCompat {
    constructor(eventName) {
        this.eventName = eventName;
        this.joinable = false;
        this._payload = {};
        this._registered = false;
    }

    get cancelable() {
        return false;
    }

    set cancelable(value) {
        if (value) {
            unimplemented('EventCustom.cancelable', 'NeoMacros custom events are always non-cancellable');
        }
    }

    putInt(name, value) {
        this._payload[name] = value;
        return value;
    }

    putString(name, value) {
        this._payload[name] = value;
        return value;
    }

    putDouble(name, value) {
        this._payload[name] = value;
        return value;
    }

    putBoolean(name, value) {
        this._payload[name] = value;
        return value;
    }

    putObject(name, value) {
        unimplemented('EventCustom.putObject', 'NeoMacros custom event payloads carry JSON-serializable data only');
    }

    getInt(name) {
        const v = this._payload[name];
        return typeof v === 'number' && Number.isInteger(v) ? v : null;
    }

    getString(name) {
        const v = this._payload[name];
        return typeof v === 'string' ? v : null;
    }

    getDouble(name) {
        const v = this._payload[name];
        return typeof v === 'number' ? v : null;
    }

    getBoolean(name) {
        const v = this._payload[name];
        return typeof v === 'boolean' ? v : null;
    }

    getObject(name) {
        const v = this._payload[name];
        return v !== undefined ? v : null;
    }

    getType(name) {
        const v = this._payload[name];
        if (typeof v === 'number') return Number.isInteger(v) ? 'Int' : 'Double';
        if (typeof v === 'string') return 'String';
        if (typeof v === 'boolean') return 'Boolean';
        if (v !== undefined && v !== null) return 'Object';
        return null;
    }

    getUnderlyingMap() {
        return this._payload;
    }

    registerEvent() {
        neo.events.register(prefixedCustom(this.eventName));
        customEvents.add(this.eventName);
        this._registered = true;
        return this;
    }

    _emit() {
        if (!this._registered) {
            throw new Error(`custom event '${this.eventName}' must be registered first (call registerEvent())`);
        }
        neo.events.emit(prefixedCustom(this.eventName), { ...this._payload });
    }

    trigger() {
        this._emit();
    }

    triggerAsync(callback) {
        this._emit();
        if (typeof callback === 'function') {
            callback(customEventPayload(this.eventName, { ...this._payload }));
        }
    }

    toString() {
        return `EventCustom(${this.eventName})`;
    }
}

// ---------------------------------------------------------------------------
// Filterers: pure JS pre-filters evaluated on the adapted event before the
// callback runs, matching JsMacros filter semantics observably.
// ---------------------------------------------------------------------------

class BlockUpdateFiltererCompat {
    constructor() {
        this._pos = null;
        this._area = null;
        this._blockId = null;
        this._updateType = null;
    }

    setPos(posOrX, y, z) {
        this._pos = typeof posOrX === 'object' ? posOrX : { x: posOrX, y, z };
        return this;
    }

    setArea(pos1, pos2) {
        this._area = [pos1, pos2];
        return this;
    }

    setBlockId(id) {
        this._blockId = id;
        return this;
    }

    setUpdateType(type) {
        this._updateType = type;
        return this;
    }

    compatTest(jsEvent) {
        if (!jsEvent || !jsEvent.block) return false;
        if (this._updateType !== null && jsEvent.updateType !== this._updateType) return false;
        if (this._blockId !== null && jsEvent.block.getId() !== this._blockId) return false;
        const pos = jsEvent.block.getBlockPos();
        if (this._pos) {
            const p = this._pos;
            if (pos.getX() !== p.x || pos.getY() !== p.y || pos.getZ() !== p.z) return false;
        }
        if (this._area) {
            const [a, b] = this._area;
            const inX = pos.getX() >= Math.min(a.x, b.x) && pos.getX() <= Math.max(a.x, b.x);
            const inY = pos.getY() >= Math.min(a.y, b.y) && pos.getY() <= Math.max(a.y, b.y);
            const inZ = pos.getZ() >= Math.min(a.z, b.z) && pos.getZ() <= Math.max(a.z, b.z);
            if (!(inX && inY && inZ)) return false;
        }
        return true;
    }
}

class ModulusFiltererCompat {
    constructor(quotient) {
        this.quotient = quotient;
        this._count = 0;
    }

    setQuotient(q) {
        this.quotient = q;
        return this;
    }

    compatTest() {
        this._count += 1;
        return (this._count - 1) % this.quotient === 0;
    }
}

class ComposedFiltererCompat {
    constructor(initial) {
        this._stack = [initial];
        this._ops = [];
    }

    and(f) {
        this._ops.push(['and', f]);
        return this;
    }

    or(f) {
        this._ops.push(['or', f]);
        return this;
    }

    compatTest(jsEvent) {
        let result = matches(this._stack[0], jsEvent);
        for (const [op, f] of this._ops) {
            const value = matches(f, jsEvent);
            result = op === 'and' ? (result && value) : (result || value);
        }
        return result;
    }
}

export const JsMacrosCompat = {
    on(name, ...rest) {
        const resolved = resolveJsName(name);
        const { joined, filterer, callback } = parseSubscriptionArgs(rest);
        return subscribe(resolved.name, resolved.kind === 'mapped' ? resolved.entry : null, callback, filterer, joined, false);
    },

    once(name, ...rest) {
        const resolved = resolveJsName(name);
        const { joined, filterer, callback } = parseSubscriptionArgs(rest);
        return subscribe(resolved.name, resolved.kind === 'mapped' ? resolved.entry : null, callback, filterer, joined, true);
    },

    off(nameOrListener, maybeListener) {
        if (typeof nameOrListener === 'string') {
            const resolved = resolveJsName(nameOrListener);
            const targets = [...listeners.values()].filter((r) => r.jsName === resolved.name);
            let any = false;
            for (const record of targets) {
                any = JsMacros_off(record.listener) || any;
            }
            return any;
        }
        return JsMacros_off(nameOrListener);
    },

    listeners(name) {
        const resolved = resolveJsName(name);
        return [...listeners.values()]
            .filter((r) => r.jsName === resolved.name)
            .map((r) => r.listener);
    },

    disableAllListeners(name) {
        let targets = [...listeners.values()];
        if (name) {
            const resolved = resolveJsName(name);
            targets = targets.filter((r) => r.jsName === resolved.name);
        }
        for (const record of targets) JsMacros_off(record.listener);
    },

    disableScriptListeners(name) {
        // Without per-script listener attribution every tracked listener is
        // the calling script's, so this mirrors disableAllListeners.
        this.disableAllListeners(name);
    },

    async waitForEvent(name, ...rest) {
        const resolved = resolveJsName(name);
        if (resolved.kind !== 'mapped' && !customEvents.has(resolved.name)) {
            unimplemented(`JsMacros.waitForEvent('${resolved.name}')`, 'cannot wait on an unsupported event');
        }
        const { filter, before } = parseWaitArgs(rest);
        if (typeof before === 'function') before();
        const entry = resolved.kind === 'mapped' ? resolved.entry : null;
        const neoNames = entry?.neo ?? [prefixedCustom(resolved.name)];
        const races = neoNames.map((neoName, index) => waitForOne(
            resolved.name,
            entry,
            neoName,
            filter,
            { closing: neoNames.length > 1 && neoName === 'screen:close' },
        ));
        const jsEvent = await (races.length === 1 ? races[0] : Promise.race(races));
        return new EventAndContextCompat(jsEvent, SHARED_CONTEXT);
    },

    assertEvent(event, type) {
        const actual = event?.getEventName?.();
        if (actual !== type) {
            throw new Error(`assertEvent failed: expected '${type}', got '${actual}'`);
        }
    },

    createCustomEvent(eventName) {
        if (customEvents.has(eventName)) {
            throw new Error(`custom event '${eventName}' already exists`);
        }
        return new EventCustomCompat(String(eventName));
    },

    createEventFilterer(eventName) {
        const resolved = resolveJsName(eventName);
        if (resolved.kind === 'unsupported') {
            unimplemented(`JsMacros.createEventFilterer('${resolved.name}')`, resolved.reason);
        }
        if (resolved.name === 'BlockUpdate') return new BlockUpdateFiltererCompat();
        return { compatTest: () => true };
    },

    createComposedEventFilterer(initial) {
        return new ComposedFiltererCompat(initial);
    },

    createModulusEventFilterer(quotient) {
        return new ModulusFiltererCompat(quotient);
    },

    invertEventFilterer(base) {
        return { compatTest: (jsEvent) => !matches(base, jsEvent) };
    },

    toString() {
        return 'JsMacros (jsmacros-compat bridge over neo.events)';
    },
};

defineStubs(JsMacrosCompat, 'JsMacros', {
    getProfile: 'NeoMacros has no profile concept',
    getConfig: 'NeoMacros exposes no config manager to scripts',
    getServiceManager: 'NeoMacros has no service system',
    getOpenContexts: 'NeoMacros does not expose script execution contexts',
    runScript: 'NeoMacros cannot spawn nested script runs',
    wrapScriptRun: 'NeoMacros cannot spawn nested script runs',
    wrapScriptRunAsync: 'NeoMacros cannot spawn nested script runs',
    open: 'deprecated in JsMacros and unavailable under NeoMacros',
    openUrl: 'deprecated in JsMacros and unavailable under NeoMacros',
});
