// The Request global mapped onto neo.net. JsMacros' blocking request surface
// keeps its names and returns promises (see README, "Synchronous APIs become
// promises"). WebSockets keep their names and throw: NeoMacros has none.
import { unimplemented } from '../support/errors.js';
import { defineStubs, fillStubs } from '../support/stubTable.js';

/** JsMacros Response helper resolved after the neo response settles. */
export class ResponseCompat {
    constructor(neoResponse) {
        this._res = neoResponse;
        this._code = neoResponse?.status ?? neoResponse?.responseCode ?? 0;
        this._headers = neoResponse?.headers ?? {};
    }

    get responseCode() {
        return this._code;
    }

    get headers() {
        return this._headers;
    }

    text() {
        return Promise.resolve(this._res).then((r) => r.text());
    }

    json() {
        // JsMacros' json() is deprecated and always returns null; the compat
        // version parses the body instead, matching what scripts actually do.
        return this.text().then((t) => JSON.parse(t));
    }

    byteArray() {
        return Promise.resolve(this._res).then((r) => r.bytes());
    }

    toString() {
        return `Response(${this._code})`;
    }
}

fillStubs(ResponseCompat.prototype, 'HTTPRequest.Response', 'raw header-list and connection details are not exposed by neo.net responses');

function headerMap(headers) {
    return headers ?? {};
}

export const RequestCompat = {
    createWS(url) {
        return neo.net.connect(String(url));
    },

    createWS2(url, headers) {
        // header support rides the ws upgrade batch; same connect path
        return neo.net.connect(String(url));
    },

    get(url, headers) {
        return neo.net.fetch(url, { method: 'GET', headers: headerMap(headers) })
            .then((r) => new ResponseCompat(r));
    },

    post(url, data, headers) {
        return neo.net.fetch(url, { method: 'POST', headers: headerMap(headers), body: String(data) })
            .then((r) => new ResponseCompat(r));
    },

    create(url) {
        return new HttpRequestCompat(url);
    },

    toString() {
        return 'Request(jsmacros-compat over neo.net)';
    },
};

/** JsMacros HTTPRequest builder over neo.net.fetch. */
export class HttpRequestCompat {
    constructor(url) {
        this._url = url;
        this._headers = {};
    }

    get url() {
        return this._url;
    }

    set url(value) {
        this._url = value;
    }

    get headers() {
        return this._headers;
    }

    set headers(value) {
        this._headers = value ?? {};
    }

    addHeader(key, value) {
        this._headers[key] = value;
        return this;
    }

    setConnectTimeout(millis) {
        unimplemented('HTTPRequest.setConnectTimeout', 'NeoMacros exposes no connect timeout tuning');
    }

    setReadTimeout(millis) {
        unimplemented('HTTPRequest.setReadTimeout', 'NeoMacros exposes no read timeout tuning');
    }

    get() {
        return neo.net.fetch(this.url, { method: 'GET', headers: this.headers })
            .then((r) => new ResponseCompat(r));
    }

    post(data) {
        return neo.net.fetch(this.url, { method: 'POST', headers: this.headers, body: String(data) })
            .then((r) => new ResponseCompat(r));
    }

    put(data) {
        return neo.net.fetch(this.url, { method: 'PUT', headers: this.headers, body: String(data) })
            .then((r) => new ResponseCompat(r));
    }

    send(method, data) {
        const init = { method: String(method).toUpperCase(), headers: this.headers };
        if (data !== undefined) init.body = String(data);
        return neo.net.fetch(this.url, init).then((r) => new ResponseCompat(r));
    }

    toString() {
        return `HTTPRequest(${this.url})`;
    }
}

fillStubs(HttpRequestCompat.prototype, 'HTTPRequest', 'timeout tuning and raw connection access are not exposed by neo.net');

defineStubs(RequestCompat, 'Request', {
});
