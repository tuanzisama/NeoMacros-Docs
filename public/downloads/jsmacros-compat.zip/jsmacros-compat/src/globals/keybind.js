// The KeyBind global mapped onto neo.input: raw key injection and vanilla
// bind-name state setting. Bind re-assignment and key introspection are
// unavailable under NeoMacros.
import { defineStubs } from '../support/stubTable.js';

export const KeyBindCompat = {
    getKeyBindings() {
        return neo.input.keybinds.map((bind) => ({
            getId() { return bind.name; },
            getKeyName() { return bind.key; },
            getCategory() { return null; },
        }));
    },

    setKeyBind(bindName, keyName) {
        neo.input.setBind(String(bindName), String(keyName));
    },

    getPressedKeys() {
        return neo.input.pressedKeys;
    },

    key(keyName, state) {
        if (state) {
            neo.input.press(keyName);
        } else {
            neo.input.release(keyName);
        }
    },

    pressKey(keyName) {
        neo.input.press(keyName);
    },

    releaseKey(keyName) {
        neo.input.release(keyName);
    },

    keyBind(keyBind, state) {
        neo.input.set(keyBind, state);
    },

    pressKeyBind(keyBind) {
        neo.input.set(keyBind, true);
    },

    releaseKeyBind(keyBind) {
        neo.input.set(keyBind, false);
    },

    toString() {
        return 'KeyBind(jsmacros-compat)';
    },
};

defineStubs(KeyBindCompat, 'KeyBind', {
    getKeyCode: 'NeoMacros exposes no raw key code objects',
});
