// InteractionManagerHelper bridge over the local player's neo action set
// (attack / interact / interactBlock / interactEntity) plus eye-ray targeting.
import { unimplemented } from '../support/errors.js';
import { fillStubs } from '../support/stubTable.js';
import { blockDataAt } from '../support/block.js';
import { createEntity } from './entity/specialized.js';

// Vanilla survival reach values (attack range 3.0, block reach 4.5).
const ENTITY_REACH = 3.0;
const BLOCK_REACH = 4.5;

function requireSelf() {
    const self = neo.player.self;
    if (!self) {
        unimplemented('Player.getInteractionManager', 'the local player is not in a world');
    }
    return self;
}

function eyeRay(distance) {
    const self = requireSelf();
    const eye = self.eyePos;
    const dir = self.direction;
    return neo.world.raycast(
        eye.x, eye.y, eye.z,
        eye.x + dir.x * distance,
        eye.y + dir.y * distance,
        eye.z + dir.z * distance,
    );
}

export class InteractionManagerCompat {
    attack(targetOrAwait, awaitFlag) {
        const self = requireSelf();
        if (targetOrAwait === undefined || typeof targetOrAwait === 'boolean') {
            const hit = eyeRay(ENTITY_REACH);
            if (!hit || !hit.entity) {
                throw new Error('interactions.attack: no entity in reach (3.0 blocks)');
            }
            return self.attack(hit.entity);
        }
        const handle = targetOrAwait?._source !== undefined ? targetOrAwait._source : targetOrAwait;
        return self.attack(handle);
    }

    interactEntity(entity, offHand, awaitFlag) {
        const handle = entity?._source !== undefined ? entity._source : entity;
        return requireSelf().interactEntity(handle);
    }

    interactBlock(x, y, z, direction, offHand, awaitFlag) {
        const pos = new neo.types.BlockPos(x, y, z);
        // The direction and off-hand arguments are accepted but NeoMacros
        // dispatches a plain use on the block position.
        return requireSelf().interactBlock(pos);
    }

    getTargetedBlock() {
        const hit = eyeRay(BLOCK_REACH);
        return hit && hit.block ? blockDataAt(hit.block.pos.x, hit.block.pos.y, hit.block.pos.z) : null;
    }

    getTargetedEntity() {
        const hit = eyeRay(ENTITY_REACH);
        return hit && hit.entity ? createEntity(hit.entity) : null;
    }

    getGameMode() {
        return requireSelf().gamemode;
    }

    toString() {
        return 'InteractionManager(jsmacros-compat)';
    }
}

fillStubs(InteractionManagerCompat.prototype, 'InteractionManagerHelper', 'block breaking, held interactions, and targeting overrides have no NeoMacros equivalent');
