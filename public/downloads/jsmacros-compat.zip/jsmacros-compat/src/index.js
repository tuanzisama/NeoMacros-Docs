// Entry point. Importing this module installs the full JsMacros 1.9.2
// global surface (Player, World, Chat, ..., JsMacros) on top of the
// NeoMacros `neo` surface. Installation is idempotent and happens
// automatically on import when `neo` is already present.
import { unimplemented } from './support/errors.js';
import { JsMacrosCompat } from './globals/jsMacros.js';
import { PlayerCompat } from './globals/player.js';
import { WorldCompat } from './globals/world.js';
import { ChatCompat } from './globals/chat.js';
import { ClientCompat } from './globals/client.js';
import { TimeCompat } from './globals/time.js';
import { KeyBindCompat } from './globals/keybind.js';
import { HudCompat } from './globals/hud.js';
import { FsCompat } from './globals/fs.js';
import { RequestCompat } from './globals/request.js';
import { GlobalVarsCompat } from './globals/globalVars.js';
import { ReflectionCompat } from './globals/reflection.js';
import { JavaUtilsCompat } from './globals/javaUtils.js';
import { JavaWrapperCompat } from './globals/javaWrapper.js';
import { PositionCommonCompat } from './globals/positionCommon.js';
import { UtilsCompat } from './globals/utils.js';
import { ColorCompat } from './globals/color.js';

const GLOBALS = {
    JsMacros: JsMacrosCompat,
    Player: PlayerCompat,
    World: WorldCompat,
    Chat: ChatCompat,
    Client: ClientCompat,
    Time: TimeCompat,
    KeyBind: KeyBindCompat,
    Hud: HudCompat,
    FS: FsCompat,
    GlobalVars: GlobalVarsCompat,
    Request: RequestCompat,
    Reflection: ReflectionCompat,
    JavaUtils: JavaUtilsCompat,
    JavaWrapper: JavaWrapperCompat,
    PositionCommon: PositionCommonCompat,
    Utils: UtilsCompat,
    Color: ColorCompat,
};

/**
 * JsMacros injects `event`, `context`, and `file` into event-triggered file
 * execution. NeoMacros runs scripts as long-lived modules with event
 * subscriptions, so the per-file execution model has no equivalent; reading
 * these globals throws with migration guidance instead.
 */
function installInjectedGlobals(target) {
    const injected = {
        event: 'JsMacros injects the triggering event into event-run files; under NeoMacros subscribe with JsMacros.on(...)',
        context: 'JsMacros injects the run context into event-run files; under NeoMacros subscriptions clean up with the module',
        file: 'JsMacros injects the script file handle; NeoMacros exposes no script file handle to scripts',
    };
    for (const [name, reason] of Object.entries(injected)) {
        Object.defineProperty(target, name, {
            get() {
                unimplemented(`global '${name}'`, reason);
            },
            configurable: true,
        });
    }
}

let installed = false;

export function install() {
    if (installed) return GLOBALS;
    for (const [name, compat] of Object.entries(GLOBALS)) {
        Object.defineProperty(globalThis, name, {
            value: compat,
            writable: true,
            configurable: true,
        });
    }
    installInjectedGlobals(globalThis);
    installed = true;
    return GLOBALS;
}

/** The compat global registry, install() or not. */
export function globals() {
    return GLOBALS;
}

if (globalThis.neo !== undefined) {
    install();
}

export default install;
