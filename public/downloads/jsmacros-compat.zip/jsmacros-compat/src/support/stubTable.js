// Declarative stub machinery. Every unsupported JsMacros member is attached
// through this module so tools/audit.mjs can enumerate them exhaustively from
// the same tables the runtime uses.
import { unimplemented } from './errors.js';
import { SURFACE } from './surface-data.js';

/**
 * Attaches throwing methods for the explicit table entries.
 * @param {object} proto prototype (or instance) receiving the stubs
 * @param {string} className dotted JsMacros class path used in error messages
 * @param {Record<string, string>} table member name -> why it is unavailable
 */
export function defineStubs(proto, className, table) {
    for (const [member, reason] of Object.entries(table)) {
        const stubFn = function stub() {
            unimplemented(`${className}.${member}`, reason);
        };
        stubFn.__compatStub = reason;
        Object.defineProperty(proto, member, {
            value: stubFn,
            writable: true,
            configurable: true,
        });
    }
}

/**
 * Fills every remaining surface method of {@link className} with a throwing
 * stub. Members already present anywhere on the prototype chain are kept, so
 * hand-written implementations always win and inherited members are untouched.
 * @param {object} proto prototype receiving the fill
 * @param {string} className key into SURFACE
 * @param {string} reason default reason for the filled members
 */
export function fillStubs(proto, className, reason) {
    const entry = SURFACE[className];
    if (!entry) return;
    for (const name of Object.keys(entry.methods)) {
        if (name in proto) continue;
        const stubFn = function stub() {
            unimplemented(`${className}.${name}`, reason);
        };
        stubFn.__compatStub = reason;
        Object.defineProperty(proto, name, {
            value: stubFn,
            writable: true,
            configurable: true,
        });
    }
    fillSurfaceFields(proto, className, reason);
}

/**
 * Adds throwing accessors for surface fields missing on the instance. Own
 * data properties already set by the constructor keep working because own
 * properties shadow prototype accessors for reads, and writes hit the own
 * property first as well.
 * @param {object} obj instance receiving the field accessors
 * @param {string} className key into SURFACE
 * @param {string} reason default reason for the filled fields
 */
export function fillSurfaceFields(obj, className, reason) {
    const entry = SURFACE[className];
    if (!entry) return;
    for (const field of entry.fields) {
        if (field in obj) continue;
        const getter = function () {
            unimplemented(`${className}.${field}`, reason);
        };
        getter.__compatStub = reason;
        Object.defineProperty(obj, field, {
            get: getter,
            set() {
                unimplemented(`${className}.${field} (write)`, reason);
            },
            configurable: true,
        });
    }
}

/**
 * Creates a shell class whose whole surface throws. Used for JsMacros helper
 * classes that exist only as return values of APIs NeoMacros cannot provide.
 * @param {string} className JsMacros class name for the shell
 * @param {Function} Base compat base class to extend
 * @param {string} reason default reason for every member
 * @returns {Function} the shell class
 */
export function stubShellClass(className, Base, reason) {
    const cls = class extends Base {
        constructor(...args) {
            super(...args);
        }
    };
    Object.defineProperty(cls, 'name', { value: className });
    fillStubs(cls.prototype, className, reason);
    return cls;
}
