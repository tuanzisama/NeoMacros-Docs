// BlockDataHelper, BlockStateHelper, and ChunkHelper over the neo
// world/block handles. Reads stay live (they re-query the world), matching
// the rest of the neo surface rather than JsMacros' point-in-time snapshots.
import { CompatBlockPos, CompatPos3D } from './pos.js';
import { TextHelperCompat } from './text.js';
import { unimplemented } from './errors.js';
import { fillStubs, stubShellClass } from './stubTable.js';

/** 'minecraft:deepslate_bricks' -> 'Deepslate Bricks' (documented approximation). */
export function prettifyId(id) {
    const short = String(id).includes(':') ? String(id).split(':')[1] : String(id);
    return short
        .split('_')
        .map((w) => (w === '' ? w : w[0].toUpperCase() + w.slice(1)))
        .join(' ');
}

function requireBlock(block, member) {
    if (block === undefined || block === null) {
        unimplemented(`BlockDataHelper.${member}`, 'the block is no longer loaded in the world');
    }
    return block;
}

/** JsMacros BlockDataHelper over a neo block handle. */
export class BlockDataCompat {
    constructor(block) {
        this._block = block;
    }

    getBlockPos() {
        const pos = requireBlock(this._block, 'getBlockPos').pos;
        return new CompatBlockPos(pos.x, pos.y, pos.z);
    }

    getX() {
        return requireBlock(this._block, 'getX').pos.x;
    }

    getY() {
        return requireBlock(this._block, 'getY').pos.y;
    }

    getZ() {
        return requireBlock(this._block, 'getZ').pos.z;
    }

    getId() {
        return requireBlock(this._block, 'getId').state?.id;
    }

    getName() {
        // Display name derived from the id: NeoMacros exposes no block name
        // translation lookup.
        return TextHelperCompat.fromString(prettifyId(this.getId()));
    }

    getBlockStateHelper() {
        const state = requireBlock(this._block, 'getBlockStateHelper').state;
        if (!state) {
            unimplemented('BlockDataHelper.getBlockStateHelper', 'the block is no longer loaded in the world');
        }
        return new BlockStateCompat(state);
    }

    getBlock() {
        unimplemented('BlockDataHelper.getBlock', 'raw host block access needs the java escape layer');
    }

    toString() {
        const b = this._block;
        if (!b) return 'BlockData(gone)';
        const pos = b.pos ?? { x: '?', y: '?', z: '?' };
        return `${b.state?.id ?? '?'} @ ${pos.x}, ${pos.y}, ${pos.z}`;
    }
}

fillStubs(BlockDataCompat.prototype, 'BlockDataHelper', 'no equivalent in the neo block surface');

/** JsMacros BlockStateHelper over a neo block state. */
export class BlockStateCompat {
    constructor(state) {
        this._state = state;
    }

    getId() {
        return this._state?.id;
    }

    isAir() {
        return !!this._state?.isAir;
    }

    isLiquid() {
        return !!this._state?.liquid;
    }

    toString() {
        return this._state ? String(this._state) : 'BlockState(gone)';
    }
}

fillStubs(BlockStateCompat.prototype, 'BlockStateHelper', 'state physics and light properties are not exposed by the neo block surface');

/**
 * JsMacros ChunkHelper carrying only the chunk coordinates; every
 * deeper chunk query has no NeoMacros equivalent.
 */
export const ChunkHelperCompat = stubShellClass('ChunkHelper', Object, 'NeoMacros exposes no chunk query surface beyond loaded checks');

/**
 * BlockDataHelper for a position: queries the world live. Returns null when
 * the position sits outside the loaded world, mirroring World.getBlock.
 */
export function blockDataAt(x, y, z) {
    const block = neo.world.blockAt(x, y, z);
    return block ? new BlockDataCompat(block) : null;
}
