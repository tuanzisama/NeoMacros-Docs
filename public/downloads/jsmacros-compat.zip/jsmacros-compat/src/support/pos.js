// JsMacros math classes: Pos2D/Pos3D/Vec2D/Vec3D/BlockPosHelper/DirectionHelper.
// Faithful to JsMacros semantics (mutable x/y/z fields, non-mutating
// arithmetic returning new instances); implemented in pure JS because the
// neo types follow different construction and access conventions.
import { fillStubs } from './stubTable.js';

export const DEG = 180 / Math.PI;
export const RAD = Math.PI / 180;

/** Unit direction vector for Minecraft yaw/pitch angles in degrees. */
export function directionFromAngles(yawDeg, pitchDeg) {
    const yaw = yawDeg * RAD;
    const pitch = pitchDeg * RAD;
    return {
        x: -Math.sin(yaw) * Math.cos(pitch),
        y: -Math.sin(pitch),
        z: Math.cos(yaw) * Math.cos(pitch),
    };
}

/** Minecraft yaw/pitch angles (degrees) for a direction vector. */
export function anglesFromDirection(x, y, z) {
    const horizontal = Math.sqrt(x * x + z * z);
    const pitch = -Math.asin(y / Math.sqrt(x * x + y * y + z * z)) * DEG;
    const yaw = Math.atan2(-x, z) * DEG;
    return { yaw, pitch, horizontal };
}

function compareNumbers(a, b) {
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
}

function argTriple(other, x, y, z) {
    return other !== undefined && typeof other === 'object' ? [other.x, other.y, other.z] : [x, y, z];
}

function argPair(other, x, y) {
    return other !== undefined && typeof other === 'object' ? [other.x, other.y] : [x, y];
}

export class CompatPos2D {
    constructor(x, y) {
        this._x = x;
        this._y = y;
    }

    // JsMacros exposes mutable public fields; keep them as accessors so the
    // surface fill never shadows construction-time assignment.
    get x() {
        return this._x;
    }

    set x(value) {
        this._x = value;
    }

    get y() {
        return this._y;
    }

    set y(value) {
        this._y = value;
    }

    getX() {
        return this.x;
    }

    getY() {
        return this.y;
    }

    add(other, y) {
        const [ox, oy] = argPair(other, other, y === undefined ? other : y);
        return new CompatPos2D(this.x + ox, this.y + oy);
    }

    sub(other, y) {
        const [ox, oy] = argPair(other, other, y === undefined ? other : y);
        return new CompatPos2D(this.x - ox, this.y - oy);
    }

    multiply(other, y) {
        const [ox, oy] = argPair(other, other, y === undefined ? other : y);
        return new CompatPos2D(this.x * ox, this.y * oy);
    }

    divide(other, y) {
        const [ox, oy] = argPair(other, other, y === undefined ? other : y);
        return new CompatPos2D(this.x / ox, this.y / oy);
    }

    scale(factor) {
        return new CompatPos2D(this.x * factor, this.y * factor);
    }

    to3D() {
        return new CompatPos3D(this.x, this.y, 0);
    }

    toVector() {
        return new CompatVec2D(0, 0, this.x, this.y);
    }

    toReverseVector() {
        return new CompatVec2D(this.x, this.y, 0, 0);
    }

    compareTo(other) {
        const byX = compareNumbers(this.x, other.x);
        return byX !== 0 ? byX : compareNumbers(this.y, other.y);
    }

    equals(other) {
        return other instanceof CompatPos2D && other.x === this.x && other.y === this.y;
    }

    hashCode() {
        return Math.trunc(this.x) * 92821 + Math.trunc(this.y);
    }

    toString() {
        return `${this.x.toFixed(6)}, ${this.y.toFixed(6)}`;
    }
}

CompatPos2D.ZERO = new CompatPos2D(0, 0);

export class CompatPos3D extends CompatPos2D {
    constructor(x, y, z) {
        super(x, y);
        this._z = z;
    }

    get z() {
        return this._z;
    }

    set z(value) {
        this._z = value;
    }

    getZ() {
        return this.z;
    }

    add(other, y, z) {
        const [ox, oy, oz] = argTriple(other, other, y, z === undefined ? y : z);
        return new CompatPos3D(this.x + ox, this.y + oy, this.z + oz);
    }

    sub(other, y, z) {
        const [ox, oy, oz] = argTriple(other, other, y, z === undefined ? y : z);
        return new CompatPos3D(this.x - ox, this.y - oy, this.z - oz);
    }

    multiply(other, y, z) {
        const [ox, oy, oz] = argTriple(other, other, y, z === undefined ? y : z);
        return new CompatPos3D(this.x * ox, this.y * oy, this.z * oz);
    }

    divide(other, y, z) {
        const [ox, oy, oz] = argTriple(other, other, y, z === undefined ? y : z);
        return new CompatPos3D(this.x / ox, this.y / oy, this.z / oz);
    }

    scale(factor) {
        return new CompatPos3D(this.x * factor, this.y * factor, this.z * factor);
    }

    toVector() {
        return new CompatVec3D(0, 0, 0, this.x, this.y, this.z);
    }

    toReverseVector() {
        return new CompatVec3D(this.x, this.y, this.z, 0, 0, 0);
    }

    toBlockPos() {
        return new CompatBlockPos(Math.floor(this.x), Math.floor(this.y), Math.floor(this.z));
    }

    compareTo(other) {
        const byX = compareNumbers(this.x, other.x);
        if (byX !== 0) return byX;
        const byY = compareNumbers(this.y, other.y);
        return byY !== 0 ? byY : compareNumbers(this.z, other.z);
    }

    equals(other) {
        return other instanceof CompatPos3D
            && other.x === this.x && other.y === this.y && other.z === this.z;
    }

    hashCode() {
        return Math.trunc(this.x) * 92821 + Math.trunc(this.y) * 92823 + Math.trunc(this.z);
    }

    toString() {
        return `${this.x.toFixed(6)}, ${this.y.toFixed(6)}, ${this.z.toFixed(6)}`;
    }
}

CompatPos3D.ZERO = new CompatPos3D(0, 0, 0);

export class CompatVec2D {
    constructor(x1, y1, x2, y2) {
        this._x1 = x1;
        this._y1 = y1;
        this._x2 = x2;
        this._y2 = y2;
    }

    get x1() {
        return this._x1;
    }

    set x1(value) {
        this._x1 = value;
    }

    get y1() {
        return this._y1;
    }

    set y1(value) {
        this._y1 = value;
    }

    get x2() {
        return this._x2;
    }

    set x2(value) {
        this._x2 = value;
    }

    get y2() {
        return this._y2;
    }

    set y2(value) {
        this._y2 = value;
    }

    getX1() {
        return this.x1;
    }

    getY1() {
        return this.y1;
    }

    getX2() {
        return this.x2;
    }

    getY2() {
        return this.y2;
    }

    getDeltaX() {
        return this.x2 - this.x1;
    }

    getDeltaY() {
        return this.y2 - this.y1;
    }

    getStart() {
        return new CompatPos2D(this.x1, this.y1);
    }

    getEnd() {
        return new CompatPos2D(this.x2, this.y2);
    }

    getMagnitudeSq() {
        return this.getDeltaX() ** 2 + this.getDeltaY() ** 2;
    }

    getMagnitude() {
        return Math.sqrt(this.getMagnitudeSq());
    }

    add(other) {
        return new CompatVec2D(this.x1 + other.x1, this.y1 + other.y1, this.x2 + other.x2, this.y2 + other.y2);
    }

    multiply(other) {
        return new CompatVec2D(this.x1 * other.x1, this.y1 * other.y1, this.x2 * other.x2, this.y2 * other.y2);
    }

    scale(factor) {
        const start = this.getStart();
        const end = this.getEnd();
        const ns = new CompatPos2D(start.x * factor, start.y * factor);
        const ne = new CompatPos2D(end.x * factor, end.y * factor);
        return new CompatVec2D(ns.x, ns.y, ne.x, ne.y);
    }

    dotProduct(other) {
        return this.getDeltaX() * other.getDeltaX() + this.getDeltaY() * other.getDeltaY();
    }

    reverse() {
        return new CompatVec2D(this.x2, this.y2, this.x1, this.y1);
    }

    normalize() {
        const magnitude = this.getMagnitude();
        if (magnitude === 0) return new CompatVec2D(this.x1, this.y1, this.x1, this.y1);
        return this.scale(1 / magnitude);
    }

    to3D() {
        return new CompatVec3D(this.x1, this.y1, 0, this.x2, this.y2, 0);
    }

    equals(other) {
        return other instanceof CompatVec2D
            && other.x1 === this.x1 && other.y1 === this.y1
            && other.x2 === this.x2 && other.y2 === this.y2;
    }

    hashCode() {
        return Math.trunc(this.getMagnitudeSq());
    }

    toString() {
        return `[${this.x1}, ${this.y1} -> ${this.x2}, ${this.y2}]`;
    }
}

export class CompatVec3D extends CompatVec2D {
    constructor(x1, y1, z1, x2, y2, z2) {
        super(x1, y1, x2, y2);
        this._z1 = z1;
        this._z2 = z2;
    }

    get z1() {
        return this._z1;
    }

    set z1(value) {
        this._z1 = value;
    }

    get z2() {
        return this._z2;
    }

    set z2(value) {
        this._z2 = value;
    }

    getZ1() {
        return this.z1;
    }

    getZ2() {
        return this.z2;
    }

    getDeltaZ() {
        return this.z2 - this.z1;
    }

    getStart() {
        return new CompatPos3D(this.x1, this.y1, this.z1);
    }

    getEnd() {
        return new CompatPos3D(this.x2, this.y2, this.z2);
    }

    getMagnitudeSq() {
        return this.getDeltaX() ** 2 + this.getDeltaY() ** 2 + this.getDeltaZ() ** 2;
    }

    add(other) {
        return new CompatVec3D(
            this.x1 + other.x1, this.y1 + other.y1, this.z1 + other.z1,
            this.x2 + other.x2, this.y2 + other.y2, this.z2 + other.z2,
        );
    }

    addStart(pos, y, z) {
        const [sx, sy, sz] = argTriple(pos, pos, y, z === undefined ? y : z);
        return new CompatVec3D(sx, sy, sz, this.x2, this.y2, this.z2);
    }

    addEnd(pos, y, z) {
        const [ex, ey, ez] = argTriple(pos, pos, y, z === undefined ? y : z);
        return new CompatVec3D(this.x1, this.y1, this.z1, ex, ey, ez);
    }

    multiply(other) {
        return new CompatVec3D(
            this.x1 * other.x1, this.y1 * other.y1, this.z1 * other.z1,
            this.x2 * other.x2, this.y2 * other.y2, this.z2 * other.z2,
        );
    }

    scale(factor) {
        const start = this.getStart();
        const end = this.getEnd();
        const ns = start.scale(factor);
        const ne = end.scale(factor);
        return new CompatVec3D(ns.x, ns.y, ns.z, ne.x, ne.y, ne.z);
    }

    dotProduct(other) {
        return this.getDeltaX() * other.getDeltaX()
            + this.getDeltaY() * other.getDeltaY()
            + this.getDeltaZ() * other.getDeltaZ();
    }

    crossProduct(other) {
        const dx = this.getDeltaX();
        const dy = this.getDeltaY();
        const dz = this.getDeltaZ();
        const ox = other.getDeltaX();
        const oy = other.getDeltaY();
        const oz = other.getDeltaZ();
        const start = this.getStart();
        return new CompatVec3D(
            start.x, start.y, start.z,
            start.x + dy * oz - dz * oy,
            start.y + dz * ox - dx * oz,
            start.z + dx * oy - dy * ox,
        );
    }

    reverse() {
        return new CompatVec3D(this.x2, this.y2, this.z2, this.x1, this.y1, this.z1);
    }

    normalize() {
        const magnitude = this.getMagnitude();
        if (magnitude === 0) return new CompatVec3D(this.x1, this.y1, this.z1, this.x1, this.y1, this.z1);
        return this.scale(1 / magnitude);
    }

    /** Unit vector of this vec as a CompatVec3D anchored at its start. */
    getDirection() {
        const start = this.getStart();
        const magnitude = this.getMagnitude();
        if (magnitude === 0) return new CompatVec3D(start.x, start.y, start.z, start.x, start.y, start.z);
        return new CompatVec3D(
            start.x, start.y, start.z,
            start.x + this.getDeltaX() / magnitude,
            start.y + this.getDeltaY() / magnitude,
            start.z + this.getDeltaZ() / magnitude,
        );
    }

    getPitch() {
        return anglesFromDirection(this.getDeltaX(), this.getDeltaY(), this.getDeltaZ()).pitch;
    }

    getYaw() {
        return anglesFromDirection(this.getDeltaX(), this.getDeltaY(), this.getDeltaZ()).yaw;
    }

    toMojangFloatVector() {
        // Host type construction needs the java escape layer.
        return undefined;
    }

    equals(other) {
        return other instanceof CompatVec3D
            && other.x1 === this.x1 && other.y1 === this.y1 && other.z1 === this.z1
            && other.x2 === this.x2 && other.y2 === this.y2 && other.z2 === this.z2;
    }

    toString() {
        return `[${this.x1}, ${this.y1}, ${this.z1} -> ${this.x2}, ${this.y2}, ${this.z2}]`;
    }
}

const CARDINALS = {
    up: [0, 1, 0],
    down: [0, -1, 0],
    north: [0, 0, -1],
    south: [0, 0, 1],
    west: [-1, 0, 0],
    east: [1, 0, 0],
};

/**
 * Immutable block-grid coordinate with JsMacros directional helpers.
 */
export class CompatBlockPos {
    constructor(x, y, z) {
        this._x = Math.trunc(x);
        this._y = Math.trunc(y);
        this._z = Math.trunc(z);
    }

    getX() {
        return this._x;
    }

    getY() {
        return this._y;
    }

    getZ() {
        return this._z;
    }

    _shift([dx, dy, dz], n) {
        return new CompatBlockPos(this._x + dx * n, this._y + dy * n, this._z + dz * n);
    }

    up(n) {
        return this._shift(CARDINALS.up, n ?? 1);
    }

    down(n) {
        return this._shift(CARDINALS.down, n ?? 1);
    }

    north(n) {
        return this._shift(CARDINALS.north, n ?? 1);
    }

    south(n) {
        return this._shift(CARDINALS.south, n ?? 1);
    }

    west(n) {
        return this._shift(CARDINALS.west, n ?? 1);
    }

    east(n) {
        return this._shift(CARDINALS.east, n ?? 1);
    }

    offset(directionOrDx, dyOrN, dz) {
        if (typeof directionOrDx === 'string') {
            const key = directionOrDx.toLowerCase();
            if (!(key in CARDINALS)) {
                throw new Error(`BlockPosHelper.offset: unknown direction '${directionOrDx}'`);
            }
            return this._shift(CARDINALS[key], dyOrN ?? 1);
        }
        return new CompatBlockPos(this._x + directionOrDx, this._y + dyOrN, this._z + dz);
    }

    distanceTo(other, y, z) {
        let ox;
        let oy;
        let oz;
        if (other instanceof CompatBlockPos || other instanceof CompatPos3D) {
            [ox, oy, oz] = [other.getX(), other.getY(), other.getZ()];
        } else if (other && typeof other === 'object') {
            [ox, oy, oz] = [other.x, other.y, other.z];
        } else {
            [ox, oy, oz] = [other, y, z];
        }
        return Math.sqrt((this._x - ox) ** 2 + (this._y - oy) ** 2 + (this._z - oz) ** 2);
    }

    toPos3D() {
        return new CompatPos3D(this._x, this._y, this._z);
    }

    toNetherCoords() {
        return new CompatBlockPos(Math.floor(this._x / 8), this._y, Math.floor(this._z / 8));
    }

    toOverworldCoords() {
        return new CompatBlockPos(this._x * 8, this._y, this._z * 8);
    }

    compareTo(other) {
        const byX = compareNumbers(this._x, other._x);
        if (byX !== 0) return byX;
        const byY = compareNumbers(this._y, other._y);
        return byY !== 0 ? byY : compareNumbers(this._z, other._z);
    }

    equals(other) {
        return other instanceof CompatBlockPos
            && other._x === this._x && other._y === this._y && other._z === this._z;
    }

    hashCode() {
        return (this._x * 92821) ^ (this._y * 92823) ^ (this._z * 92829);
    }

    toString() {
        return `${this._x}, ${this._y}, ${this._z}`;
    }
}

const AXES = { up: 'y', down: 'y', north: 'z', south: 'z', east: 'x', west: 'x' };

/**
 * JsMacros DirectionHelper over a cardinal direction name.
 */
export class CompatDirection {
    constructor(name) {
        this._name = name;
        this._cardinal = CARDINALS[name.toLowerCase()];
        if (!this._cardinal) {
            throw new Error(`DirectionHelper: unknown direction '${name}'`);
        }
    }

    getName() {
        return this._name.toLowerCase();
    }

    getVector() {
        const [x, y, z] = this._cardinal;
        return new CompatPos3D(x, y, z);
    }

    getAxis() {
        return AXES[this.getName()];
    }

    getOpposite() {
        const opposites = { up: 'down', down: 'up', north: 'south', south: 'north', west: 'east', east: 'west' };
        return new CompatDirection(opposites[this.getName()]);
    }

    getLeft() {
        const lefts = { north: 'west', west: 'south', south: 'east', east: 'north' };
        return this.isVertical() ? this : new CompatDirection(lefts[this.getName()]);
    }

    getRight() {
        return this.getLeft().getOpposite();
    }

    getPitch() {
        const [, y] = this._cardinal;
        return -Math.asin(y) * DEG;
    }

    getYaw() {
        const [x, , z] = this._cardinal;
        return Math.atan2(-x, z) * DEG;
    }

    isHorizontal() {
        return this.getName() !== 'up' && this.getName() !== 'down';
    }

    isVertical() {
        return !this.isHorizontal();
    }

    isTowardsPositive() {
        const [x, y, z] = this._cardinal;
        return (x + y + z) > 0;
    }

    pointsTo(yaw) {
        if (!this.isHorizontal()) return false;
        // Vanilla yaw grows counter-clockwise: the yaw points along the
        // direction when its circular distance to the direction yaw is <= 45.
        const dirYaw = this.getYaw();
        let diff = ((yaw - dirYaw) % 360 + 540) % 360 - 180;
        diff = Math.abs(diff);
        return diff <= 45;
    }

    toString() {
        return this.getName();
    }
}

fillStubs(CompatPos2D.prototype, 'Pos2D', 'no NeoMacros equivalent');
fillStubs(CompatPos3D.prototype, 'Pos3D', 'no NeoMacros equivalent');
fillStubs(CompatVec2D.prototype, 'Vec2D', 'no NeoMacros equivalent');
fillStubs(CompatVec3D.prototype, 'Vec3D', 'no NeoMacros equivalent');
fillStubs(CompatBlockPos.prototype, 'BlockPosHelper', 'no NeoMacros equivalent');
fillStubs(CompatDirection.prototype, 'DirectionHelper', 'no NeoMacros equivalent');
