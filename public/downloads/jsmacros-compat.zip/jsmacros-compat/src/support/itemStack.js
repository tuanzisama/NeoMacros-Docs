// ItemStackHelper over a neo item stack. Accepts both a live neo
// ItemStack handle and a plain ItemStackData payload object - both carry the
// same field names, only the read timing differs.
import { TextHelperCompat } from './text.js';
import { prettifyId } from './block.js';
import { unimplemented } from './errors.js';
import { fillStubs } from './stubTable.js';

function sameJson(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
}

export class ItemStackCompat {
    constructor(data) {
        this._data = data;
    }

    _read(field) {
        const d = this._data;
        if (d === undefined || d === null) {
            unimplemented(`ItemStackHelper.${field}`, 'the backing stack is gone');
        }
        return d[field];
    }

    getItemId() {
        return this._read('id');
    }

    /** Deprecated JsMacros alias kept for old scripts. */
    getItemID() {
        return this.getItemId();
    }

    getCount() {
        return this._read('count');
    }

    getDamage() {
        return this._read('damage');
    }

    getMaxDamage() {
        return this._read('maxDamage');
    }

    getMaxDurability() {
        return this.getMaxDamage();
    }

    getDurability() {
        const max = this.getMaxDamage();
        return max > 0 ? max - this.getDamage() : 0;
    }

    isEmpty() {
        return !!this._read('isEmpty');
    }

    getItem() {
        unimplemented('ItemStackHelper.getItem', 'raw host item access needs the java escape layer');
    }

    getName() {
        return TextHelperCompat.fromString(String(this._read('name')));
    }

    getDefaultName() {
        // Derived from the id: NeoMacros carries no default-name translation.
        return TextHelperCompat.fromString(prettifyId(this.getItemId()));
    }

    getLore() {
        return (this._read('lore') ?? []).map((line) => TextHelperCompat.fromString(String(line)));
    }

    getEnchantments() {
        return (this._read('enchantments') ?? []).map((e) => ({ id: e.id, lvl: e.level }));
    }

    getEnchantment(id) {
        const wanted = withNamespace(id);
        const hit = this.getEnchantments().find((e) => withNamespace(e.id) === wanted);
        return hit ?? null;
    }

    hasEnchantment(idOrHelper) {
        return this.getEnchantment(idOrHelper) !== null;
    }

    equals(other) {
        if (!(other instanceof ItemStackCompat)) return false;
        return this.getItemId() === other.getItemId()
            && this.getCount() === other.getCount()
            && this.getDamage() === other.getDamage()
            && sameJson(this.getLore().map(String), other.getLore().map(String))
            && sameJson(this.getEnchantments(), other.getEnchantments());
    }

    isNBTEqual(other) {
        return other instanceof ItemStackCompat && this.equals(other);
    }

    isItemEqual(other) {
        if (!(other instanceof ItemStackCompat)) return false;
        return withNamespace(other.getItemId()) === withNamespace(this.getItemId());
    }

    /** No component-level data is carried, so both JsMacros forms agree. */
    isItemEqualIgnoreDamage(other) {
        return this.isItemEqual(other);
    }

    copy() {
        return new ItemStackCompat({
            id: this.getItemId(),
            count: this.getCount(),
            damage: this.getDamage(),
            maxDamage: this.getMaxDamage(),
            name: String(this.getName()),
            lore: this.getLore().map((l) => String(l)),
            enchantments: this.getEnchantments().map((e) => ({ id: e.id, level: e.lvl })),
            isEmpty: this.isEmpty(),
        });
    }

    toString() {
        return `${this.getItemId()} x ${this.getCount()}`;
    }
}

function withNamespace(id) {
    const s = String(id);
    return s.includes(':') ? s : `minecraft:${s}`;
}

fillStubs(ItemStackCompat.prototype, 'ItemStackHelper', 'not exposed by the neo item stack surface');
