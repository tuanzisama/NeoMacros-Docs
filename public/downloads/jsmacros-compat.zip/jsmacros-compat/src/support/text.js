// TextHelper and TextBuilder compatibility shims over plain strings and
// NeoMacros chat component trees. NeoMacros chat output renders legacy
// formatting codes, so shims serialize styling to section codes.
import { unimplemented } from './errors.js';
import { fillStubs } from './stubTable.js';

const COLOR_NAMES = {
    black: 0, dark_blue: 1, dark_green: 2, dark_aqua: 3, dark_red: 4,
    dark_purple: 5, gold: 6, gray: 7, dark_gray: 8, blue: 9, green: 10,
    aqua: 11, red: 12, light_purple: 13, yellow: 14, white: 15,
};

const CODE_COLORS = {
    0: [0, 0, 0], 1: [0, 0, 170], 2: [0, 170, 0], 3: [0, 170, 170],
    4: [170, 0, 0], 5: [170, 0, 170], 6: [255, 170, 0], 7: [170, 170, 170],
    8: [85, 85, 85], 9: [85, 85, 255], 10: [85, 255, 85], 11: [85, 255, 255],
    12: [255, 85, 85], 13: [255, 85, 255], 14: [255, 255, 85], 15: [255, 255, 255],
};

const COLOR_CODES = '0123456789abcdef';
const STYLE_CODES = { bold: 'l', italic: 'o', underlined: 'n', strikethrough: 'm', obfuscated: 'k' };

const STRIP_PATTERN = /\u00a7[0-9a-fk-or]/gi;

export function stripFormatting(text) {
    return String(text).replace(STRIP_PATTERN, '');
}

/** Nearest legacy palette code for an RGB triple (simple squared distance). */
export function nearestColorCode(r, g, b) {
    let best = 15;
    let bestDist = Infinity;
    for (const code of Object.keys(CODE_COLORS)) {
        const [cr, cg, cb] = CODE_COLORS[code];
        const dist = (r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2;
        if (dist < bestDist) {
            bestDist = dist;
            best = Number(code);
        }
    }
    return best;
}

export function colorCodeFromName(name) {
    return COLOR_NAMES[name] ?? null;
}

function emptyPart() {
    return {
        text: '',
        color: null,
        bold: false,
        italic: false,
        underlined: false,
        strikethrough: false,
        obfuscated: false,
    };
}

/** Flattens a NeoMacros chat component tree into shim parts. */
function partsFromComponent(component) {
    const parts = [];
    const base = { color: null, bold: false, italic: false, underlined: false, strikethrough: false, obfuscated: false };
    const walk = (node, style) => {
        if (node === undefined || node === null || typeof node === 'string') {
            parts.push({ ...emptyPart(), text: String(node ?? '') });
            return;
        }
        const merged = {
            color: typeof node.color === 'string' && node.color in COLOR_NAMES ? COLOR_NAMES[node.color] : style.color,
            bold: typeof node.bold === 'boolean' ? node.bold : style.bold,
            italic: typeof node.italic === 'boolean' ? node.italic : style.italic,
            underlined: typeof node.underlined === 'boolean' ? node.underlined : style.underlined,
            strikethrough: typeof node.strikethrough === 'boolean' ? node.strikethrough : style.strikethrough,
            obfuscated: typeof node.obfuscated === 'boolean' ? node.obfuscated : style.obfuscated,
        };
        parts.push({ ...emptyPart(), text: node.text ?? '', ...merged });
        for (const child of node.children ?? []) walk(child, merged);
    };
    walk(component, base);
    return parts.length ? parts : [emptyPart()];
}

function nodeFromPart(part) {
    const node = { text: part.text };
    if (part.color !== null) node.color = Object.keys(COLOR_NAMES)[part.color];
    for (const flag of Object.keys(STYLE_CODES)) {
        if (part[flag]) node[flag] = true;
    }
    return node;
}

/**
 * JsMacros TextHelper: an ordered list of styled text parts with
 * plain, formatted, and JSON serializations.
 */
export class TextHelperCompat {
    /**
     * @param {string|object|null} source plain string or chat component tree
     */
    constructor(source) {
        this._parts = typeof source === 'string'
            ? [{ ...emptyPart(), text: source }]
            : partsFromComponent(source);
    }

    static fromString(content) {
        return new TextHelperCompat(String(content));
    }

    static fromJson(json) {
        let tree;
        try {
            tree = typeof json === 'string' ? JSON.parse(json) : json;
        } catch (e) {
            throw new Error(`TextHelper: invalid JSON input: ${e.message}`);
        }
        return new TextHelperCompat(tree);
    }

    static fromTranslationKey(key, ...content) {
        // NeoMacros does not expose the translation registry; the raw key is
        // kept so scripts receive deterministic output.
        const suffix = content.length ? ` ${content.join(' ')}` : '';
        return new TextHelperCompat(`${key}${suffix}`);
    }

    static wrap(source) {
        return source instanceof TextHelperCompat ? source : new TextHelperCompat(source);
    }

    _adopt(parts) {
        this._parts = parts.map((p) => ({ ...p }));
        return this;
    }

    getString() {
        return this._parts.map((p) => p.text).join('');
    }

    /** Legacy section-code form suitable for NeoMacros chat rendering. */
    getFormatted() {
        let out = '';
        for (const p of this._parts) {
            if (p.text === '') continue;
            out += '\u00a7r';
            if (p.color !== null) out += `\u00a7${COLOR_CODES[p.color]}`;
            for (const [flag, code] of Object.entries(STYLE_CODES)) {
                if (p[flag]) out += `\u00a7${code}`;
            }
            out += p.text;
        }
        return out;
    }

    getStringStripFormatting() {
        return stripFormatting(this.getString());
    }

    toJson() {
        const [head, ...rest] = this._parts;
        const node = nodeFromPart(head);
        if (rest.length) node.extra = rest.map(nodeFromPart);
        return node;
    }

    getJson() {
        return JSON.stringify(this.toJson());
    }

    withoutFormatting() {
        const clone = new TextHelperCompat(null)._adopt(this._parts);
        for (const p of clone._parts) {
            p.bold = false;
            p.italic = false;
            p.underlined = false;
            p.strikethrough = false;
            p.obfuscated = false;
        }
        return clone;
    }

    visit(visitor) {
        for (const p of this._parts) {
            if (p.text !== '') visitor(p.text);
        }
    }

    replaceFromString(content) {
        this._parts = [{ ...emptyPart(), text: String(content) }];
        return this;
    }

    replaceFromJson(json) {
        this._parts = TextHelperCompat.fromJson(json)._parts;
        return this;
    }

    toString() {
        return this.getString();
    }
}

fillStubs(TextHelperCompat.prototype, 'TextHelper', 'not backed by the NeoMacros text pipeline');

/**
 * JsMacros TextBuilder: accumulates styled parts and produces a
 * TextHelper.
 */
export class TextBuilderCompat {
    constructor() {
        this._parts = [emptyPart()];
    }

    _current() {
        return this._parts[this._parts.length - 1];
    }

    _ensurePart() {
        if (this._current().text === '') return this._current();
        const fresh = emptyPart();
        this._parts.push(fresh);
        return fresh;
    }

    append(part) {
        const text = part instanceof TextHelperCompat ? part.getString() : String(part);
        this._current().text += text;
        return this;
    }

    withColor(a, b, c) {
        const part = this._ensurePart();
        if (typeof a === 'number' && b === undefined) {
            part.color = a;
        } else if (typeof a === 'string' && /^[0-9a-f]$/i.test(a)) {
            part.color = COLOR_CODES.indexOf(a.toLowerCase());
        } else if (typeof a === 'string' && a in COLOR_NAMES) {
            part.color = COLOR_NAMES[a];
        } else if (typeof a === 'number' && typeof b === 'number' && typeof c === 'number') {
            part.color = nearestColorCode(a, b, c);
        } else {
            unimplemented('TextBuilder.withColor', 'unsupported color argument form');
        }
        return this;
    }

    withFormatting(underline, bold, italic, strikethrough, magic) {
        const part = this._ensurePart();
        part.underlined = !!underline;
        part.bold = !!bold;
        part.italic = !!italic;
        part.strikethrough = !!strikethrough;
        part.obfuscated = !!magic;
        return this;
    }

    build() {
        return new TextHelperCompat(null)._adopt(this._parts);
    }

    toString() {
        return 'TextBuilder';
    }
}

fillStubs(TextBuilderCompat.prototype, 'TextBuilder', 'hover and click styling has no NeoMacros chat equivalent');
