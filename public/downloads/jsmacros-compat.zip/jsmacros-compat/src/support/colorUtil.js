// ARGB helpers backing the Color global and the draw modules. Pure integer
// math, no NeoMacros involvement.
export function argb(a, r, g, b) {
    return ((a & 0xff) << 24) | ((r & 0xff) << 16) | ((g & 0xff) << 8) | (b & 0xff);
}

export function rgb(r, g, b) {
    return argb(0xff, r, g, b);
}

export function alpha(color) {
    return (color >>> 24) & 0xff;
}

export function red(color) {
    return (color >>> 16) & 0xff;
}

export function green(color) {
    return (color >>> 8) & 0xff;
}

export function blue(color) {
    return color & 0xff;
}

export function withAlpha(color, a) {
    return argb(a, red(color), green(color), blue(color));
}

/** JsMacros fromPacked: unpack the low 32 bits of a packed long into ARGB. */
export function fromPacked(packed) {
    if (typeof packed === 'bigint') {
        return Number(BigInt.asIntN(32, packed & 0xffffffffn));
    }
    return packed | 0;
}
