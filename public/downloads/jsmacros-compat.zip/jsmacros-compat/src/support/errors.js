// Error type and thrower for JsMacros API members that have no NeoMacros
// equivalent. Every unsupported member keeps its JsMacros name and raises this
// error when reached, so old scripts fail loudly instead of silently no-oping.

export class UnimplementedError extends Error {
    /**
     * @param {string} path dotted JsMacros API path, e.g. `World.playSound`
     * @param {string} reason short reason why NeoMacros cannot substitute it
     */
    constructor(path, reason) {
        super(`${path} is not available on NeoMacros: ${reason}`);
        this.name = 'UnimplementedError';
        this.path = path;
        this.reason = reason;
    }
}

/**
 * Throws an {@link UnimplementedError} for the given API path.
 * @param {string} path dotted JsMacros API path
 * @param {string} reason why the API cannot be substituted
 */
export function unimplemented(path, reason) {
    throw new UnimplementedError(path, reason);
}
