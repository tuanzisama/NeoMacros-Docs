// jsmacros-compat demo script for NeoMacros.
// Copy the jsmacros-compat folder next to this script (or adjust the import
// path), then run this file from the NeoMacros script browser.
import './jsmacros-compat/src/index.js';

// Read surface: synchronous, live handles.
const me = Player.getPlayer();
if (me) {
    Chat.log(`hello ${me.getPlayerName()} @ ${me.getPos()}`);
    Chat.actionbar(`hp ${me.getHealth()}/${me.getMaxHealth()} food ${me.getFoodLevel()}`);
    const target = me.rayTraceBlock(4.5, false);
    if (target) {
        Chat.log(`looking at ${target.getId()} @ ${target.getBlockPos()}`);
    }
    const held = me.getMainHand();
    if (held) {
        Chat.log(`holding ${held.getItemId()} x${held.getCount()}`);
    }
} else {
    Chat.log('not in a world');
}

// World queries.
if (World.isWorldLoaded()) {
    const stone = World.getBlock(0, 64, 0);
    if (stone) {
        Chat.log(`block at 0/64/0 = ${stone.getId()} (biome ${stone.getBlockStateHelper().getId()})`);
    }
    const players = World.getLoadedPlayers() ?? [];
    Chat.log(`${players.length} players loaded`);
}

// Event bridge: JsMacros names map onto neo events, payload keeps the
// JsMacros shape.
JsMacros.on('Key', (event, context) => {
    Chat.log(`key ${event.key} action ${event.action} mods [${event.mods}]`);
});

JsMacros.on('RecvMessage', (event) => {
    Chat.log(`chat: ${event.text.getStringStripFormatting()}`);
});

// Legacy alias also works.
JsMacros.on('TICK', () => {
    // fires every client tick
});

// Unsupported surfaces fail loudly instead of silently missing.
try {
    Client.connect('localhost');
} catch (e) {
    Chat.log(`expected failure: ${e}`);
}

// Async surfaces return promises (JsMacros was synchronous).
await Time.sleep(50);
await FS.open('jsmacros-compat-demo.txt').write('written at ' + Date.now());
Chat.log('fs roundtrip: ' + await FS.open('jsmacros-compat-demo.txt').read());

const response = await Request.get('https://api.github.com/zen');
Chat.log('http: ' + await response.text());

// Custom events bridge onto neo.events under a compat: namespace.
const ping = JsMacros.createCustomEvent('demoPing');
ping.putString('from', 'demo');
ping.registerEvent();
JsMacros.on('demoPing', (event) => {
    Chat.log('got custom event from ' + event.getString('from'));
});
ping.trigger();

// Draw facades with the JsMacros register lifecycle.
const d2 = Hud.createDraw2D();
d2.addText('jsmacros-compat online', 8, 8, 0xff55ff55);
d2.register();

const d3 = Hud.createDraw3D();
if (me) {
    const p = me.getBlockPos();
    d3.addBox(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 2, p.getZ() + 1, 0xff5555ff, 0, false, true);
    d3.register();
}

// Cleanup with the module lifecycle: unregistering removes the shapes.
JsMacros.on('QuitGame', () => {
    d2.unregister();
    d3.unregister();
    Chat.log('bye');
});
